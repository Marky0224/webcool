$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pythonScript = Join-Path $projectRoot 'forecast_model.py'
$port = 8001
$forecastUrl = "http://127.0.0.1:$port/forecast"
$logsDirectory = Join-Path $env:LOCALAPPDATA 'Webcool\logs'
$stdoutLog = Join-Path $logsDirectory 'forecast-service.log'
$stderrLog = Join-Path $logsDirectory 'forecast-service-error.log'

if (-not (Test-Path -LiteralPath $pythonScript -PathType Leaf)) {
    throw "Python forecast model was not found: $pythonScript"
}

$listener = Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue |
    Select-Object -First 1

if (-not $listener) {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if (-not $pythonCommand) {
        throw 'Python was not found. Install Python or add it to PATH, then try again.'
    }

    if (-not (Test-Path -LiteralPath $logsDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $logsDirectory -Force | Out-Null
    }

    Start-Process `
        -FilePath $pythonCommand.Source `
        -ArgumentList @('-u', 'forecast_model.py') `
        -WorkingDirectory $projectRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutLog `
        -RedirectStandardError $stderrLog | Out-Null
}

$body = '{"horizon":7}'
$ready = $false
for ($attempt = 0; $attempt -lt 15; $attempt++) {
    try {
        $result = Invoke-RestMethod `
            -Uri $forecastUrl `
            -Method Post `
            -ContentType 'application/json' `
            -Body $body `
            -TimeoutSec 2
        if ($result.history.Count -eq 7 -and $result.predictions.Count -eq 7) {
            $ready = $true
            break
        }
    } catch {
        Start-Sleep -Seconds 1
    }
}

if (-not $ready) {
    if (Test-Path -LiteralPath $stderrLog -PathType Leaf) {
        $details = Get-Content -LiteralPath $stderrLog -Tail 20
        throw "Forecast service failed to start. Check $stderrLog.`n$($details -join "`n")"
    }
    throw "Forecast service did not respond at $forecastUrl."
}

Write-Output "Forecast service is running at $forecastUrl"
Write-Output 'It will remain available until Windows shuts down or the service process is stopped.'
