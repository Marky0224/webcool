<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectionId = trim((string) ($_GET['inspection_id'] ?? $_POST['inspection_id'] ?? ''));
$inspections = firebase_get('inspections');
$inspections = is_array($inspections) ? $inspections : [];
$inspection = null;
$inspectionKey = null;
foreach ($inspections as $key => $item) {
    if (is_array($item) && (string) ($item['inspection_id'] ?? '') === $inspectionId) {
        $inspection = $item;
        $inspectionKey = (string) $key;
        break;
    }
}

if ($inspection === null || $inspectionKey === null) {
    http_response_code(404);
    exit('Ante-Mortem inspection record not found.');
}

$inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
$anteMortem = is_array($inspectionData['ante_mortem'] ?? null) ? $inspectionData['ante_mortem'] : [];
$customer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
$categoryOptions = ['B' => 'Backyard', 'C' => 'Commercial', 'S' => 'Stockyard'];
$documentOptions = [
    'Animal Identification Certificate (AIC)',
    'Veterinary Health Certificate (VHC)',
    'Certificate of Status for African Swine Fever (ASF)',
    'Shipping Permit',
    'Para Vet Issue',
];
$savedDocumentsValue = $anteMortem['document_presented'] ?? [];
$savedDocuments = is_array($savedDocumentsValue)
    ? $savedDocumentsValue
    : ($savedDocumentsValue !== '' ? [$savedDocumentsValue] : []);
$savedDocuments = array_map(
    static fn($document): string => get_ante_mortem_document_label((string) $document),
    $savedDocuments
);
$form = [
    'no_of_heads' => trim((string) ($_POST['no_of_heads'] ?? $anteMortem['no_of_heads'] ?? '')),
    'farm_owner' => trim((string) ($_POST['farm_owner'] ?? $anteMortem['farm_owner'] ?? '')),
    'origin' => trim((string) ($_POST['origin'] ?? $anteMortem['origin'] ?? '')),
    'category' => get_ante_mortem_category_code((string) ($_POST['category'] ?? $anteMortem['category'] ?? '')),
    'document_presented' => $_SERVER['REQUEST_METHOD'] === 'POST'
        ? (is_array($_POST['document_presented'] ?? null) ? array_values(array_map('strval', $_POST['document_presented'])) : [])
        : $savedDocuments,
    'document_number' => trim((string) ($_POST['document_number'] ?? $anteMortem['document_number'] ?? '')),
];
$changeReason = trim((string) ($_POST['change_reason'] ?? ''));
$errors = [];
$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['document_presented'] = array_values(array_unique(array_filter(
        array_map('trim', $form['document_presented']),
        static fn(string $document): bool => in_array($document, $documentOptions, true)
    )));

    if ($form['no_of_heads'] === '' || $form['farm_owner'] === '' || $form['origin'] === '' || $form['category'] === '' || !$form['document_presented']) {
        $errors[] = 'Complete all required Ante-Mortem fields and select at least one document.';
    }
    if (!ctype_digit($form['no_of_heads']) || (int) $form['no_of_heads'] < 1) {
        $errors[] = 'Number of heads must be a whole number greater than zero.';
    }
    if (!array_key_exists($form['category'], $categoryOptions)) {
        $errors[] = 'Select a valid category.';
    }
    if ($changeReason === '') {
        $errors[] = 'Enter a reason for changing this Ante-Mortem record.';
    }

    if (!$errors) {
        $updatedAnteMortem = [
            'no_of_heads' => $form['no_of_heads'],
            'farm_owner' => $form['farm_owner'],
            'origin' => $form['origin'],
            'category' => $form['category'],
            'document_presented' => $form['document_presented'],
            'document_number' => $form['document_number'],
            'change_reason' => $changeReason,
            'changed_at' => date('Y-m-d H:i:s'),
        ];
        $updatedInspectionData = array_merge($inspectionData, ['ante_mortem' => $updatedAnteMortem]);
        $request = firebase_request_with_metadata('PATCH', 'inspections/' . $inspectionKey, [
            'inspection_data' => $updatedInspectionData,
        ]);

        if ($request['error'] === null && $request['status'] < 400) {
            record_activity_log('Edited Ante-Mortem record: ' . $changeReason, 'inspections/' . $inspectionKey);
            $inspectionData = $updatedInspectionData;
            $anteMortem = $updatedAnteMortem;
            $message = 'Ante-Mortem record updated successfully.';
        } else {
            $requestError = $request['error'] ?? ('Firebase request failed with HTTP ' . ($request['status'] ?? 'unknown status'));
            $errors[] = 'Unable to save the Ante-Mortem record. ' . $requestError;
        }
    }
}

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <main class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Edit Ante-Mortem Record</h3>
                <p class="text-secondary mb-0">Update the report for <?php echo htmlspecialchars($inspectionId); ?>.</p>
            </div>
            <a class="btn btn-outline-secondary" href="/admin/ante_mortem.php">
                <i class="fa-solid fa-arrow-left me-1"></i>Back to Records
            </a>
        </div>

        <?php if ($errors): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?><div><?php echo htmlspecialchars($error); ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

        <form method="post">
            <input type="hidden" name="inspection_id" value="<?php echo htmlspecialchars($inspectionId); ?>">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Customer / Code</label>
                            <input class="form-control" value="<?php echo htmlspecialchars(($customer['owner_code'] ?? $customer['customer_id'] ?? $inspection['customer_id'] ?? 'N/A') . ' / ' . ($customer['owner_name'] ?? $inspection['customer_name'] ?? 'N/A')); ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="no_of_heads">No. of Heads</label>
                            <input class="form-control" id="no_of_heads" name="no_of_heads" type="number" min="1" step="1" value="<?php echo htmlspecialchars($form['no_of_heads']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="farm_owner">Name of Farm / Farmer</label>
                            <input class="form-control" id="farm_owner" name="farm_owner" value="<?php echo htmlspecialchars($form['farm_owner']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="origin">Origin / Place</label>
                            <input class="form-control" id="origin" name="origin" value="<?php echo htmlspecialchars($form['origin']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="category">Category</label>
                            <select class="form-select" id="category" name="category" required>
                                <option value="">Select category</option>
                                <?php foreach ($categoryOptions as $code => $label): ?>
                                    <option value="<?php echo htmlspecialchars($code); ?>" <?php echo $form['category'] === $code ? 'selected' : ''; ?>><?php echo htmlspecialchars($label); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Document Presented</label>
                            <div class="document-presented-options d-flex flex-column gap-2">
                                <?php foreach ($documentOptions as $document): ?>
                                    <label class="form-check">
                                        <input class="form-check-input" type="checkbox" name="document_presented[]" value="<?php echo htmlspecialchars($document); ?>" <?php echo in_array($document, $form['document_presented'], true) ? 'checked' : ''; ?>>
                                        <span class="form-check-label"><?php echo htmlspecialchars($document); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <small class="form-text text-muted">Select at least one document.</small>
                            <label class="form-label mt-2" for="document_number">Document Number</label>
                            <input class="form-control" id="document_number" name="document_number" value="<?php echo htmlspecialchars($form['document_number']); ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label" for="change_reason">Reason for Change</label>
                            <textarea class="form-control" id="change_reason" name="change_reason" rows="3" maxlength="1000" required><?php echo htmlspecialchars($changeReason); ?></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <a class="btn btn-outline-secondary" href="/admin/ante_mortem.php">Cancel</a>
                        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk me-1"></i>Save Changes</button>
                    </div>
                </div>
            </div>
        </form>
    </main>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
