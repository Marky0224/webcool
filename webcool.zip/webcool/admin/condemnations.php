<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspections = array_values(array_filter(get_array_values(firebase_get('inspections')), 'is_array'));
$records = [];
foreach ($inspections as $inspection) {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    $condemnation = is_array($inspectionData['condemnation'] ?? null) ? $inspectionData['condemnation'] : null;
    if ($condemnation === null && !in_array($inspection['status'] ?? '', ['Condemned', 'Partially Condemned'], true)) {
        continue;
    }

    $recordedAt = trim((string) ($condemnation['recorded_at'] ?? ''));
    if ($recordedAt === '') {
        $recordedAt = trim((string) ($inspection['created_at'] ?? ''));
    }
    $customer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
    $records[] = [
        'inspection_id' => (string) ($inspection['inspection_id'] ?? 'N/A'),
        'customer_code' => (string) ($customer['owner_code'] ?? $customer['customer_id'] ?? $inspection['customer_id'] ?? 'N/A'),
        'customer_name' => (string) ($inspection['customer_name'] ?? $customer['owner_name'] ?? 'N/A'),
        'animal_type' => (string) ($condemnation['animal_type'] ?? 'N/A'),
        'part_affected' => (string) ($condemnation['part_affected'] ?? 'N/A'),
        'quantity' => $condemnation['quantity'] ?? 'N/A',
        'weight' => $condemnation['weight'] ?? 'N/A',
        'reason' => (string) ($condemnation['reason'] ?? 'N/A'),
        'remarks' => (string) ($condemnation['remarks'] ?? $inspection['final_remarks'] ?? 'N/A'),
        'inspector' => (string) ($condemnation['inspector'] ?? $inspection['inspector_name'] ?? 'N/A'),
        'recorded_at' => $recordedAt,
        'status' => ($condemnation['part_affected'] ?? '') === 'whole' ? 'Condemned' : 'Partially Condemned',
    ];
}

usort($records, static function (array $first, array $second): int {
    return strcmp($second['recorded_at'], $first['recorded_at']);
});

$totalRecords = count($records);
$wholeRecords = count(array_filter($records, static fn(array $record): bool => $record['status'] === 'Condemned'));
$partialRecords = count(array_filter($records, static fn(array $record): bool => $record['status'] === 'Partially Condemned'));
$totalWeight = array_sum(array_map(static function (array $record): float {
    return is_numeric($record['weight']) ? (float) $record['weight'] : 0.0;
}, $records));

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <main class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Condemnation Records</h3>
                <p class="text-secondary mb-0">
                    Showing condemnation decisions and findings from all dates.
                </p>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <?php foreach ([
                ['label' => 'Total Records', 'value' => (string) $totalRecords, 'icon' => 'fa-file-circle-exclamation'],
                ['label' => 'Whole Animal / Carcass', 'value' => (string) $wholeRecords, 'icon' => 'fa-skull-crossbones'],
                ['label' => 'Partially Condemned', 'value' => (string) $partialRecords, 'icon' => 'fa-triangle-exclamation'],
                ['label' => 'Total Weight (kg)', 'value' => number_format($totalWeight, 2), 'icon' => 'fa-weight-hanging'],
            ] as $card): ?>
                <div class="col-md-3">
                    <div class="card shadow-sm border-0 p-3">
                        <div class="text-muted mb-3"><i class="fa-solid <?php echo $card['icon']; ?> fa-lg"></i></div>
                        <h6 class="text-secondary mb-1"><?php echo htmlspecialchars($card['label']); ?></h6>
                        <h3 class="fw-bold mb-0"><?php echo $card['value']; ?></h3>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="mb-3">
                    <h5 class="card-title mb-1">Submitted Records</h5>
                    <p class="text-secondary mb-0">Detailed condemnation information from all dates.</p>
                </div>
                <div class="admin-record-controls">
                    <div class="admin-record-print no-print">
                        <button class="btn btn-sm print-button" type="button" onclick="window.print()">
                            <i class="fa-solid fa-print me-1"></i>Print
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover datatable align-middle mb-0" data-page-length="10">
                        <thead>
                            <tr>
                                <th>Inspection ID</th>
                                <th>Customer / Code</th>
                                <th>Animal / Part</th>
                                <th>Qty.</th>
                                <th>Weight (kg)</th>
                                <th>Reason</th>
                                <th>Findings / Remarks</th>
                                <th>Inspector</th>
                                <th>Date Recorded</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($record['inspection_id']); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($record['customer_name']); ?></strong>
                                        <small class="d-block text-secondary"><?php echo htmlspecialchars($record['customer_code']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars(ucfirst($record['animal_type']) . ' / ' . ucfirst($record['part_affected'])); ?></td>
                                    <td><?php echo htmlspecialchars((string) $record['quantity']); ?></td>
                                    <td><?php echo is_numeric($record['weight']) ? htmlspecialchars(number_format((float) $record['weight'], 2)) : htmlspecialchars((string) $record['weight']); ?></td>
                                    <td><?php echo htmlspecialchars($record['reason']); ?></td>
                                    <td><?php echo htmlspecialchars($record['remarks']); ?></td>
                                    <td><?php echo htmlspecialchars($record['inspector']); ?></td>
                                    <td><?php echo htmlspecialchars($record['recorded_at']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (!$records): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-secondary py-4">
                                        No condemnation records found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
