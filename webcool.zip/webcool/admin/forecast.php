<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$respond = static function (int $status, array $payload): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
};

$startService = false;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $startRequest = json_decode((string) file_get_contents('php://input'), true);
    $providedToken = is_array($startRequest) ? (string) ($startRequest['csrf_token'] ?? '') : '';
    $expectedToken = (string) ($_SESSION['forecast_csrf_token'] ?? '');
    if (
        !is_array($startRequest)
        || ($startRequest['action'] ?? '') !== 'start'
        || $expectedToken === ''
        || !hash_equals($expectedToken, $providedToken)
        || !hash_equals($expectedToken, (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))
    ) {
        $respond(403, ['error' => 'The forecast start request could not be verified. Reload the page and try again.']);
    }
    $startService = true;
} elseif (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    header('Allow: GET, POST');
    $respond(405, ['error' => 'This forecast request method is not supported.']);
}

$pythonUrl = trim((string) getenv('PYTHON_FORECAST_URL'));
if ($pythonUrl === '') {
    $pythonUrl = 'http://127.0.0.1:8001/forecast';
}
if (filter_var($pythonUrl, FILTER_VALIDATE_URL) === false) {
    error_log('Inspection forecast unavailable: PYTHON_FORECAST_URL is not a valid URL.');
    $respond(503, ['error' => 'The Python forecast service URL is invalid.']);
}

$urlParts = parse_url($pythonUrl);
if (!is_array($urlParts) || !in_array(strtolower((string) ($urlParts['scheme'] ?? '')), ['http', 'https'], true)) {
    error_log('Inspection forecast unavailable: PYTHON_FORECAST_URL must use HTTP or HTTPS.');
    $respond(503, ['error' => 'The Python forecast service URL must use HTTP or HTTPS.']);
}

if ($startService) {
    if ($pythonUrl !== 'http://127.0.0.1:8001/forecast') {
        $respond(503, ['error' => 'Automatic startup is only available for the default local forecast service.']);
    }
    if (PHP_OS_FAMILY !== 'Windows') {
        $respond(503, ['error' => 'Automatic forecast startup is configured for Windows only.']);
    }
    if (!function_exists('proc_open')) {
        error_log('Unable to start the Python forecast service: proc_open is unavailable.');
        $respond(503, ['error' => 'The server is not configured to start the forecast service.']);
    }

    $scriptPath = realpath(__DIR__ . '/../start_forecast.ps1');
    if ($scriptPath === false || !is_file($scriptPath)) {
        error_log('Unable to start the Python forecast service: start_forecast.ps1 was not found.');
        $respond(503, ['error' => 'The forecast startup script could not be found.']);
    }

    $systemRoot = getenv('SystemRoot');
    $powerShellPath = is_string($systemRoot) && $systemRoot !== ''
        ? $systemRoot . '\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
        : 'powershell.exe';
    $pipes = [];
    $process = @proc_open(
        [
            $powerShellPath,
            '-NoProfile',
            '-NonInteractive',
            '-ExecutionPolicy',
            'Bypass',
            '-File',
            $scriptPath,
        ],
        [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ],
        $pipes,
        dirname(__DIR__),
        null,
        ['bypass_shell' => true]
    );
    if (!is_resource($process)) {
        error_log('Unable to launch the Python forecast service startup script.');
        $respond(503, ['error' => 'The server could not launch the forecast service.']);
    }

    fclose($pipes[0]);
    $startupOutput = stream_get_contents($pipes[1]);
    fclose($pipes[1]);
    $startupError = stream_get_contents($pipes[2]);
    fclose($pipes[2]);
    $startupExitCode = proc_close($process);
    if ($startupExitCode !== 0) {
        $startupDetails = trim((string) ($startupError ?: $startupOutput));
        error_log('Forecast service startup failed: ' . ($startupDetails !== '' ? $startupDetails : 'PowerShell returned a non-zero exit code.'));
        $respond(503, [
            'error' => $startupDetails !== ''
                ? 'Forecast service startup failed: ' . substr($startupDetails, 0, 500)
                : 'Forecast service startup failed. Check the PHP error log for details.',
        ]);
    }
}

$requestBody = json_encode([
    'horizon' => 7,
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
if ($requestBody === false) {
    error_log('Unable to encode the forecast request for the Python service.');
    $respond(500, ['error' => 'Forecast input could not be prepared.']);
}

$headers = [
    'Content-Type: application/json',
    'Accept: application/json',
];
$pythonToken = trim((string) getenv('PYTHON_FORECAST_TOKEN'));
if ($pythonToken !== '') {
    $headers[] = 'Authorization: Bearer ' . $pythonToken;
}

$context = stream_context_create([
    'http' => [
        'method' => 'POST',
        'header' => implode("\r\n", $headers) . "\r\n",
        'content' => $requestBody,
        'timeout' => 15,
        'ignore_errors' => true,
    ],
]);
$transportWarning = null;
set_error_handler(static function (int $severity, string $message) use (&$transportWarning): bool {
    if (error_reporting() & $severity) {
        $transportWarning = $message;
        return true;
    }
    return false;
});
try {
    $pythonResponseBody = file_get_contents($pythonUrl, false, $context);
} finally {
    restore_error_handler();
}

if ($pythonResponseBody === false) {
    error_log('Python forecast request failed: ' . ($transportWarning ?? 'The service could not be reached.'));
    $respond(502, ['error' => 'The Python forecast service is offline. Click "Run forecast" to start it.']);
}

$pythonStatus = 0;
foreach ($http_response_header ?? [] as $responseHeader) {
    if (preg_match('/^HTTP\/\S+\s+(\d{3})/', $responseHeader, $matches)) {
        $pythonStatus = (int) $matches[1];
    }
}
if ($pythonStatus < 200 || $pythonStatus >= 300) {
    error_log('Python forecast service returned HTTP ' . $pythonStatus . '.');
    $respond(502, ['error' => 'The Python forecast service returned an error.']);
}

$modelResponse = json_decode($pythonResponseBody, true);
$history = is_array($modelResponse) ? ($modelResponse['history'] ?? null) : null;
$predictions = is_array($modelResponse) ? ($modelResponse['predictions'] ?? null) : null;
if (
    json_last_error() !== JSON_ERROR_NONE
    || !is_array($history)
    || count($history) !== 7
    || !is_array($predictions)
    || count($predictions) !== 7
) {
    error_log('Python forecast service returned an invalid response; expected seven monthly history values and predictions.');
    $respond(502, ['error' => 'The Python forecast response was invalid.']);
}

$validateMonthlyValues = static function (array $values): array {
    foreach ($values as $value) {
        if (
            !is_array($value)
            || !isset($value['date'])
            || !preg_match('/^\d{4}-\d{2}-01$/', (string) $value['date'])
            || !isset($value['count'])
            || !is_numeric($value['count'])
            || !is_finite((float) $value['count'])
            || (float) $value['count'] < 0
        ) {
            return [];
        }
    }

    return array_values($values);
};

$history = $validateMonthlyValues($history);
$predictions = $validateMonthlyValues($predictions);
if (count($history) !== 7 || count($predictions) !== 7) {
    error_log('Python forecast service returned invalid monthly dates or volume values.');
    $respond(502, ['error' => 'The Python forecast response contained invalid monthly data.']);
}

$respond(200, [
    'history' => $history,
    'predictions' => $predictions,
]);
