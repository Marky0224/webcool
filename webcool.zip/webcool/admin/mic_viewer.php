<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectionsRaw = firebase_get('inspections');
$recentInspections = array_values(array_filter(get_array_values($inspectionsRaw), 'is_array'));
usort($recentInspections, static function (array $first, array $second): int {
    $firstDate = (string) ($first['created_at'] ?? $first['inspection_date'] ?? '');
    $secondDate = (string) ($second['created_at'] ?? $second['inspection_date'] ?? '');
    return strcmp($secondDate, $firstDate);
});
$savedCertificates = array_values(array_filter(get_array_values(firebase_get('certificates')), 'is_array'));
$micRecordIds = [];
foreach ($recentInspections as $index => $inspection) {
    if (($inspection['status'] ?? '') !== 'MIC' && empty($inspection['certificate_id'])) {
        continue;
    }
    $recordId = !empty($inspection['certificate_id'])
        ? 'certificate:' . (string) $inspection['certificate_id']
        : (!empty($inspection['inspection_id'])
            ? 'inspection:' . (string) $inspection['inspection_id']
            : 'inspection-record:' . $index);
    $micRecordIds[$recordId] = true;
}
foreach ($savedCertificates as $index => $certificate) {
    $recordId = !empty($certificate['certificate_id'])
        ? 'certificate:' . (string) $certificate['certificate_id']
        : (!empty($certificate['inspection_id'])
            ? 'inspection:' . (string) $certificate['inspection_id']
            : 'saved-certificate:' . $index);
    $micRecordIds[$recordId] = true;
}
$summary = [
    'total' => count($micRecordIds),
];

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">MIC Viewer</h3>
                <p class="text-secondary mb-0">Review recent inspections and the total number of issued MIC records across all dates.</p>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <?php foreach ([
                ['label' => 'Total MIC Records', 'value' => $summary['total'], 'icon' => 'fa-database'],
            ] as $card) { ?>
                <div class="col-md-6 col-xl-3">
                    <div class="card shadow-sm border-0 p-3">
                        <div class="text-muted mb-3"><i class="fa-solid <?php echo $card['icon']; ?> fa-lg"></i></div>
                        <h6 class="text-secondary mb-1"><?php echo $card['label']; ?></h6>
                        <h3 class="fw-bold"><?php echo $card['value']; ?></h3>
                    </div>
                </div>
            <?php } ?>
        </div>

        <div class="card shadow-sm border-0 mt-4">
            <div class="card-body">
                    
                <div class="table-responsive">
                    <table class="table table-striped table-hover datatable align-middle mb-0" data-page-length="15">
                        <thead>
                            <tr>
                                <th>Inspection ID</th>
                                <th>Owner Name</th>
                                <th>Animal Type</th>
                                <th>Heads</th>
                                <th>Weight (kg)</th>
                                <th>Inspector</th>
                                <th>Date Submitted</th>
                                <th>Reason for Editing</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentInspections as $inspection):
                                $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
                                $customerData = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
                                $meatDetails = is_array($inspectionData['meat_details'] ?? null) ? $inspectionData['meat_details'] : [];
                                $heads = (int) ($inspection['head_count'] ?? $inspectionData['meat_summary']['no_of_heads'] ?? 0);
                                $totalWeight = 0.0;
                                foreach ($meatDetails as $detail) {
                                    if (!is_array($detail)) {
                                        continue;
                                    }
                                    $heads += (int) ($detail['qty'] ?? 0);
                                    $totalWeight += (float) ($detail['weight'] ?? 0);
                                }
                                $animalType = $customerData['animal_type'] ?? $inspectionData['mic']['animal_type'] ?? 'N/A';
                                $inspectionId = (string) ($inspection['inspection_id'] ?? '');
                                $submittedAt = (string) ($inspection['created_at'] ?? $inspection['inspection_date'] ?? 'N/A');
                                $editReason = trim((string) ($inspectionData['mic_edit_reason'] ?? ''));
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($inspectionId !== '' ? $inspectionId : 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($inspection['customer_name'] ?? $customerData['owner_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($animalType); ?></td>
                                    <td><?php echo htmlspecialchars((string) $heads); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($totalWeight, 2)); ?></td>
                                    <td><?php echo htmlspecialchars($inspection['inspector_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($submittedAt); ?></td>
                                    <td><?php echo htmlspecialchars($editReason !== '' ? $editReason : '—'); ?></td>
                                    <td>
                                        <?php if ($inspectionId !== ''): ?>
                                            <a class="btn btn-sm btn-outline-primary" href="/admin/mic_certificate.php?inspection_id=<?php echo urlencode($inspectionId); ?>">View</a>
                                            <a class="btn btn-sm btn-outline-secondary" href="/admin/mic_edit.php?inspection_id=<?php echo urlencode($inspectionId); ?>">Edit</a>
                                        <?php else: ?>
                                            <span class="text-secondary">Unavailable</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
