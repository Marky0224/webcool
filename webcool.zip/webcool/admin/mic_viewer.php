<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectionsRaw = firebase_get('inspections');
$inspections = array_values(array_filter(get_array_values($inspectionsRaw), fn($item) => is_array($item) && ($item['status'] ?? '') === 'MIC'));
$summary = [
    'total' => count($inspections),
    'accepted' => 0,
    'rejected' => 0,
];

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">MIC Viewer</h3>
                <p class="text-secondary mb-0">Saved inspection records are compiled here for quick review and management.</p>
            </div>
            <a href="/admin/dashboard.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-2"></i>Back to Dashboard</a>
        </div>

        <div class="row g-3 mb-4">
            <?php foreach ([
                ['label' => 'Total MIC Records', 'value' => $summary['total'], 'icon' => 'fa-database', 'color' => 'primary'],
                ['label' => 'Accepted', 'value' => $summary['accepted'], 'icon' => 'fa-check-circle', 'color' => 'success'],
                ['label' => 'Rejected', 'value' => $summary['rejected'], 'icon' => 'fa-ban', 'color' => 'danger'],
            ] as $card) { ?>
                <div class="col-md-6 col-xl-3">
                    <div class="card shadow-sm border-0 p-3">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="text-muted"><i class="fa-solid <?php echo $card['icon']; ?> fa-lg"></i></div>
                            <span class="badge bg-<?php echo $card['color']; ?>-light text-<?php echo $card['color']; ?>"><?php echo $card['value']; ?></span>
                        </div>
                        <h6 class="text-secondary mb-1"><?php echo $card['label']; ?></h6>
                        <h3 class="fw-bold"><?php echo $card['value']; ?></h3>
                    </div>
                </div>
            <?php } ?>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h5 class="card-title mb-3">Compiled MIC Records</h5>
                <div class="table-responsive">
                    <table class="table table-striped table-hover datatable mb-0" data-certificate-number="true">
                        <thead>
                            <tr>
                                <th>Inspection ID</th>
                                <th>Certificate #</th>
                                <th>Customer</th>
                                <th>Inspector</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($inspections as $index => $inspection): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($inspection['inspection_id'] ?? 'N/A'); ?></td>
                                    <td class="certificate-number"><?php echo $index + 1; ?></td>
                                    <td><?php echo htmlspecialchars($inspection['customer_name'] ?? $inspection['customer_id'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($inspection['inspector_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($inspection['inspection_date'] ?? $inspection['created_at'] ?? 'N/A'); ?></td>
                                    <td>
                                        <a href="/admin/mic_certificate.php?inspection_id=<?php echo urlencode($inspection['inspection_id'] ?? ''); ?>" class="btn btn-sm btn-outline-primary">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
