<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

if (empty($_SESSION['mic_delete_csrf_token'])) {
    $_SESSION['mic_delete_csrf_token'] = bin2hex(random_bytes(32));
}
$micDeleteCsrfToken = (string) $_SESSION['mic_delete_csrf_token'];
$deleteMessage = null;
$deleteError = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_mic') {
    $submittedToken = (string) ($_POST['csrf_token'] ?? '');
    $inspectionIdToDelete = trim((string) ($_POST['inspection_id'] ?? ''));
    if ($submittedToken === '' || !hash_equals($micDeleteCsrfToken, $submittedToken)) {
        $deleteError = 'Unable to delete the MIC because the security token is invalid.';
    } elseif ($inspectionIdToDelete === '') {
        $deleteError = 'Unable to delete the MIC because its inspection ID is missing.';
    } else {
        $inspectionRecords = firebase_get('inspections');
        $certificateRecords = firebase_get('certificates');
        $deletedPaths = [];

        foreach (is_array($inspectionRecords) ? $inspectionRecords : [] as $key => $inspection) {
            if (
                is_array($inspection)
                && (
                    (string) ($inspection['inspection_id'] ?? '') === $inspectionIdToDelete
                    || (string) ($inspection['certificate_id'] ?? '') === $inspectionIdToDelete
                )
            ) {
                $deletedPaths[] = 'inspections/' . $key;
            }
        }
        foreach (is_array($certificateRecords) ? $certificateRecords : [] as $key => $certificate) {
            if (
                is_array($certificate)
                && (
                    (string) ($certificate['inspection_id'] ?? '') === $inspectionIdToDelete
                    || (string) ($certificate['certificate_id'] ?? '') === $inspectionIdToDelete
                )
            ) {
                $deletedPaths[] = 'certificates/' . $key;
            }
        }

        if ($deletedPaths !== []) {
            foreach ($deletedPaths as $path) {
                $deleteRequest = firebase_request_with_metadata('DELETE', $path);
                if ($deleteRequest['error'] !== null || $deleteRequest['status'] >= 400) {
                    $deleteError = 'Unable to delete the MIC record. Please try again.';
                    break;
                }
            }
            if ($deleteError === null) {
                record_activity_log('Deleted MIC: ' . $inspectionIdToDelete, 'inspections');
                $deleteMessage = 'MIC record ' . $inspectionIdToDelete . ' was deleted successfully.';
            }
        }
    }
}

$inspectionsRaw = firebase_get('inspections');
$recentInspections = array_values(array_filter(get_array_values($inspectionsRaw), 'is_array'));
usort($recentInspections, static function (array $first, array $second): int {
    $firstDate = (string) ($first['created_at'] ?? $first['inspection_date'] ?? '');
    $secondDate = (string) ($second['created_at'] ?? $second['inspection_date'] ?? '');
    return strcmp($secondDate, $firstDate);
});
$savedCertificates = array_values(array_filter(get_array_values(firebase_get('certificates')), 'is_array'));
$micInspections = array_values(array_filter($recentInspections, static function (array $inspection): bool {
    return ($inspection['status'] ?? '') === 'MIC' || !empty($inspection['certificate_id']);
}));
$micRows = [];
$micRowKeys = [];
foreach ($micInspections as $inspection) {
    $inspectionId = (string) ($inspection['inspection_id'] ?? '');
    $certificateId = (string) ($inspection['certificate_id'] ?? '');
    $rowKey = $inspectionId !== '' ? 'inspection:' . $inspectionId : 'certificate:' . $certificateId;
    $micRows[] = $inspection;
    $micRowKeys[$rowKey] = count($micRows) - 1;
    if ($certificateId !== '') {
        $micRowKeys['certificate:' . $certificateId] = count($micRows) - 1;
    }
}
foreach ($savedCertificates as $certificate) {
    $inspectionId = (string) ($certificate['inspection_id'] ?? '');
    $certificateId = (string) ($certificate['certificate_id'] ?? '');
    $inspectionKey = $inspectionId !== '' ? 'inspection:' . $inspectionId : '';
    $certificateKey = $certificateId !== '' ? 'certificate:' . $certificateId : '';
    $rowKey = isset($micRowKeys[$inspectionKey]) ? $inspectionKey : $certificateKey;
    if (isset($micRowKeys[$rowKey])) {
        $rowIndex = $micRowKeys[$rowKey];
        $existingData = is_array($micRows[$rowIndex]['inspection_data'] ?? null) ? $micRows[$rowIndex]['inspection_data'] : [];
        $certificateData = is_array($certificate['inspection_data'] ?? null) ? $certificate['inspection_data'] : [];
        $micRows[$rowIndex] = array_merge($micRows[$rowIndex], $certificate, [
            'inspection_data' => array_merge($existingData, $certificateData),
        ]);
    } else {
        $micRows[] = $certificate;
        $micRowKeys[$rowKey] = count($micRows) - 1;
    }
}
$micInspections = $micRows;
$summary = [
    'total' => count($micInspections),
];

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <?php if ($deleteMessage !== null): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($deleteMessage); ?></div>
        <?php elseif ($deleteError !== null): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($deleteError); ?></div>
        <?php endif; ?>
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">MIC Viewer</h3>
                <p class="text-secondary mb-0">Review recent inspections and the total number of issued MIC records across all dates.</p>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <?php foreach ([
                ['label' => 'Total MIC Records', 'value' => $summary['total'], 'icon' => 'fa-database'],
            ] as $card) { ?>
                <div class="col-md-6 col-xl-3">
                    <div class="card shadow-sm border-0 p-3">
                        <div class="text-muted mb-3"><i class="fa-solid <?php echo $card['icon']; ?> fa-lg"></i></div>
                        <h6 class="text-secondary mb-1"><?php echo $card['label']; ?></h6>
                        <h3 class="fw-bold"><?php echo $card['value']; ?></h3>
                    </div>
                </div>
            <?php } ?>
        </div>

        <div class="card shadow-sm border-0 mt-4">
            <div class="card-body">
                <div class="admin-record-controls">
                    <div class="admin-record-print no-print">
                        <button class="btn btn-sm print-button" type="button" onclick="window.print()">
                            <i class="fa-solid fa-print me-1"></i>Print
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover datatable align-middle mb-0" data-page-length="10">
                        <thead>
                            <tr>
                                <th>Inspection ID</th>
                                <th>Owner Name</th>
                                <th>Animal Type</th>
                                <th>Heads</th>
                                <th>Weight (kg)</th>
                                <th>Inspector</th>
                                <th>Date Submitted</th>
                                <th>Reason for Editing</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($micInspections as $inspection):
                                $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
                                $customerData = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
                                $meatDetails = is_array($inspectionData['meat_details'] ?? null) ? $inspectionData['meat_details'] : [];
                                $heads = (int) ($inspection['head_count'] ?? $inspectionData['meat_summary']['no_of_heads'] ?? 0);
                                $totalWeight = 0.0;
                                foreach ($meatDetails as $detail) {
                                    if (!is_array($detail)) {
                                        continue;
                                    }
                                    $heads += (int) ($detail['qty'] ?? 0);
                                    $totalWeight += (float) ($detail['weight'] ?? 0);
                                }
                                $animalType = $customerData['animal_type'] ?? $inspectionData['mic']['animal_type'] ?? 'N/A';
                                $recordInspectionId = (string) ($inspection['inspection_id'] ?? '');
                                $inspectionId = (string) ($inspection['certificate_id'] ?? $recordInspectionId);
                                $submittedAt = (string) ($inspection['created_at'] ?? $inspection['inspection_date'] ?? 'N/A');
                                $editReason = trim((string) ($inspectionData['mic_edit_reason'] ?? ''));
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($inspectionId !== '' ? $inspectionId : 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($inspection['customer_name'] ?? $customerData['owner_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($animalType); ?></td>
                                    <td><?php echo htmlspecialchars((string) $heads); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($totalWeight, 2)); ?></td>
                                    <td><?php echo htmlspecialchars($inspection['inspector_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($submittedAt); ?></td>
                                    <td><?php echo htmlspecialchars($editReason !== '' ? $editReason : '—'); ?></td>
                                    <td>
                                        <?php if ($recordInspectionId !== ''): ?>
                                            <a class="btn btn-sm btn-outline-primary" href="/admin/mic_certificate.php?inspection_id=<?php echo urlencode($recordInspectionId); ?>">View</a>
                                            <a class="btn btn-sm btn-outline-secondary" href="/admin/mic_edit.php?inspection_id=<?php echo urlencode($recordInspectionId); ?>">Edit</a>
                                            <form method="post" class="d-inline" onsubmit="return window.confirm('Delete MIC <?php echo htmlspecialchars($inspectionId, ENT_QUOTES, 'UTF-8'); ?>? This action cannot be undone.');">
                                                <input type="hidden" name="action" value="delete_mic">
                                                <input type="hidden" name="inspection_id" value="<?php echo htmlspecialchars($recordInspectionId, ENT_QUOTES, 'UTF-8'); ?>">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($micDeleteCsrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-secondary">Unavailable</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
