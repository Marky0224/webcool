<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectionId = trim((string) ($_GET['inspection_id'] ?? ''));
$inspections = firebase_get('inspections');
$inspection = null;
foreach (is_array($inspections) ? $inspections : [] as $item) {
    if (is_array($item) && (string) ($item['inspection_id'] ?? '') === $inspectionId) {
        $inspection = $item;
        break;
    }
}

if ($inspection === null) {
    http_response_code(404);
    exit('Ante-Mortem inspection record not found.');
}

$inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
$anteMortem = is_array($inspectionData['ante_mortem'] ?? null) ? $inspectionData['ante_mortem'] : [];
$customer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
$recordDate = trim((string) ($inspection['inspection_date'] ?? $inspection['created_at'] ?? ''));
$recordDate = substr($recordDate, 0, 10);
$parsedRecordDate = DateTime::createFromFormat('!Y-m-d', $recordDate);
$documentPresentedValue = $anteMortem['document_presented'] ?? $inspection['document_presented'] ?? [];
$documentPresented = is_array($documentPresentedValue)
    ? implode(', ', array_map(static fn($document): string => get_ante_mortem_document_label((string) $document), $documentPresentedValue))
    : get_ante_mortem_document_label((string) $documentPresentedValue);

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <main class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">View Ante-Mortem Record</h3>
                <p class="text-secondary mb-0">Review the submitted inspection details for <?php echo htmlspecialchars($inspectionId); ?>.</p>
            </div>
            <div class="d-flex gap-2">
                <a class="btn btn-outline-secondary" href="/admin/ante_mortem.php">
                    <i class="fa-solid fa-arrow-left me-1"></i>Back to Records
                </a>
                <a class="btn btn-outline-primary" href="/admin/ante_mortem_edit.php?inspection_id=<?php echo urlencode($inspectionId); ?>">
                    <i class="fa-solid fa-pen-to-square me-1"></i>Edit
                </a>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-md-4">Inspection ID</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars($inspectionId !== '' ? $inspectionId : 'N/A'); ?></dd>
                    <dt class="col-md-4">Date</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars($parsedRecordDate && $parsedRecordDate->format('Y-m-d') === $recordDate ? $parsedRecordDate->format('M d, Y') : 'N/A'); ?></dd>
                    <dt class="col-md-4">Owner / Code</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars(($customer['owner_code'] ?? $customer['customer_id'] ?? $inspection['customer_id'] ?? 'N/A') . ' / ' . ($customer['owner_name'] ?? $inspection['customer_name'] ?? 'N/A')); ?></dd>
                    <dt class="col-md-4">No. of Heads</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars((string) ($anteMortem['no_of_heads'] ?? $inspection['no_of_heads'] ?? $inspection['head_count'] ?? $inspectionData['head_count'] ?? $inspectionData['meat_summary']['no_of_heads'] ?? 'N/A')); ?></dd>
                    <dt class="col-md-4">Name of Farm / Farmer</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars((string) ($anteMortem['farm_owner'] ?? $inspection['farm_owner'] ?? 'N/A')); ?></dd>
                    <dt class="col-md-4">Origin / Place</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars((string) ($anteMortem['origin'] ?? $inspection['origin'] ?? 'N/A')); ?></dd>
                    <dt class="col-md-4">Category</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars(get_ante_mortem_category_code((string) ($anteMortem['category'] ?? $inspection['category'] ?? 'N/A'))); ?></dd>
                    <dt class="col-md-4">Document Presented</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars($documentPresented !== '' ? $documentPresented : 'N/A'); ?></dd>
                    <?php $documentNumber = trim((string) ($anteMortem['document_number'] ?? $inspection['document_number'] ?? '')); ?>
                    <?php if ($documentNumber !== ''): ?>
                        <dt class="col-md-4">Document Number</dt>
                        <dd class="col-md-8"><?php echo htmlspecialchars($documentNumber); ?></dd>
                    <?php endif; ?>
                    <dt class="col-md-4">Inspector</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars((string) ($inspection['inspector_name'] ?? 'N/A')); ?></dd>
                    <dt class="col-md-4">Reason for Edit</dt>
                    <dd class="col-md-8"><?php echo htmlspecialchars((string) ($anteMortem['change_reason'] ?? '—')); ?></dd>
                </dl>
            </div>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
