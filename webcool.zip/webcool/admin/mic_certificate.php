<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectionId = trim((string) ($_GET['inspection_id'] ?? ''));
$inspectionsRaw = firebase_get('inspections');
$inspection = null;
foreach (is_array($inspectionsRaw) ? $inspectionsRaw : [] as $item) {
    if (is_array($item) && ($item['inspection_id'] ?? '') === $inspectionId) {
        $inspection = $item;
        break;
    }
}

if (!$inspection) {
    header('Location: /admin/mic_viewer.php');
    exit;
}

$registrations = get_array_values(firebase_get('client_registrations'));
$registration = is_array($inspection['inspection_data']['customer'] ?? null)
    ? $inspection['inspection_data']['customer']
    : null;
foreach ($registrations as $regItem) {
    if (!is_array($regItem)) {
        continue;
    }
    if (!empty($inspection['registration_key']) && ($regItem['registration_key'] ?? '') === $inspection['registration_key']) {
        $registration = $regItem;
        break;
    }
    if (!empty($inspection['registration_id']) && ($regItem['inspection_id'] ?? '') === $inspection['registration_id']) {
        $registration = $regItem;
        break;
    }
}
$inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
$controlNumber = trim((string) ($inspection['control_number'] ?? $inspectionData['control_number'] ?? ''));
$certificateRecords = [[
    'inspection' => $inspection,
    'inspection_data' => $inspectionData,
    'registration' => is_array($registration) ? $registration : [],
    'control_number' => $controlNumber,
    'owner_dealer' => (string) ($inspectionData['owner_dealer'] ?? $registration['owner_name'] ?? $inspection['customer_name'] ?? ''),
    'date_issued' => (string) ($inspectionData['date_issued'] ?? $inspection['inspection_date'] ?? substr((string) ($inspection['created_at'] ?? ''), 0, 10)),
    'time_issued' => (string) ($inspectionData['time_issued'] ?? ''),
]];
$downloadInspectionId = $inspectionId;

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content mic-certificate-print-page">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4 no-print">
            <div>
                <h3 class="mb-1">MIC Certificate</h3>
                <p class="text-secondary mb-0">View the MIC form, scan the QR, and print or download it as PDF.</p>
            </div>
            <div class="d-flex gap-2 no-print">
                <a href="/admin/mic_viewer.php" class="btn btn-outline-secondary">Back to MIC Viewer</a>
                <button class="btn btn-primary" onclick="window.print();"><i class="fa-solid fa-print me-2"></i>Print</button>
                <button class="btn btn-success" onclick="downloadCertificatePdf();"><i class="fa-solid fa-download me-2"></i>Download PDF</button>
            </div>
        </div>

            <div class="certificate-preview-card certificate-admin-view" id="certificate">
                <div class="certificate-print-copies">
                    <?php foreach ($certificateRecords as $record):
                        $inspection = $record['inspection'];
                        $inspectionData = $record['inspection_data'];
                        $registration = $record['registration'];
                        $meatDetails = is_array($inspectionData['meat_details'] ?? null) ? $inspectionData['meat_details'] : [];
                        $ownerDealer = $record['owner_dealer'];
                        if ($ownerDealer === '' && !empty($inspectionData['customer']['owner_name'])) {
                            $ownerDealer = (string) $inspectionData['customer']['owner_name'];
                        }
                        $dateIssued = $record['date_issued'];
                        $timeIssued = $record['time_issued'] !== ''
                            ? $record['time_issued']
                            : (string) ($inspectionData['customer']['time_issued'] ?? '');
                        $currentInspectionId = (string) ($inspection['inspection_id'] ?? '');
                    ?>
                        <article class="certificate-preview-paper" data-inspection-id="<?php echo htmlspecialchars($currentInspectionId, ENT_QUOTES, 'UTF-8'); ?>">
                            <header class="certificate-letterhead">
                                <div class="certificate-letterhead-top">
                                    <img src="/assets/images/lipa-city-seal.png" alt="City of Lipa official seal">
                                    <p>Republic of the Philippines<br>City of Lipa</p>
                                    <img src="/assets/images/lipa-veterinary-office-seal.png" alt="Lipa City Veterinary Office seal">
                                </div>
                                <h1>OFFICE OF THE CITY VETERINARIAN</h1>
                                <p class="certificate-control-number"><strong>CN:</strong> <?php echo htmlspecialchars($record['control_number'] !== '' ? $record['control_number'] : '________'); ?></p>
                                <p class="certificate-inspection-id"><strong>Inspection ID:</strong> <?php echo htmlspecialchars($currentInspectionId); ?></p>
                                <p class="certificate-letterhead-office">LIPA CITY SLAUGHTERHOUSE</p>
                                <p class="certificate-letterhead-accreditation">NMIS ACCREDITATION NO. SH-989-AAA</p>
                            </header>
                            <h2>MEAT INSPECTION CERTIFICATE</h2>
                            <p>This certifies that meat/meat by products described below are slaughtered in accordance with the Meat Inspection Code of the Philippines and at the time and date of inspection are found fit for human consumption.</p>
                            <table class="certificate-table w-100 text-uppercase">
                                <thead>
                                    <tr>
                                        <th style="width: 50%;">Type of Meat/Entrails</th>
                                        <th style="width: 25%;">Quantity</th>
                                        <th style="width: 25%;">Weight</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (['PORK' => 'pork', 'BEEF' => 'beef', 'CARABEEF' => 'carabeef', 'ENTRAILS' => 'entrails'] as $label => $key):
                                        $qty = $meatDetails[$key]['qty'] ?? ($inspection['qty_' . $key] ?? '');
                                        $weight = $meatDetails[$key]['weight'] ?? ($inspection['weight_' . $key] ?? '');
                                    ?>
                                        <tr>
                                            <td class="fw-semibold"><?php echo $label; ?></td>
                                            <td><?php echo htmlspecialchars((string) ($qty !== '' ? $qty : 'hd/s')); ?></td>
                                            <td><?php echo htmlspecialchars((string) ($weight !== '' ? $weight : 'kls.')); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <dl>
                                <dt>Name of Owner (Dealer)</dt><dd><?php echo htmlspecialchars($ownerDealer); ?></dd>
                                <dt>Point of Origin</dt><dd>FMIMC</dd>
                                <dt>Destination</dt><dd>Lipa</dd>
                                <dt>Time Issued</dt><dd><?php echo htmlspecialchars($timeIssued); ?></dd>
                                <dt>Date Issued</dt><dd><?php echo htmlspecialchars($dateIssued); ?></dd>
                            </dl>
                            <div class="certificate-preview-signatures"><span>Owner/Dealer</span><span>Meat Inspector</span></div>
                            <div class="certificate-preview-qr">
                                <img src="<?php echo htmlspecialchars(inspection_qr_url($currentInspectionId)); ?>" alt="QR code for inspection <?php echo htmlspecialchars($currentInspectionId); ?>">
                                <span>Scan to verify inspection</span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js"></script>
<script>
function downloadCertificatePdf() {
    const element = document.getElementById('certificate');
    const firstCertificate = element ? element.querySelector('.certificate-preview-paper') : null;
    if (!firstCertificate) {
        return;
    }
    const opt = {
        margin: 0.5,
        filename: 'MIC-<?php echo addslashes($downloadInspectionId); ?>.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(firstCertificate).save();
}
</script>
