<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectionId = $_GET['inspection_id'] ?? '';
$inspection = null;
$inspectionsRaw = firebase_get('inspections');
$inspections = is_array($inspectionsRaw) ? $inspectionsRaw : [];
$inspectionKey = null;

foreach ($inspections as $key => $item) {
    if (!empty($item['inspection_id']) && $item['inspection_id'] === $inspectionId) {
        $inspection = $item;
        $inspectionKey = $key;
        break;
    }
}

if (!$inspection) {
    header('Location: /admin/mic_viewer.php');
    exit;
}

$registration = null;
$registrations = get_array_values(firebase_get('client_registrations'));
foreach ($registrations as $regItem) {
    if (!empty($inspection['registration_key']) && ($regItem['registration_key'] ?? '') === $inspection['registration_key']) {
        $registration = $regItem;
        break;
    }
    if (!empty($inspection['registration_id']) && !empty($regItem['inspection_id']) && $regItem['inspection_id'] === $inspection['registration_id']) {
        $registration = $regItem;
        break;
    }
}

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">MIC Certificate</h3>
                <p class="text-secondary mb-0">View the MIC form, scan the QR, and print or download it as PDF.</p>
            </div>
            <div class="d-flex gap-2 no-print">
                <a href="/admin/mic_viewer.php" class="btn btn-outline-secondary">Back to MIC Viewer</a>
                <button class="btn btn-primary" onclick="window.print();"><i class="fa-solid fa-print me-2"></i>Print</button>
                <button class="btn btn-success" onclick="downloadCertificatePdf();"><i class="fa-solid fa-download me-2"></i>Download PDF</button>
            </div>
        </div>

        <style>
            .certificate-card { max-width: 900px; margin: 0 auto; }
            .certificate-header p { margin: 0; }
            .certificate-title { font-size: 1.1rem; letter-spacing: 0.25rem; font-weight: 700; }
            .certificate-subtitle { font-size: 0.95rem; }
            .certificate-body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
            .certificate-table th, .certificate-table td { border: 1px solid #000; vertical-align: middle; }
            .certificate-table th { font-weight: 700; }
            .certificate-line { border-bottom: 1px solid #000; min-height: 1.5rem; }
            .certificate-field { padding: 0.6rem 0; }
            .certificate-label { font-weight: 600; }
            .certificate-footer span { display: block; }
            .no-print { display: flex; gap: 0.75rem; }
            @media print {
                .no-print { display: none !important; }
            }
        </style>

        <div class="card shadow-sm border-0 certificate-card" id="certificate">
            <div class="card-body p-5 certificate-body">
                <div class="row certificate-header mb-4">
                    <div class="col-md-8">
                        <p class="text-uppercase fw-semibold mb-1">Republic of the Philippines</p>
                        <p class="fw-semibold mb-1">City of Lipa</p>
                        <p class="display-6 fw-bold mb-1">Office of the City Veterinarian</p>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <p class="fw-semibold mb-1">CN:</p>
                        <p class="certificate-line"><?php echo htmlspecialchars($inspection['certificate_id'] ?? ''); ?></p>
                    </div>
                </div>

                <div class="text-center mb-4">
                    <p class="fw-semibold mb-1">Lipa City Slaughterhouse</p>
                    <p class="text-uppercase fw-semibold mb-1">NMIS Accreditation No. SH-989-AA</p>
                    <p class="h4 fw-bold mb-3">Meat Inspection Certificate</p>
                    <p class="text-secondary">This certifies that meat/meat by-products described below are slaughtered in accordance with the Meat Inspection Code of the Philippines and are at the time and date of inspection found fit for human consumption.</p>
                </div>

                <?php
                $meatDetails = $inspection['inspection_data']['meat_details'] ?? [];
                $ownerDealer = $inspection['inspection_data']['owner_dealer'] ?? $registration['owner_name'] ?? $inspection['customer_name'] ?? '';
                if (empty($ownerDealer) && !empty($inspection['inspection_data']['customer']['owner_name'])) {
                    $ownerDealer = $inspection['inspection_data']['customer']['owner_name'];
                }
                $origin = $inspection['inspection_data']['origin'] ?? $inspection['customer_origin'] ?? $inspection['inspection_data']['customer']['origin'] ?? $registration['origin'] ?? 'FMIMC';
                $destination = $inspection['inspection_data']['destination'] ?? $inspection['destination'] ?? 'LIPA CITY';
                if (empty($destination) && !empty($inspection['inspection_data']['customer']['destination'])) {
                    $destination = $inspection['inspection_data']['customer']['destination'];
                }
                $dateIssued = $inspection['inspection_data']['date_issued'] ?? $inspection['inspection_date'] ?? substr($inspection['created_at'] ?? '', 0, 10);
                $timeIssued = $inspection['inspection_data']['time_issued'] ?? '';
                if (empty($timeIssued) && !empty($inspection['inspection_data']['customer']['time_issued'])) {
                    $timeIssued = $inspection['inspection_data']['customer']['time_issued'];
                }
                ?>
                <div class="table-responsive mb-4">
                    <table class="table certificate-table w-100 text-uppercase">
                        <thead>
                            <tr>
                                <th style="width: 50%;">Type of Meat/Entrails</th>
                                <th style="width: 25%;">Quantity</th>
                                <th style="width: 25%;">Weight</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $meatTypes = [
                                'PORK' => 'pork',
                                'BEEF' => 'beef',
                                'CARABEEF' => 'carabeef',
                                'ENTRAILS' => 'entrails',
                            ];
                            foreach ($meatTypes as $label => $key):
                                $qty = $meatDetails[$key]['qty'] ?? ($inspection['qty_' . $key] ?? '');
                                $weight = $meatDetails[$key]['weight'] ?? ($inspection['weight_' . $key] ?? '');
                            ?>
                                <tr>
                                    <td class="fw-semibold"><?php echo $label; ?></td>
                                    <td><?php echo htmlspecialchars($qty !== '' ? $qty : 'hd/s'); ?></td>
                                    <td><?php echo htmlspecialchars($weight !== '' ? $weight : 'kls.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6 certificate-field">
                        <span class="certificate-label">Name of Owner (Dealer):</span>
                        <span class="certificate-line"><?php echo htmlspecialchars($ownerDealer); ?></span>
                    </div>
                    <div class="col-md-6 certificate-field">
                        <span class="certificate-label">Point of Origin:</span>
                        <span class="certificate-line"><?php echo htmlspecialchars($origin); ?></span>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6 certificate-field">
                        <span class="certificate-label">Destination:</span>
                        <span class="certificate-line"><?php echo htmlspecialchars($destination); ?></span>
                    </div>
                    <div class="col-md-3 certificate-field">
                        <span class="certificate-label">Time Issued:</span>
                        <span class="certificate-line"><?php echo htmlspecialchars($timeIssued); ?></span>
                    </div>
                    <div class="col-md-3 certificate-field">
                        <span class="certificate-label">Date Issued:</span>
                        <span class="certificate-line"><?php echo htmlspecialchars($dateIssued); ?></span>
                    </div>
                </div>

                <div class="row mb-5">
                    <div class="col-md-12 certificate-field">
                        <span class="certificate-label">Received by:</span>
                        <span class="certificate-line">&nbsp;</span>
                    </div>
                </div>

                <div class="row justify-content-between mt-5 pt-4">
                    <div class="col-md-6 text-center">
                        <div class="certificate-line mb-2"></div>
                        <span>Owner/Dealer</span>
                    </div>
                    <div class="col-md-6 text-center">
                        <div class="certificate-line mb-2"></div>
                        <span>Meat Inspector</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.3/html2pdf.bundle.min.js" integrity="sha512-YcsIP7rQ6kQlmmSrF1u6s/VrkEeWgFcc+VCVoU0Q7Es/Mn1A6HAn/qx3qQ2YKq56BuIHKt9Kw42PrT7Boue3Gw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
function downloadCertificatePdf() {
    const element = document.getElementById('certificate');
    const opt = {
        margin: 0.5,
        filename: 'MIC-<?php echo addslashes($inspection['inspection_id']); ?>.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
}
</script>
