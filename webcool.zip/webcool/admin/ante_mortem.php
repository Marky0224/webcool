<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectionsRaw = firebase_get('inspections');
$allInspections = is_array($inspectionsRaw) ? array_filter($inspectionsRaw, 'is_array') : [];
$isAnteMortemRecord = static function (array $inspection): bool {
	$inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
	return is_array($inspectionData['ante_mortem'] ?? null);
};

$getInspectionDate = static function (array $inspection): string {
	$recordDate = trim((string) ($inspection['inspection_date'] ?? ''));
	if ($recordDate === '') {
		$recordDate = trim((string) ($inspection['created_at'] ?? ''));
	}
	return substr($recordDate, 0, 10);
};
$requestedDate = trim((string) ($_GET['date'] ?? ''));
$selectedDate = DateTime::createFromFormat('!Y-m-d', $requestedDate);
$selectedDateValue = $selectedDate && $selectedDate->format('Y-m-d') === $requestedDate
	? $selectedDate->format('Y-m-d')
	: '';
$anteMortemInspections = [];
foreach ($allInspections as $key => $inspection) {
	if ($isAnteMortemRecord($inspection)) {
		$anteMortemInspections[] = ['key' => (string) $key, 'inspection' => $inspection];
	}
}
$monthlyTotals = [];
$availableYears = [];
foreach ($anteMortemInspections as $record) {
	$recordDate = $getInspectionDate($record['inspection']);
	$parsedRecordDate = DateTime::createFromFormat('!Y-m-d', $recordDate);
	if (!$parsedRecordDate || $parsedRecordDate->format('Y-m-d') !== $recordDate) {
		continue;
	}

	$monthKey = $parsedRecordDate->format('Y-m');
	$monthlyTotals[$monthKey] = ($monthlyTotals[$monthKey] ?? 0) + 1;
	$availableYears[$parsedRecordDate->format('Y')] = true;
}
if (!isset($availableYears[date('Y')])) {
	$availableYears[date('Y')] = true;
}
$availableYears = array_map('strval', array_keys($availableYears));
rsort($availableYears);
$requestedYear = trim((string) ($_GET['year'] ?? ''));
$selectedYear = in_array($requestedYear, $availableYears, true) ? $requestedYear : $availableYears[0];
$monthlyTotalsForYear = [];
for ($month = 1; $month <= 12; $month++) {
	$monthKey = $selectedYear . '-' . str_pad((string) $month, 2, '0', STR_PAD_LEFT);
	$monthlyTotalsForYear[$monthKey] = $monthlyTotals[$monthKey] ?? 0;
}
$inspections = array_values(array_filter($anteMortemInspections, function (array $record) use ($selectedDateValue, $getInspectionDate) {
	if ($selectedDateValue === '') {
		return true;
	}
	return $getInspectionDate($record['inspection']) === $selectedDateValue;
}));
usort($inspections, static function (array $first, array $second) use ($getInspectionDate): int {
	return strcmp($getInspectionDate($second['inspection']), $getInspectionDate($first['inspection']));
});
$pageHeading = 'Ante-Mortem Inspections';
$pageDescription = $selectedDateValue === ''
	? 'Showing all ante-mortem inspection records. Use the date filter to narrow the results.'
	: 'Review records from the ante-mortem inspection stage for ' . $selectedDate->format('F d, Y') . '.';

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
	<?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
	<div class="container-fluid px-4 py-4">
		<div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
			<div>
				<h3 class="mb-1"><?php echo htmlspecialchars($pageHeading); ?></h3>
				<p class="text-secondary mb-0"><?php echo htmlspecialchars($pageDescription); ?></p>
			</div>
		</div>

		<div class="card shadow-sm border-0 mb-4" id="monthly-ante-mortem-summary">
			<div class="card-body">
				<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
					<h5 class="card-title mb-0">Monthly Ante-Mortem Summary</h5>
					<div class="d-flex align-items-center gap-2 no-print">
						<form class="d-flex align-items-center gap-2" action="/admin/ante_mortem.php" method="get">
							<?php if ($selectedDateValue !== ''): ?>
								<input type="hidden" name="date" value="<?php echo htmlspecialchars($selectedDateValue); ?>">
							<?php endif; ?>
							<label class="form-label mb-0" for="summaryYear">Year</label>
							<select class="form-select form-select-sm" id="summaryYear" name="year">
								<?php foreach ($availableYears as $year): ?>
									<option value="<?php echo htmlspecialchars($year); ?>"<?php echo $year === $selectedYear ? ' selected' : ''; ?>><?php echo htmlspecialchars($year); ?></option>
								<?php endforeach; ?>
							</select>
							<button class="btn btn-sm ante-mortem-action-button" type="submit">View</button>
						</form>
						<button class="btn btn-sm print-button" type="button" onclick="printMonthlyAnteMortemSummary()"><i class="fa-solid fa-print me-1"></i>Print Summary</button>
					</div>
				</div>
				<div class="table-responsive">
					<table class="table table-striped table-hover mb-0">
						<thead>
							<tr>
								<th>Month</th>
								<th>Total Records Submitted</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($monthlyTotalsForYear as $month => $total): ?>
								<tr>
									<td><?php echo htmlspecialchars(DateTime::createFromFormat('!Y-m', $month)->format('F Y')); ?></td>
									<td><?php echo number_format($total); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>

		<div class="modal fade" id="anteMortemChartModal" tabindex="-1" aria-labelledby="anteMortemChartModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="anteMortemChartModalLabel">Monthly Ante-Mortem Summary</h5>
						<div class="d-flex align-items-center gap-2">
							<button type="button" class="btn btn-sm print-button" onclick="printAnteMortemChart()">
								<i class="fa-solid fa-print me-1"></i>Print
							</button>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
					</div>
					<div class="modal-body">
						<div class="ante-mortem-chart-container">
							<canvas id="anteMortemMonthlyChart" aria-label="Monthly Ante-Mortem records bar chart"></canvas>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="card shadow-sm border-0" id="ante-mortem-inspection-records">
			<div class="card-body">
				<div class="ante-mortem-record-toolbar mb-3">
					<div>
						<h5 class="card-title mb-1">Ante Mortem Records</h5>
						<p class="text-secondary small mb-0"><span id="anteMortemRecordCount"><?php echo count($inspections); ?></span> record(s) found for the selected date.</p>
					</div>
					<div class="ante-mortem-record-filters no-print">
						<form class="ante-mortem-date-filter" method="get" action="/admin/ante_mortem.php">
							<input type="hidden" name="year" value="<?php echo htmlspecialchars($selectedYear); ?>">
							<label class="form-label mb-0" for="anteMortemDate">Date</label>
							<input class="form-control form-control-sm" type="date" id="anteMortemDate" name="date" value="<?php echo htmlspecialchars($selectedDateValue); ?>">
							<button class="btn btn-sm filter-button" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button>
						</form>
						<label class="visually-hidden" for="anteMortemRecordSearch">Search Ante-Mortem records</label>
						<input class="form-control form-control-sm ante-mortem-record-search" type="search" id="anteMortemRecordSearch" placeholder="Search records..." aria-controls="anteMortemRecordsTable">
						<span class="badge bg-primary"><?php echo htmlspecialchars($selectedDateValue !== '' ? $selectedDate->format('F d, Y') : 'All dates'); ?></span>
					</div>
					<button class="btn btn-sm print-button no-print" type="button" onclick="printAnteMortemRecords()"><i class="fa-solid fa-print me-1"></i>Print Records</button>
				</div>
				<div class="table-responsive">
					<table id="anteMortemRecordsTable" class="table table-striped table-hover datatable mb-0" data-search-input="anteMortemRecordSearch" data-count-target="anteMortemRecordCount" data-filter-toolbar="false">
						<thead>
							<tr>
								<th>Date</th>
								<th>Owner / Code</th>
								<th>No. of Heads</th>
								<th>Farm / Supplier Name</th>
								<th>Barangay of Animal Origin</th>
								<th>Category</th>
								<th>Document Presented</th>
								<th>Inspector</th>
								<th>Reason for Edit</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($inspections as $record):
								$inspection = $record['inspection'];
								$inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
								$anteMortem = is_array($inspectionData['ante_mortem'] ?? null) ? $inspectionData['ante_mortem'] : [];
								$customerData = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
								$ownerCode = $customerData['owner_code'] ?? $inspection['owner_code'] ?? $customerData['customer_id'] ?? $inspection['customer_id'] ?? 'N/A';
								$ownerName = $customerData['owner_name'] ?? $inspection['customer_name'] ?? 'N/A';
								$heads = $anteMortem['no_of_heads'] ?? $inspection['no_of_heads'] ?? $inspection['head_count'] ?? $inspectionData['head_count'] ?? $inspectionData['meat_summary']['no_of_heads'] ?? 'N/A';
								$farmOwner = $anteMortem['farm_owner'] ?? $inspection['farm_owner'] ?? $customerData['farm_supplier_name'] ?? 'N/A';
								$origin = $anteMortem['origin'] ?? $inspection['origin'] ?? $customerData['barangay_of_animal_origin'] ?? $customerData['origin'] ?? 'N/A';
								$category = get_ante_mortem_category_code((string) ($anteMortem['category'] ?? $inspection['category'] ?? 'N/A'));
								$documentPresentedValue = $anteMortem['document_presented'] ?? $inspection['document_presented'] ?? 'N/A';
								$documentPresented = is_array($documentPresentedValue)
									? implode(', ', array_map(static fn($document): string => get_ante_mortem_document_label((string) $document), $documentPresentedValue))
									: get_ante_mortem_document_label((string) $documentPresentedValue);
								$documentNumber = $anteMortem['document_number'] ?? $inspection['document_number'] ?? '';
								$changeReason = trim((string) ($anteMortem['change_reason'] ?? ''));
								$recordDate = $getInspectionDate($inspection);
								$parsedRecordDate = DateTime::createFromFormat('!Y-m-d', $recordDate);
							?>
								<tr>
									<td><?php echo htmlspecialchars($parsedRecordDate && $parsedRecordDate->format('Y-m-d') === $recordDate ? $parsedRecordDate->format('M d, Y') : 'N/A'); ?></td>
									<td><?php echo htmlspecialchars($ownerCode . ' / ' . $ownerName); ?></td>
									<td><?php echo htmlspecialchars($heads); ?></td>
									<td><?php echo htmlspecialchars($farmOwner); ?></td>
									<td><?php echo htmlspecialchars($origin); ?></td>
									<td><?php echo htmlspecialchars($category); ?></td>
									<td>
										<?php echo htmlspecialchars($documentPresented); ?>
										<?php if ($documentNumber !== ''): ?>
											<span class="d-block text-secondary small"><?php echo htmlspecialchars($documentNumber); ?></span>
										<?php endif; ?>
									</td>
									<td><?php echo htmlspecialchars($inspection['inspector_name'] ?? 'N/A'); ?></td>
									<td><?php echo htmlspecialchars($changeReason !== '' ? $changeReason : '—'); ?></td>
									<td>
										<?php if (!empty($inspection['inspection_id'])): ?>
											<a class="btn btn-sm ante-mortem-action-button" href="/admin/ante_mortem_view.php?inspection_id=<?php echo urlencode((string) $inspection['inspection_id']); ?>">
												<i class="fa-regular fa-eye me-1"></i>View
											</a>
											<a class="btn btn-sm ante-mortem-action-button" href="/admin/ante_mortem_edit.php?inspection_id=<?php echo urlencode((string) $inspection['inspection_id']); ?>">
												<i class="fa-solid fa-pen-to-square me-1"></i>Edit
											</a>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
							<?php if (empty($inspections)): ?>
								<tr>
									<td colspan="10" class="text-center text-secondary py-4">
										<?php echo $selectedDateValue === '' ? 'No Ante-Mortem records were found.' : 'No Ante-Mortem records were found for this date.'; ?>
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>

		</div>
	</div>
</div>
<style>
	@media print {
		body.ante-mortem-records-print .sidebar,
		body.ante-mortem-records-print .admin-navbar,
		body.ante-mortem-records-print #sidebarOverlay,
		body.ante-mortem-records-print .toast-container,
		body.ante-mortem-records-print .container-fluid > *:not(#ante-mortem-inspection-records) {
			display: none !important;
		}

		body.ante-mortem-records-print .main-content,
		body.ante-mortem-records-print .container-fluid,
		body.ante-mortem-records-print #ante-mortem-inspection-records {
			width: 100% !important;
			margin: 0 !important;
			padding: 0 !important;
		}

		body.ante-mortem-records-print #ante-mortem-inspection-records {
			display: block !important;
			border: 0 !important;
			box-shadow: none !important;
		}

		body.ante-mortem-records-print #ante-mortem-inspection-records .no-print,
		body.ante-mortem-records-print #ante-mortem-inspection-records .dataTables_paginate {
			display: none !important;
		}

		body.ante-mortem-records-print #ante-mortem-inspection-records .table-responsive {
			overflow: visible !important;
		}

		body.ante-mortem-summary-print .sidebar,
		body.ante-mortem-summary-print .admin-navbar,
		body.ante-mortem-summary-print #sidebarOverlay,
		body.ante-mortem-summary-print .toast-container,
		body.ante-mortem-summary-print .container-fluid > *:not(#monthly-ante-mortem-summary) {
			display: none !important;
		}

		body.ante-mortem-summary-print .main-content,
		body.ante-mortem-summary-print #monthly-ante-mortem-summary {
			margin: 0 !important;
			padding: 0 !important;
			width: 100% !important;
		}

		body.ante-mortem-summary-print .container-fluid {
			padding: 0 !important;
		}

		body.ante-mortem-summary-print #monthly-ante-mortem-summary {
			display: block !important;
			border: 0 !important;
			box-shadow: none !important;
		}

		body.ante-mortem-summary-print #monthly-ante-mortem-summary .no-print {
			display: none !important;
		}
	}
</style>
<script>
	function printAnteMortemRecords() {
		const table = window.jQuery && jQuery.fn.dataTable && jQuery.fn.dataTable.isDataTable('#anteMortemRecordsTable')
			? jQuery('#anteMortemRecordsTable').DataTable()
			: null;
		const originalPageLength = table ? table.page.len() : null;
		if (table) {
			table.page.len(-1).draw();
		}

		document.body.classList.add('ante-mortem-records-print');
		const originalTitle = document.title;
		document.title = 'Ante-Mortem Records - <?php echo htmlspecialchars($selectedDateValue !== '' ? $selectedDate->format('F d, Y') : 'All Dates', ENT_QUOTES, 'UTF-8'); ?>';
		window.addEventListener('afterprint', function restoreRecordsView() {
			document.body.classList.remove('ante-mortem-records-print');
			document.title = originalTitle;
			if (table && originalPageLength !== null) {
				table.page.len(originalPageLength).draw();
			}
			window.removeEventListener('afterprint', restoreRecordsView);
		});
		window.print();
	}

	function printMonthlyAnteMortemSummary() {
		document.body.classList.add('ante-mortem-summary-print');
		const originalTitle = document.title;
		document.title = 'Monthly Ante-Mortem Summary - <?php echo htmlspecialchars($selectedYear, ENT_QUOTES, 'UTF-8'); ?>';
		window.addEventListener('afterprint', function restorePrintView() {
			document.body.classList.remove('ante-mortem-summary-print');
			document.title = originalTitle;
			window.removeEventListener('afterprint', restorePrintView);
		});
		window.print();
	}

	function printAnteMortemChart() {
		document.body.classList.add('ante-mortem-chart-print');
		const originalTitle = document.title;
		document.title = document.getElementById('anteMortemChartModalLabel').textContent;
		window.addEventListener('afterprint', function restoreChartView() {
			document.body.classList.remove('ante-mortem-chart-print');
			document.title = originalTitle;
			window.removeEventListener('afterprint', restoreChartView);
		});
		window.print();
	}

	const anteMortemMonthlyTotals = <?php echo json_encode($monthlyTotals, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
	const anteMortemChartLabels = <?php echo json_encode(
		array_map(
			static fn(int $month): string => DateTime::createFromFormat('!m', (string) $month)->format('F'),
			range(1, 12)
		),
		JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
	); ?>;
	document.addEventListener('DOMContentLoaded', function () {
		const anteMortemSummaryForm = document.querySelector('#monthly-ante-mortem-summary form');
		const anteMortemChartModalElement = document.getElementById('anteMortemChartModal');
		const anteMortemChartModal = anteMortemChartModalElement ? new bootstrap.Modal(anteMortemChartModalElement) : null;
		let anteMortemMonthlyChart = null;

		if (anteMortemSummaryForm && anteMortemChartModal) {
			anteMortemSummaryForm.addEventListener('submit', function (event) {
				event.preventDefault();
				const year = this.querySelector('select[name="year"]').value;
				const values = anteMortemChartLabels.map(function (_, index) {
					const month = String(index + 1).padStart(2, '0');
					return Number(anteMortemMonthlyTotals[year + '-' + month] || 0);
				});
				const chartContext = document.getElementById('anteMortemMonthlyChart').getContext('2d');

				document.getElementById('anteMortemChartModalLabel').textContent = 'Monthly Ante-Mortem Summary - ' + year;
				if (anteMortemMonthlyChart) {
					anteMortemMonthlyChart.destroy();
				}
				anteMortemMonthlyChart = new Chart(chartContext, {
					type: 'bar',
					data: {
						labels: anteMortemChartLabels,
						datasets: [{
							label: 'Total Records Submitted',
							data: values,
							backgroundColor: '#800000',
							borderColor: '#5c0000',
							borderWidth: 1,
							borderRadius: 5
						}]
					},
					options: {
						responsive: true,
						maintainAspectRatio: false,
						scales: {
							y: {
								beginAtZero: true,
								ticks: { precision: 0 }
							}
						},
						plugins: {
							legend: { display: false }
						}
					}
				});
				anteMortemChartModal.show();
			});
		}
	});
</script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>