<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$allInspections = array_values(array_filter(get_array_values(firebase_get('inspections')), 'is_array'));
$getInspectionDate = static function (array $inspection): string {
	$recordDate = trim((string) ($inspection['inspection_date'] ?? ''));
	if ($recordDate === '') {
		$recordDate = trim((string) ($inspection['created_at'] ?? ''));
	}
	return substr($recordDate, 0, 10);
};
$requestedDate = trim((string) ($_GET['date'] ?? ''));
$selectedDate = DateTime::createFromFormat('!Y-m-d', $requestedDate);
$selectedDateValue = $selectedDate && $selectedDate->format('Y-m-d') === $requestedDate
	? $selectedDate->format('Y-m-d')
	: '';
$anteMortemInspections = array_values(array_filter($allInspections, function ($item) {
	$inspectionData = is_array($item['inspection_data'] ?? null) ? $item['inspection_data'] : [];
	return isset($inspectionData['ante_mortem']) || ($item['status'] ?? '') === 'Ante-Mortem';
}));
$inspections = array_values(array_filter($anteMortemInspections, function ($item) use ($selectedDateValue, $getInspectionDate) {
	if ($selectedDateValue === '') {
		return true;
	}
	return $getInspectionDate($item) === $selectedDateValue;
}));
usort($inspections, static function (array $first, array $second) use ($getInspectionDate): int {
	return strcmp($getInspectionDate($second), $getInspectionDate($first));
});
$pageHeading = 'Ante-Mortem Inspections';
$pageDescription = $selectedDateValue === ''
	? 'Showing all ante-mortem inspection records. Use the date filter to narrow the results.'
	: 'Review records from the ante-mortem inspection stage for ' . $selectedDate->format('F d, Y') . '.';

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
	<?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
	<div class="container-fluid px-4 py-4">
		<div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
			<div>
				<h3 class="mb-1"><?php echo htmlspecialchars($pageHeading); ?></h3>
				<p class="text-secondary mb-0"><?php echo htmlspecialchars($pageDescription); ?></p>
			</div>
			<form class="d-flex flex-wrap align-items-end gap-2" method="get" action="/admin/ante_mortem.php">
				<div>
					<label class="form-label small mb-1" for="anteMortemDate">Filter by date</label>
					<input class="form-control" type="date" id="anteMortemDate" name="date" value="<?php echo htmlspecialchars($selectedDateValue); ?>">
				</div>
				<button class="btn btn-primary" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button>
				<?php if ($selectedDateValue !== ''): ?>
					<a class="btn btn-outline-secondary" href="/admin/ante_mortem.php">Show all</a>
				<?php endif; ?>
			</form>
		</div>

		<div class="card shadow-sm border-0">
			<div class="card-body">
				<h5 class="card-title mb-1"><?php echo htmlspecialchars($pageHeading); ?> Records <span class="badge text-bg-light"><?php echo count($inspections); ?></span></h5>
				<p class="text-secondary small mb-3"><?php echo $selectedDateValue === '' ? 'All dates' : 'Date: ' . htmlspecialchars($selectedDate->format('F d, Y')); ?></p>
				<div class="table-responsive">
					<table class="table table-striped table-hover datatable mb-0">
						<thead>
							<tr>
								<th>Date</th>
								<th>Owner / Code</th>
								<th>No. of Heads</th>
								<th>Name of Farm / Farmer</th>
								<th>Origin / Place</th>
								<th>Category</th>
								<th>Document Presented</th>
								<th>Inspector</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($inspections as $inspection):
								$inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
								$anteMortem = is_array($inspectionData['ante_mortem'] ?? null) ? $inspectionData['ante_mortem'] : [];
								$customerData = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
								$ownerCode = $customerData['owner_code'] ?? $inspection['owner_code'] ?? $customerData['customer_id'] ?? $inspection['customer_id'] ?? 'N/A';
								$ownerName = $customerData['owner_name'] ?? $inspection['customer_name'] ?? 'N/A';
								$heads = $anteMortem['no_of_heads'] ?? $inspection['no_of_heads'] ?? $inspection['head_count'] ?? $inspectionData['head_count'] ?? $inspectionData['meat_summary']['no_of_heads'] ?? 'N/A';
								$farmOwner = $anteMortem['farm_owner'] ?? $inspection['farm_owner'] ?? 'N/A';
								$origin = $anteMortem['origin'] ?? $inspection['origin'] ?? 'N/A';
								$category = get_ante_mortem_category_code((string) ($anteMortem['category'] ?? $inspection['category'] ?? 'N/A'));
								$documentPresentedValue = $anteMortem['document_presented'] ?? $inspection['document_presented'] ?? 'N/A';
								$documentPresented = is_array($documentPresentedValue)
									? implode(', ', array_map(static fn($document): string => get_ante_mortem_document_label((string) $document), $documentPresentedValue))
									: get_ante_mortem_document_label((string) $documentPresentedValue);
								$documentNumber = $anteMortem['document_number'] ?? $inspection['document_number'] ?? '';
								$recordDate = $getInspectionDate($inspection);
								$parsedRecordDate = DateTime::createFromFormat('!Y-m-d', $recordDate);
							?>
								<tr>
									<td><?php echo htmlspecialchars($parsedRecordDate && $parsedRecordDate->format('Y-m-d') === $recordDate ? $parsedRecordDate->format('M d, Y') : 'N/A'); ?></td>
									<td><?php echo htmlspecialchars($ownerCode . ' / ' . $ownerName); ?></td>
									<td><?php echo htmlspecialchars($heads); ?></td>
									<td><?php echo htmlspecialchars($farmOwner); ?></td>
									<td><?php echo htmlspecialchars($origin); ?></td>
									<td><?php echo htmlspecialchars($category); ?></td>
									<td>
										<?php echo htmlspecialchars($documentPresented); ?>
										<?php if ($documentNumber !== ''): ?>
											<span class="d-block text-secondary small"><?php echo htmlspecialchars($documentNumber); ?></span>
										<?php endif; ?>
									</td>
									<td><?php echo htmlspecialchars($inspection['inspector_name'] ?? 'N/A'); ?></td>
								</tr>
							<?php endforeach; ?>
							<?php if (empty($inspections)): ?>
								<tr>
									<td colspan="8" class="text-center text-secondary py-4">
										<?php echo $selectedDateValue === '' ? 'No Ante-Mortem records were found.' : 'No Ante-Mortem records were found for this date.'; ?>
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>