<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$customersRaw = firebase_get('customers');
$customers = is_array($customersRaw) ? $customersRaw : [];

$customerKey = $_GET['id'] ?? '';
$customer = $customerKey && isset($customers[$customerKey]) ? $customers[$customerKey] : null;

$errors = [];
$message = null;
$suffixOptions = ['', 'Jr.', 'Sr.', 'II', 'III', 'IV', 'V'];
$categoryOptions = ['B' => 'Backyard', 'C' => 'Commercial', 'S' => 'Stockyard'];
$barangayDatasetPath = __DIR__ . '/../assets/data/lipa-city-barangays.geojson';
$barangayDatasetContents = is_file($barangayDatasetPath) ? file_get_contents($barangayDatasetPath) : false;
$barangayDataset = is_string($barangayDatasetContents) ? json_decode($barangayDatasetContents, true) : null;
$barangays = [];
foreach (is_array($barangayDataset['features'] ?? null) ? $barangayDataset['features'] : [] as $feature) {
    $properties = is_array($feature['properties'] ?? null) ? $feature['properties'] : [];
    $name = trim((string) ($properties['name'] ?? ''));
    if ($name !== '') {
        $barangays[] = $name;
    }
}
$barangays = array_values(array_unique($barangays));
sort($barangays, SORT_NATURAL | SORT_FLAG_CASE);
$legacyNameParts = preg_split('/\s+/', trim((string) ($customer['owner_name'] ?? '')), -1, PREG_SPLIT_NO_EMPTY) ?: [];
$customerForm = [
    'first_name' => format_person_name((string) ($customer['first_name'] ?? ($legacyNameParts[0] ?? ''))),
    'last_name' => format_person_name((string) ($customer['last_name'] ?? (count($legacyNameParts) > 1 ? array_pop($legacyNameParts) : ''))),
    'middle_name' => (string) ($customer['middle_name'] ?? (count($legacyNameParts) > 1 ? implode(' ', array_slice($legacyNameParts, 1)) : '')),
    'suffix' => (string) ($customer['suffix'] ?? ''),
    'owner_code' => (string) ($customer['owner_code'] ?? ''),
    'contact_number' => (string) ($customer['contact_number'] ?? ''),
    'barangay_of_animal_origin' => (string) ($customer['barangay_of_animal_origin'] ?? $customer['origin'] ?? ''),
    'farm_supplier_name' => (string) ($customer['farm_supplier_name'] ?? ''),
    'category' => get_ante_mortem_category_code((string) ($customer['category'] ?? '')),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($customerForm as $field => $default) {
        $value = $_POST[$field] ?? $default;
        $customerForm[$field] = is_string($value) ? trim($value) : '';
    }
    $firstName = $customerForm['first_name'];
    $lastName = $customerForm['last_name'];
    $middleName = $customerForm['middle_name'];
    $suffix = $customerForm['suffix'];
    $ownerCode = $customerForm['owner_code'];
    $contactNumber = $customerForm['contact_number'];
    $barangayOrigin = $customerForm['barangay_of_animal_origin'];
    $farmSupplierName = $customerForm['farm_supplier_name'];
    $category = $customerForm['category'];
    $firstName = format_person_name($firstName);
    $lastName = format_person_name($lastName);
    $customerForm['first_name'] = $firstName;
    $customerForm['last_name'] = $lastName;
    $ownerName = implode(' ', array_filter(
        [$firstName, $middleName, $lastName, $suffix],
        static fn(string $part): bool => $part !== ''
    ));
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $origin = $barangayOrigin !== '' ? $barangayOrigin : trim($_POST['origin'] ?? '');
    $province = trim($_POST['province'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');

    if ($firstName === '' || $lastName === '') {
        $errors[] = 'First name and last name are required.';
    }
    foreach (['First name' => $firstName, 'Last name' => $lastName, 'Middle name' => $middleName] as $label => $namePart) {
        if (strlen($namePart) > 100) {
            $errors[] = $label . ' must be 100 characters or fewer.';
        }
    }
    if (!in_array($suffix, $suffixOptions, true)) {
        $errors[] = 'Select a valid suffix.';
    }
    if ($contactNumber === '') {
        $errors[] = 'Contact Number is required.';
    } elseif (!preg_match('/\A09[0-9]{9}\z/', $contactNumber)) {
        $errors[] = 'Contact number must be exactly 11 digits and start with 09.';
    }
    if ($ownerCode === '') {
        $errors[] = 'Code is required.';
    } elseif (strlen($ownerCode) > 50) {
        $errors[] = 'Code must be 50 characters or fewer.';
    }
    if (!in_array($barangayOrigin, $barangays, true)) {
        $errors[] = 'Select a valid barangay of animal origin.';
    }
    if ($farmSupplierName === '') {
        $errors[] = 'Farm / Supplier Name is required.';
    } elseif (strlen($farmSupplierName) > 150) {
        $errors[] = 'Farm / Supplier Name must be 150 characters or fewer.';
    }
    if (!array_key_exists($category, $categoryOptions)) {
        $errors[] = 'Select a valid category.';
    }
    if (empty($errors)) {
        $customersResult = firebase_request('get', 'customers');
        if (is_array($customersResult) && isset($customersResult['error'])) {
            $errors[] = 'Customer database is unavailable. Check the Firebase connection and try again.';
        } elseif ($customersResult !== null && !is_array($customersResult)) {
            $errors[] = 'Customer records could not be read. Please try again.';
        } else {
            $customersForValidation = is_array($customersResult) ? $customersResult : [];
            foreach ($customersForValidation as $existingKey => $existingCustomer) {
                if (!is_array($existingCustomer) || (string) $existingKey === (string) $customerKey) {
                    continue;
                }
                $existingOwnerCode = trim((string) ($existingCustomer['owner_code'] ?? ''));
                if ($existingOwnerCode === '') {
                    $existingOwnerCode = trim((string) ($existingCustomer['customer_id'] ?? ''));
                }
                if (strcasecmp($existingOwnerCode, $ownerCode) === 0) {
                    $errors[] = 'This code is already registered. Please enter another code.';
                    break;
                }
            }
        }

        if (empty($errors)) {
            $customerId = $customer['customer_id'] ?? generate_customer_id(get_array_values($customers));
            $customerData = [
                'customer_id' => $customerId,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'middle_name' => $middleName,
                'suffix' => $suffix,
                'owner_name' => $ownerName,
                'owner_code' => $ownerCode,
                'contact_number' => $contactNumber,
                'barangay_of_animal_origin' => $barangayOrigin,
                'farm_supplier_name' => $farmSupplierName,
                'category' => $category,
                'email' => $email,
                'address' => $address,
                'origin' => $origin,
                'province' => $province,
                'remarks' => $remarks,
                'created_at' => $customer['created_at'] ?? date('Y-m-d H:i:s'),
            ];

            $qrPath = save_customer_qr_image($customerId);
            if ($qrPath === null) {
                $errors[] = 'Failed to generate customer QR image. Please check server permissions.';
            } else {
                $customerData['qr_image'] = customer_qr_image_web_path($customerId);
            }

            if (empty($errors)) {
                if ($customerKey) {
                    $saveResult = firebase_patch('customers/' . $customerKey, $customerData);
                    if (is_array($saveResult) && isset($saveResult['error'])) {
                        $errors[] = 'Failed to save customer: ' . $saveResult['error'];
                    } else {
                        header('Location: /admin/customer_profile.php?id=' . urlencode($customerKey) . '&saved=1');
                        exit;
                    }
                } else {
                    $pushResult = firebase_post('customers', $customerData);
                    if (!empty($pushResult['name'])) {
                        $customerKey = $pushResult['name'];
                        header('Location: /admin/customer_profile.php?id=' . urlencode($customerKey) . '&saved=1');
                        exit;
                    } else {
                        $errors[] = 'Failed to save customer. Please try again.';
                    }
                }
                $customer = $customerData;
            }
        }
    }
} else {
    $message = isset($_GET['saved']) ? 'Customer details saved successfully.' : null;
}

$showCustomerForm = !$customer || !empty($errors);

$customerActivities = [];
$customerActivityError = null;
if (is_array($customer) && !empty($customer['customer_id'])) {
    $customerId = (string) $customer['customer_id'];
    $addCustomerActivity = static function (string $title, string $date, string $details = '') use (&$customerActivities): void {
        $timestamp = strtotime($date);
        $customerActivities[] = [
            'title' => $title,
            'timestamp' => $timestamp !== false ? $timestamp : 0,
            'date' => $timestamp !== false ? date('M d, Y h:i A', $timestamp) : 'Date unavailable',
            'details' => $details,
        ];
    };

    if (!empty($customer['created_at'])) {
        $addCustomerActivity('Customer registered', (string) $customer['created_at']);
    }

    $inspectionRecords = firebase_request('get', 'inspections');
    if (is_array($inspectionRecords) && isset($inspectionRecords['error'])) {
        $customerActivityError = 'Customer activity history is unavailable. Check the Firebase connection and try again.';
    }

    foreach (is_array($inspectionRecords) && $customerActivityError === null ? $inspectionRecords : [] as $inspection) {
        if (!is_array($inspection)) {
            continue;
        }

        $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
        $inspectionCustomer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
        if (
            (string) ($inspection['customer_id'] ?? '') !== $customerId
            && (string) ($inspectionCustomer['customer_id'] ?? '') !== $customerId
        ) {
            continue;
        }

        $inspectionDate = (string) ($inspection['inspection_date'] ?? $inspection['created_at'] ?? '');
        $inspectionId = trim((string) ($inspection['inspection_id'] ?? ''));
        $status = trim((string) ($inspection['status'] ?? 'Inspection'));
        $details = array_filter([
            $inspectionId !== '' ? 'Inspection ID: ' . $inspectionId : '',
            'Status: ' . $status,
            !empty($inspection['inspector_name']) ? 'Inspector: ' . (string) $inspection['inspector_name'] : '',
        ]);
        $addCustomerActivity('Slaughterhouse visit / inspection', $inspectionDate, implode(' · ', $details));

        $anteMortem = is_array($inspectionData['ante_mortem'] ?? null) ? $inspectionData['ante_mortem'] : [];
        if ($anteMortem) {
            $heads = trim((string) ($anteMortem['no_of_heads'] ?? ''));
            $addCustomerActivity(
                'Ante-mortem report recorded',
                $inspectionDate,
                $heads !== '' ? 'Number of heads: ' . $heads : ($inspectionId !== '' ? 'Inspection ID: ' . $inspectionId : '')
            );
        }

        $slaughter = is_array($inspectionData['slaughter'] ?? null) ? $inspectionData['slaughter'] : [];
        $slaughterDate = (string) (
            $inspectionData['slaughter_date']
            ?? $slaughter['slaughter_date']
            ?? ''
        );
        if ($slaughter || $slaughterDate !== '' || strtolower($status) === 'slaughter') {
            $addCustomerActivity(
                'Slaughter / post-mortem recorded',
                $slaughterDate !== '' ? $slaughterDate : $inspectionDate,
                $inspectionId !== '' ? 'Inspection ID: ' . $inspectionId : ''
            );
        }

        $condemnation = is_array($inspectionData['condemnation'] ?? null) ? $inspectionData['condemnation'] : [];
        if ($condemnation) {
            $condemnationDetails = array_filter([
                !empty($condemnation['animal_type']) ? 'Type: ' . ucfirst((string) $condemnation['animal_type']) : '',
                isset($condemnation['weight']) ? 'Weight: ' . (string) $condemnation['weight'] . ' kg' : '',
                !empty($condemnation['reason']) ? 'Reason: ' . (string) $condemnation['reason'] : '',
            ]);
            $addCustomerActivity(
                'Condemnation recorded',
                (string) ($condemnation['recorded_at'] ?? $inspectionDate),
                implode(' · ', $condemnationDetails)
            );
        }

        $certificateId = trim((string) ($inspection['certificate_id'] ?? ''));
        if ($certificateId !== '') {
            $addCustomerActivity(
                'Meat inspection certificate issued',
                (string) ($inspection['certificate_created_at'] ?? $inspectionData['date_issued'] ?? $inspectionDate),
                'Certificate ID: ' . $certificateId
            );
        }
    }

    usort($customerActivities, static fn(array $first, array $second): int => $second['timestamp'] <=> $first['timestamp']);
}

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content customer-profile-page">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="customer-profile-heading d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1"><?php echo htmlspecialchars($customer['customer_id'] ?? 'New Customer'); ?></h3>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <?php if ($customer): ?>
                    <button
                        id="toggleCustomerEdit"
                        class="btn btn-outline-primary"
                        type="button"
                        aria-controls="customer-details"
                        aria-expanded="<?php echo $showCustomerForm ? 'true' : 'false'; ?>"
                    ><?php echo $showCustomerForm ? 'Done Editing' : 'Edit Customer'; ?></button>
                <?php endif; ?>
                <a href="/admin/customers.php" class="btn btn-outline-secondary">Back to Customers</a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="row g-4 customer-profile-grid">
            <div class="col-md-7">
                <div class="card shadow-sm border-0 customer-profile-details-card">
                    <div class="card-body">
                        <?php if ($customer): ?>
                            <div id="customer-summary" class="customer-profile-summary<?php echo $showCustomerForm ? ' d-none' : ''; ?>">
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Customer ID</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['customer_id'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Customer Name</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars(format_person_name((string) ($customer['owner_name'] ?? 'N/A'))); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Code</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['owner_code'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Contact Number</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['contact_number'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Barangay of Animal Origin</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['barangay_of_animal_origin'] ?? $customer['origin'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Farm / Supplier Name</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['farm_supplier_name'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Category</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($categoryOptions[get_ante_mortem_category_code((string) ($customer['category'] ?? ''))] ?? 'N/A'); ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <form id="customer-details" method="post" class="row g-3<?php echo $customer && !$showCustomerForm ? ' d-none' : ''; ?>">
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="first_name">First Name <span class="text-danger">*</span></label>
                                <input type="text" name="first_name" id="first_name" class="form-control" maxlength="100" value="<?php echo htmlspecialchars($customerForm['first_name']); ?>" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="last_name">Last Name <span class="text-danger">*</span></label>
                                <input type="text" name="last_name" id="last_name" class="form-control" maxlength="100" value="<?php echo htmlspecialchars($customerForm['last_name']); ?>" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="middle_name">Middle Name</label>
                                <input type="text" name="middle_name" id="middle_name" class="form-control" maxlength="100" value="<?php echo htmlspecialchars($customerForm['middle_name']); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="suffix">Suffix</label>
                                <select name="suffix" id="suffix" class="form-select">
                                    <?php foreach ($suffixOptions as $suffixOption): ?>
                                        <option value="<?php echo htmlspecialchars($suffixOption); ?>"<?php echo $customerForm['suffix'] === $suffixOption ? ' selected' : ''; ?>><?php echo $suffixOption !== '' ? htmlspecialchars($suffixOption) : 'None'; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="owner_code">Code <span class="text-danger">*</span></label>
                                <input type="text" name="owner_code" id="owner_code" class="form-control" maxlength="50" value="<?php echo htmlspecialchars($customerForm['owner_code']); ?>" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="contact_number">Contact Number <span class="text-danger">*</span></label>
                                <input type="tel" name="contact_number" id="contact_number" class="form-control" value="<?php echo htmlspecialchars($customerForm['contact_number']); ?>" pattern="09[0-9]{9}" minlength="11" maxlength="11" title="Enter exactly 11 digits starting with 09." required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="barangay_of_animal_origin">Barangay of Animal Origin <span class="text-danger">*</span></label>
                                <select name="barangay_of_animal_origin" id="barangay_of_animal_origin" class="form-select" required>
                                    <option value="">Select barangay</option>
                                    <?php foreach ($barangays as $barangay): ?>
                                        <option value="<?php echo htmlspecialchars($barangay); ?>"<?php echo $customerForm['barangay_of_animal_origin'] === $barangay ? ' selected' : ''; ?>><?php echo htmlspecialchars($barangay); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label" for="farm_supplier_name">Farm / Supplier Name <span class="text-danger">*</span></label>
                                <input type="text" name="farm_supplier_name" id="farm_supplier_name" class="form-control" maxlength="150" value="<?php echo htmlspecialchars($customerForm['farm_supplier_name']); ?>" required>
                            </div>
                            <div class="col-12">
                                <fieldset>
                                    <legend class="form-label">Category <span class="text-danger">*</span></legend>
                                    <div class="row g-2">
                                        <?php foreach ($categoryOptions as $categoryCode => $categoryLabel): ?>
                                            <div class="col-12 col-md-4">
                                                <label class="form-check border rounded-2 p-3 h-100">
                                                    <input class="form-check-input" type="radio" name="category" value="<?php echo htmlspecialchars($categoryCode); ?>"<?php echo $customerForm['category'] === $categoryCode ? ' checked' : ''; ?> required>
                                                    <span class="form-check-label"><?php echo htmlspecialchars($categoryLabel); ?></span>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </fieldset>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Email Address</label>
                                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($_POST['email'] ?? $customer['email'] ?? ''); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Province</label>
                                <input type="text" name="province" class="form-control" value="<?php echo htmlspecialchars($_POST['province'] ?? $customer['province'] ?? ''); ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($_POST['address'] ?? $customer['address'] ?? ''); ?></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Remarks</label>
                                <textarea name="remarks" class="form-control" rows="3"><?php echo htmlspecialchars($_POST['remarks'] ?? $customer['remarks'] ?? ''); ?></textarea>
                            </div>
                            <div class="col-12 text-end">
                                <button type="submit" class="btn btn-success"><?php echo $customer ? 'Save Customer' : 'Create Customer'; ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card shadow-sm border-0 customer-profile-qr-card">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-3">Customer QR Code</h5>
                        <?php if (!empty($customer['customer_id'])): ?>
                            <p class="text-secondary mb-2">Customer ID</p>
                            <p class="fw-semibold mb-4"><?php echo htmlspecialchars($customer['customer_id']); ?></p>
                            <?php if (!empty($customer['qr_image'])): ?>
                                <img src="<?php echo htmlspecialchars($customer['qr_image']); ?>" alt="Customer QR Code" class="img-fluid mb-3 customer-profile-qr-image">
                                <div class="d-grid gap-2">
                                    <a class="btn btn-primary" href="<?php echo htmlspecialchars($customer['qr_image']); ?>" download="<?php echo htmlspecialchars($customer['customer_id']); ?>-qr.png"><i class="fa-solid fa-download me-2"></i>Download QR</a>
                                    <button class="btn print-button customer-profile-print-button" onclick="window.print();"><i class="fa-solid fa-print me-2"></i>Print QR Card</button>
                                </div>
                                <?php if (isset($_GET['debug']) && $_GET['debug'] === 'qr'): ?>
                                    <div class="alert alert-info mt-3 text-start">
                                        <strong>QR debug:</strong><br>
                                        Image URL: <?php echo htmlspecialchars($customer['qr_image']); ?><br>
                                        <?php $fsPath = __DIR__ . '/../' . ltrim($customer['qr_image'], '/'); ?>
                                        Server file: <?php echo htmlspecialchars($fsPath); ?><br>
                                        Exists: <?php echo file_exists($fsPath) ? 'yes' : 'no'; ?>
                                        <?php if (file_exists($fsPath)): ?>
                                            , size: <?php echo filesize($fsPath); ?> bytes
                                            <div class="mt-2">
                                                <strong>Embedded preview:</strong><br>
                                                <?php $data = base64_encode(file_get_contents($fsPath)); ?>
                                                <img src="data:image/png;base64,<?php echo $data; ?>" alt="Embedded QR" style="max-width:260px;" />
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-warning">QR image not generated yet.</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p class="text-secondary">Save the customer first to generate the QR code.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if ($customer): ?>
                <div id="customer-activities" class="col-12<?php echo $showCustomerForm ? ' d-none' : ''; ?>">
                    <div class="card shadow-sm border-0 mt-4">
                        <div class="card-body">
                            <h5 class="card-title mb-1">Customer Activities</h5>
                            <p class="text-secondary mb-3">Slaughterhouse visits and records associated with this customer.</p>
                            <?php if ($customerActivityError !== null): ?>
                                <p class="text-danger mb-0"><?php echo htmlspecialchars($customerActivityError); ?></p>
                            <?php elseif ($customerActivities): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($customerActivities as $activity): ?>
                                        <div class="list-group-item px-0">
                                            <div class="d-flex flex-column flex-md-row justify-content-between gap-1">
                                                <strong><?php echo htmlspecialchars($activity['title']); ?></strong>
                                                <span class="text-secondary small"><?php echo htmlspecialchars($activity['date']); ?></span>
                                            </div>
                                            <?php if ($activity['details'] !== ''): ?>
                                                <div class="text-secondary small mt-1"><?php echo htmlspecialchars($activity['details']); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p class="text-secondary mb-0">No activities have been recorded for this customer yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    </div>
<?php if ($customer): ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const toggleButton = document.getElementById('toggleCustomerEdit');
            const customerSummary = document.getElementById('customer-summary');
            const customerForm = document.getElementById('customer-details');
            const customerActivities = document.getElementById('customer-activities');
            if (!toggleButton || !customerSummary || !customerForm || !customerActivities) {
                return;
            }

            toggleButton.addEventListener('click', () => {
                const isEditing = !customerForm.classList.contains('d-none');
                customerForm.classList.toggle('d-none', isEditing);
                customerSummary.classList.toggle('d-none', !isEditing);
                customerActivities.classList.toggle('d-none', !isEditing);
                toggleButton.textContent = isEditing ? 'Edit Customer' : 'Done Editing';
                toggleButton.setAttribute('aria-expanded', String(!isEditing));
            });
        });
    </script>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>