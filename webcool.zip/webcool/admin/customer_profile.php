<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$customersRaw = firebase_get('customers');
$customers = is_array($customersRaw) ? $customersRaw : [];

$customerKey = $_GET['id'] ?? '';
$customer = $customerKey && isset($customers[$customerKey]) ? $customers[$customerKey] : null;

$errors = [];
$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ownerName = trim($_POST['owner_name'] ?? '');
    $ownerCode = trim($_POST['owner_code'] ?? '');
    $contactNumber = trim($_POST['contact_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $origin = trim($_POST['origin'] ?? '');
    $province = trim($_POST['province'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');

    if ($ownerName === '') {
        $errors[] = 'Owner Name is required.';
    }
    if ($contactNumber === '') {
        $errors[] = 'Contact Number is required.';
    }
    if ($ownerCode === '') {
        $errors[] = 'Hero (Owner Code) is required.';
    }
    if (empty($errors)) {
        $customersResult = firebase_request('get', 'customers');
        if (is_array($customersResult) && isset($customersResult['error'])) {
            $errors[] = 'Customer database is unavailable. Check the Firebase connection and try again.';
        } elseif ($customersResult !== null && !is_array($customersResult)) {
            $errors[] = 'Customer records could not be read. Please try again.';
        } else {
            $customersForValidation = is_array($customersResult) ? $customersResult : [];
            foreach ($customersForValidation as $existingKey => $existingCustomer) {
                if (!is_array($existingCustomer) || (string) $existingKey === (string) $customerKey) {
                    continue;
                }
                $existingOwnerCode = trim((string) ($existingCustomer['owner_code'] ?? ''));
                if ($existingOwnerCode === '') {
                    $existingOwnerCode = trim((string) ($existingCustomer['customer_id'] ?? ''));
                }
                if (strcasecmp($existingOwnerCode, $ownerCode) === 0) {
                    $errors[] = 'This Hero (Owner Code) is already registered. Please enter another code.';
                    break;
                }
            }
        }

        if (empty($errors)) {
            $customerId = $customer['customer_id'] ?? generate_customer_id(get_array_values($customers));
            $customerData = [
                'customer_id' => $customerId,
                'owner_name' => $ownerName,
                'owner_code' => $ownerCode,
                'contact_number' => $contactNumber,
                'email' => $email,
                'address' => $address,
                'origin' => $origin,
                'province' => $province,
                'remarks' => $remarks,
                'created_at' => $customer['created_at'] ?? date('Y-m-d H:i:s'),
            ];

            $qrPath = save_customer_qr_image($customerId);
            if ($qrPath === null) {
                $errors[] = 'Failed to generate customer QR image. Please check server permissions.';
            } else {
                $customerData['qr_image'] = customer_qr_image_web_path($customerId);
            }

            if (empty($errors)) {
                if ($customerKey) {
                    $saveResult = firebase_patch('customers/' . $customerKey, $customerData);
                    if (is_array($saveResult) && isset($saveResult['error'])) {
                        $errors[] = 'Failed to save customer: ' . $saveResult['error'];
                    } else {
                        header('Location: /admin/customer_profile.php?id=' . urlencode($customerKey) . '&saved=1');
                        exit;
                    }
                } else {
                    $pushResult = firebase_post('customers', $customerData);
                    if (!empty($pushResult['name'])) {
                        $customerKey = $pushResult['name'];
                        header('Location: /admin/customer_profile.php?id=' . urlencode($customerKey) . '&saved=1');
                        exit;
                    } else {
                        $errors[] = 'Failed to save customer. Please try again.';
                    }
                }
                $customer = $customerData;
            }
        }
    }
}

$showCustomerForm = !$customer || !empty($errors);

$customerActivities = [];
$customerActivityError = null;
if (is_array($customer) && !empty($customer['customer_id'])) {
    $customerId = (string) $customer['customer_id'];
    $addCustomerActivity = static function (string $title, string $date, string $details = '') use (&$customerActivities): void {
        $timestamp = strtotime($date);
        $customerActivities[] = [
            'title' => $title,
            'timestamp' => $timestamp !== false ? $timestamp : 0,
            'date' => $timestamp !== false ? date('M d, Y h:i A', $timestamp) : 'Date unavailable',
            'details' => $details,
        ];
    };

    if (!empty($customer['created_at'])) {
        $addCustomerActivity('Customer registered', (string) $customer['created_at']);
    }

    $inspectionRecords = firebase_request('get', 'inspections');
    if (is_array($inspectionRecords) && isset($inspectionRecords['error'])) {
        $customerActivityError = 'Customer activity history is unavailable. Check the Firebase connection and try again.';
    }

    foreach (is_array($inspectionRecords) && $customerActivityError === null ? $inspectionRecords : [] as $inspection) {
        if (!is_array($inspection)) {
            continue;
        }

        $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
        $inspectionCustomer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
        if (
            (string) ($inspection['customer_id'] ?? '') !== $customerId
            && (string) ($inspectionCustomer['customer_id'] ?? '') !== $customerId
        ) {
            continue;
        }

        $inspectionDate = (string) ($inspection['inspection_date'] ?? $inspection['created_at'] ?? '');
        $inspectionId = trim((string) ($inspection['inspection_id'] ?? ''));
        $status = trim((string) ($inspection['status'] ?? 'Inspection'));
        $details = array_filter([
            $inspectionId !== '' ? 'Inspection ID: ' . $inspectionId : '',
            'Status: ' . $status,
            !empty($inspection['inspector_name']) ? 'Inspector: ' . (string) $inspection['inspector_name'] : '',
        ]);
        $addCustomerActivity('Slaughterhouse visit / inspection', $inspectionDate, implode(' · ', $details));

        $anteMortem = is_array($inspectionData['ante_mortem'] ?? null) ? $inspectionData['ante_mortem'] : [];
        if ($anteMortem) {
            $heads = trim((string) ($anteMortem['no_of_heads'] ?? ''));
            $addCustomerActivity(
                'Ante-mortem report recorded',
                $inspectionDate,
                $heads !== '' ? 'Number of heads: ' . $heads : ($inspectionId !== '' ? 'Inspection ID: ' . $inspectionId : '')
            );
        }

        $slaughter = is_array($inspectionData['slaughter'] ?? null) ? $inspectionData['slaughter'] : [];
        $slaughterDate = (string) (
            $inspectionData['slaughter_date']
            ?? $slaughter['slaughter_date']
            ?? ''
        );
        if ($slaughter || $slaughterDate !== '' || strtolower($status) === 'slaughter') {
            $addCustomerActivity(
                'Slaughter / post-mortem recorded',
                $slaughterDate !== '' ? $slaughterDate : $inspectionDate,
                $inspectionId !== '' ? 'Inspection ID: ' . $inspectionId : ''
            );
        }

        $condemnation = is_array($inspectionData['condemnation'] ?? null) ? $inspectionData['condemnation'] : [];
        if ($condemnation) {
            $condemnationDetails = array_filter([
                !empty($condemnation['animal_type']) ? 'Type: ' . ucfirst((string) $condemnation['animal_type']) : '',
                isset($condemnation['weight']) ? 'Weight: ' . (string) $condemnation['weight'] . ' kg' : '',
                !empty($condemnation['reason']) ? 'Reason: ' . (string) $condemnation['reason'] : '',
            ]);
            $addCustomerActivity(
                'Condemnation recorded',
                (string) ($condemnation['recorded_at'] ?? $inspectionDate),
                implode(' · ', $condemnationDetails)
            );
        }

        $certificateId = trim((string) ($inspection['certificate_id'] ?? ''));
        if ($certificateId !== '') {
            $addCustomerActivity(
                'Meat inspection certificate issued',
                (string) ($inspection['certificate_created_at'] ?? $inspectionData['date_issued'] ?? $inspectionDate),
                'Certificate ID: ' . $certificateId
            );
        }
    }

    usort($customerActivities, static fn(array $first, array $second): int => $second['timestamp'] <=> $first['timestamp']);
}

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content customer-profile-page">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="customer-profile-heading d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1"><?php echo htmlspecialchars($customer['customer_id'] ?? 'New Customer'); ?></h3>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <?php if ($customer): ?>
                    <button
                        id="toggleCustomerEdit"
                        class="btn btn-outline-primary"
                        type="button"
                        aria-controls="customer-details"
                        aria-expanded="<?php echo $showCustomerForm ? 'true' : 'false'; ?>"
                    ><?php echo $showCustomerForm ? 'Done Editing' : 'Edit Customer'; ?></button>
                <?php endif; ?>
                <a href="/admin/customers.php" class="btn btn-outline-secondary">Back to Customers</a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="row g-4 customer-profile-grid">
            <div class="col-md-7">
                <div class="card shadow-sm border-0 customer-profile-details-card">
                    <div class="card-body">
                        <?php if ($customer): ?>
                            <div id="customer-summary" class="customer-profile-summary<?php echo $showCustomerForm ? ' d-none' : ''; ?>">
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Customer ID</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['customer_id'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Owner Name</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['owner_name'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Hero (Owner Code)</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['owner_code'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Contact Number</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['contact_number'] ?? 'N/A'); ?></div>
                                </div>
                                <div class="customer-profile-detail">
                                    <div class="text-secondary fs-6">Origin / Municipality</div>
                                    <div class="fw-semibold fs-5"><?php echo htmlspecialchars($customer['origin'] ?? 'N/A'); ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <form id="customer-details" method="post" class="row g-3<?php echo $customer && !$showCustomerForm ? ' d-none' : ''; ?>">
                            <div class="col-12 col-md-6">
                                <label class="form-label">Owner Name</label>
                                <input type="text" name="owner_name" class="form-control" value="<?php echo htmlspecialchars($customer['owner_name'] ?? ''); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Hero (Owner Code) <span class="text-danger">*</span></label>
                                <input type="text" name="owner_code" class="form-control" value="<?php echo htmlspecialchars($_POST['owner_code'] ?? $customer['owner_code'] ?? ''); ?>" required>
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Contact Number</label>
                                <input type="text" name="contact_number" class="form-control" value="<?php echo htmlspecialchars($customer['contact_number'] ?? ''); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Email Address</label>
                                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($customer['email'] ?? ''); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Origin / Municipality</label>
                                <input type="text" name="origin" class="form-control" value="<?php echo htmlspecialchars($customer['origin'] ?? ''); ?>">
                            </div>
                            <div class="col-12 col-md-6">
                                <label class="form-label">Province</label>
                                <input type="text" name="province" class="form-control" value="<?php echo htmlspecialchars($customer['province'] ?? ''); ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($customer['address'] ?? ''); ?></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Remarks</label>
                                <textarea name="remarks" class="form-control" rows="3"><?php echo htmlspecialchars($customer['remarks'] ?? ''); ?></textarea>
                            </div>
                            <div class="col-12 text-end">
                                <button type="submit" class="btn btn-success"><?php echo $customer ? 'Save Customer' : 'Create Customer'; ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card shadow-sm border-0 customer-profile-qr-card">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-3">Customer QR Code</h5>
                        <?php if (!empty($customer['customer_id'])): ?>
                            <p class="text-secondary mb-2">Customer ID</p>
                            <p class="fw-semibold mb-4"><?php echo htmlspecialchars($customer['customer_id']); ?></p>
                            <?php if (!empty($customer['qr_image'])): ?>
                                <img src="<?php echo htmlspecialchars($customer['qr_image']); ?>" alt="Customer QR Code" class="img-fluid mb-3 customer-profile-qr-image">
                                <div class="d-grid gap-2">
                                    <a class="btn btn-primary" href="<?php echo htmlspecialchars($customer['qr_image']); ?>" download="<?php echo htmlspecialchars($customer['customer_id']); ?>-qr.png"><i class="fa-solid fa-download me-2"></i>Download QR</a>
                                    <button class="btn print-button customer-profile-print-button" onclick="window.print();"><i class="fa-solid fa-print me-2"></i>Print QR Card</button>
                                </div>
                                <?php if (isset($_GET['debug']) && $_GET['debug'] === 'qr'): ?>
                                    <div class="alert alert-info mt-3 text-start">
                                        <strong>QR debug:</strong><br>
                                        Image URL: <?php echo htmlspecialchars($customer['qr_image']); ?><br>
                                        <?php $fsPath = __DIR__ . '/../' . ltrim($customer['qr_image'], '/'); ?>
                                        Server file: <?php echo htmlspecialchars($fsPath); ?><br>
                                        Exists: <?php echo file_exists($fsPath) ? 'yes' : 'no'; ?>
                                        <?php if (file_exists($fsPath)): ?>
                                            , size: <?php echo filesize($fsPath); ?> bytes
                                            <div class="mt-2">
                                                <strong>Embedded preview:</strong><br>
                                                <?php $data = base64_encode(file_get_contents($fsPath)); ?>
                                                <img src="data:image/png;base64,<?php echo $data; ?>" alt="Embedded QR" style="max-width:260px;" />
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <p class="text-warning">QR image not generated yet.</p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p class="text-secondary">Save the customer first to generate the QR code.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if ($customer): ?>
                <div id="customer-activities" class="col-12<?php echo $showCustomerForm ? ' d-none' : ''; ?>">
                    <div class="card shadow-sm border-0 mt-4">
                        <div class="card-body">
                            <h5 class="card-title mb-1">Customer Activities</h5>
                            <p class="text-secondary mb-3">Slaughterhouse visits and records associated with this customer.</p>
                            <?php if ($customerActivityError !== null): ?>
                                <p class="text-danger mb-0"><?php echo htmlspecialchars($customerActivityError); ?></p>
                            <?php elseif ($customerActivities): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($customerActivities as $activity): ?>
                                        <div class="list-group-item px-0">
                                            <div class="d-flex flex-column flex-md-row justify-content-between gap-1">
                                                <strong><?php echo htmlspecialchars($activity['title']); ?></strong>
                                                <span class="text-secondary small"><?php echo htmlspecialchars($activity['date']); ?></span>
                                            </div>
                                            <?php if ($activity['details'] !== ''): ?>
                                                <div class="text-secondary small mt-1"><?php echo htmlspecialchars($activity['details']); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p class="text-secondary mb-0">No activities have been recorded for this customer yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    </div>
<?php if ($customer): ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const toggleButton = document.getElementById('toggleCustomerEdit');
            const customerSummary = document.getElementById('customer-summary');
            const customerForm = document.getElementById('customer-details');
            const customerActivities = document.getElementById('customer-activities');
            if (!toggleButton || !customerSummary || !customerForm || !customerActivities) {
                return;
            }

            toggleButton.addEventListener('click', () => {
                const isEditing = !customerForm.classList.contains('d-none');
                customerForm.classList.toggle('d-none', isEditing);
                customerSummary.classList.toggle('d-none', !isEditing);
                customerActivities.classList.toggle('d-none', !isEditing);
                toggleButton.textContent = isEditing ? 'Edit Customer' : 'Done Editing';
                toggleButton.setAttribute('aria-expanded', String(!isEditing));
            });
        });
    </script>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>