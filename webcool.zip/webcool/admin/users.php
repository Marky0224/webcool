<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspectorsRaw = firebase_get('users/inspectors');
$inspectors = is_array($inspectorsRaw) ? array_filter($inspectorsRaw, 'is_array') : [];
$inspectorsForClient = [];
foreach ($inspectors as $key => $inspector) {
    $inspectorsForClient[(string) $key] = [
        'name' => (string) ($inspector['name'] ?? ''),
        'email' => (string) ($inspector['email'] ?? ''),
        'phone' => (string) ($inspector['phone'] ?? ''),
        'status' => (string) ($inspector['status'] ?? 'Inactive'),
    ];
}

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">User Management</h3>
                <p class="text-secondary mb-0">View and manage registered meat inspectors.</p>
            </div>
            <button id="openAddInspector" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#inspectorModal">
                <i class="fa-solid fa-user-plus me-2"></i>Add Inspector
            </button>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover datatable align-middle mb-0" id="inspectorsTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Contact</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($inspectors as $key => $inspector): ?>
                                <tr data-inspector-id="<?php echo htmlspecialchars($key); ?>">
                                    <td><?php echo htmlspecialchars($inspector['name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($inspector['email'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($inspector['phone'] ?? 'N/A'); ?></td>
                                    <td>
                                        <?php $inspectorStatus = $inspector['status'] ?? 'Inactive'; ?>
                                        <span class="badge <?php echo $inspectorStatus === 'Active' ? 'text-bg-success' : 'text-bg-secondary'; ?>"><?php echo htmlspecialchars($inspectorStatus); ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-2 user-action-group">
                                            <button type="button" class="btn btn-sm btn-primary user-action-btn inspector-edit" data-inspector-id="<?php echo htmlspecialchars((string) $key, ENT_QUOTES); ?>">
                                                <i class="fa-solid fa-pen-to-square me-1"></i>Edit
                                            </button>
                                            <button type="button" class="btn btn-sm <?php echo $inspectorStatus === 'Active' ? 'btn-warning' : 'btn-success'; ?> user-action-btn inspector-toggle-status" data-inspector-id="<?php echo htmlspecialchars((string) $key, ENT_QUOTES); ?>" data-status="<?php echo $inspectorStatus === 'Active' ? 'Inactive' : 'Active'; ?>">
                                                <i class="fa-solid <?php echo $inspectorStatus === 'Active' ? 'fa-user-slash' : 'fa-user-check'; ?> me-1"></i><?php echo $inspectorStatus === 'Active' ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger user-action-btn inspector-delete" data-inspector-id="<?php echo htmlspecialchars((string) $key, ENT_QUOTES); ?>">
                                                <i class="fa-solid fa-trash me-1"></i>Delete
                                            </button>
                                            <button type="button" class="btn btn-sm btn-info user-action-btn inspector-reset-password" data-inspector-id="<?php echo htmlspecialchars((string) $key, ENT_QUOTES); ?>">
                                                <i class="fa-solid fa-key me-1"></i>Reset Password
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="inspectorModal" tabindex="-1" aria-labelledby="inspectorModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="inspectorModalLabel">Add Meat Inspector</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="inspectorForm">
                <div class="modal-body">
                    <input type="hidden" id="inspector_id" name="inspector_id" value="">
                    <input type="hidden" id="form_action" name="action" value="add">
                    <div class="mb-3">
                        <label class="form-label" for="inspector_name">Name</label>
                        <input type="text" class="form-control" id="inspector_name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="inspector_email">Email</label>
                        <input type="email" class="form-control" id="inspector_email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="inspector_phone">Contact Number</label>
                        <input type="text" class="form-control" id="inspector_phone" name="phone" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="inspector_status">Status</label>
                        <select class="form-select" id="inspector_status" name="status">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="inspector_password">Password</label>
                        <input type="password" class="form-control" id="inspector_password" name="password" minlength="8" autocomplete="new-password" placeholder="Leave blank to use the default or keep the current password">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="inspectorSubmitButton">Save Inspector</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-labelledby="resetPasswordModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="resetPasswordModalLabel">Reset Inspector Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="resetPasswordForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" id="reset_inspector_id" name="inspector_id" value="">
                    <p class="text-secondary">Set a new password for <strong id="resetInspectorName"></strong>.</p>
                    <div class="mb-3">
                        <label class="form-label" for="reset_password">New password</label>
                        <input type="password" class="form-control" id="reset_password" name="password" minlength="8" autocomplete="new-password" required>
                    </div>
                    <div>
                        <label class="form-label" for="reset_password_confirm">Confirm new password</label>
                        <input type="password" class="form-control" id="reset_password_confirm" minlength="8" autocomplete="new-password" required>
                        <div class="invalid-feedback">The passwords must match.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-info" id="resetPasswordSubmit">Set New Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="passwordUpdatedModal" tabindex="-1" aria-labelledby="passwordUpdatedModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title" id="passwordUpdatedModalLabel">Password Updated</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-2">
                <p class="mb-0">The password for <strong id="updatedPasswordInspectorName"></strong> was changed successfully.</p>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-primary" id="passwordUpdatedDone">Done</button>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
<script>
    const inspectorsData = <?php echo json_encode($inspectorsForClient, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>;
</script>
<style>
    .user-action-group {
        min-width: 290px;
    }

    .user-action-btn {
        border-radius: 0.45rem;
        font-weight: 600;
        white-space: nowrap;
    }

    .user-action-btn.btn-primary {
        color: #fff;
        background-color: #42627a;
        border-color: #42627a;
    }

    .user-action-btn.btn-warning {
        color: #483a1d;
        background-color: #e8d29a;
        border-color: #e8d29a;
    }

    .user-action-btn.btn-success {
        color: #fff;
        background-color: #54806a;
        border-color: #54806a;
    }

    .user-action-btn.btn-danger {
        color: #fff;
        background-color: #a85b5b;
        border-color: #a85b5b;
    }

    .user-action-btn.btn-info {
        color: #173d43;
        background-color: #a9cdd0;
        border-color: #a9cdd0;
    }

    .user-action-btn.btn-primary:hover,
    .user-action-btn.btn-success:hover,
    .user-action-btn.btn-danger:hover {
        color: #fff;
        filter: brightness(0.92);
    }

    .user-action-btn.btn-warning:hover,
    .user-action-btn.btn-info:hover {
        color: #17212b;
        filter: brightness(0.95);
    }
</style>
<script src="/assets/js/users.js"></script>
