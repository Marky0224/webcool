<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$inspections = array_values(array_filter(get_array_values(firebase_get('inspections')), 'is_array'));
$monthlyTotals = [];
$availableYears = [];
foreach ($inspections as $inspection) {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    if (!isset($inspectionData['ante_mortem']) && ($inspection['status'] ?? '') !== 'Ante-Mortem') {
        continue;
    }

    $submissionDate = substr((string) ($inspection['created_at'] ?? $inspection['inspection_date'] ?? ''), 0, 10);
    $parsedSubmissionDate = DateTime::createFromFormat('!Y-m-d', $submissionDate);
    if (!$parsedSubmissionDate || $parsedSubmissionDate->format('Y-m-d') !== $submissionDate) {
        continue;
    }

    $month = $parsedSubmissionDate->format('Y-m');
    $monthlyTotals[$month] = ($monthlyTotals[$month] ?? 0) + 1;
    $availableYears[$parsedSubmissionDate->format('Y')] = true;
}
if (!isset($availableYears[date('Y')])) {
    $availableYears[date('Y')] = true;
}
$availableYears = array_map('strval', array_keys($availableYears));
rsort($availableYears);
$requestedYear = trim((string) ($_GET['year'] ?? ''));
$selectedYear = in_array($requestedYear, $availableYears, true)
    ? $requestedYear
    : $availableYears[0];
$monthlyTotalsForYear = [];
for ($month = 1; $month <= 12; $month++) {
    $monthKey = $selectedYear . '-' . str_pad((string) $month, 2, '0', STR_PAD_LEFT);
    $monthlyTotalsForYear[$monthKey] = $monthlyTotals[$monthKey] ?? 0;
}
$requestedDate = trim((string) ($_GET['date'] ?? ''));
$selectedDate = DateTime::createFromFormat('!Y-m-d', $requestedDate);
if (!$selectedDate || $selectedDate->format('Y-m-d') !== $requestedDate) {
    $selectedDate = new DateTime('today');
}
$selectedDateValue = $selectedDate->format('Y-m-d');
$documentTitle = 'Daily Ante-Mortem Report';
$anteMortemRecords = [];
foreach ($inspections as $inspection) {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    $anteMortem = is_array($inspectionData['ante_mortem'] ?? null) ? $inspectionData['ante_mortem'] : [];
    $recordDate = substr((string) ($inspection['inspection_date'] ?? $inspection['created_at'] ?? ''), 0, 10);
    if (!$anteMortem || $recordDate !== $selectedDateValue) {
        continue;
    }

    $customer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
    $anteMortemRecords[] = [
        'inspection_id' => (string) ($inspection['inspection_id'] ?? 'N/A'),
        'customer_code' => (string) ($customer['owner_code'] ?? $customer['customer_id'] ?? $inspection['customer_id'] ?? 'N/A'),
        'customer_name' => (string) ($customer['owner_name'] ?? $inspection['customer_name'] ?? 'N/A'),
        'heads' => (string) ($anteMortem['no_of_heads'] ?? 'N/A'),
        'farm_owner' => (string) ($anteMortem['farm_owner'] ?? 'N/A'),
        'origin' => (string) ($anteMortem['origin'] ?? 'N/A'),
        'category' => get_ante_mortem_category_code((string) ($anteMortem['category'] ?? 'N/A')),
        'document' => is_array($anteMortem['document_presented'] ?? null)
            ? implode(', ', array_map(static fn($document): string => get_ante_mortem_document_label((string) $document), $anteMortem['document_presented']))
            : get_ante_mortem_document_label((string) ($anteMortem['document_presented'] ?? 'N/A')),
        'document_number' => (string) ($anteMortem['document_number'] ?? ''),
        'inspector' => (string) ($inspection['inspector_name'] ?? 'N/A'),
    ];
}

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="reports-page-heading d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Reports</h3>
                <p class="text-secondary mb-0">Ante Mortem records for <?php echo htmlspecialchars($selectedDate->format('F d, Y')); ?>.</p>
            </div>
        </div>

        <div class="card shadow-sm border-0 mb-4 reports-print-section" id="monthly-ante-mortem-summary">
            <div class="card-body">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
                    <h5 class="card-title mb-0">Monthly Ante-Mortem Summary</h5>
                    <div class="d-flex align-items-center gap-2 no-print">
                        <form class="d-flex align-items-center gap-2" action="/admin/reports.php" method="get">
                            <input type="hidden" name="date" value="<?php echo htmlspecialchars($selectedDateValue); ?>">
                            <label class="form-label mb-0" for="summaryYear">Year</label>
                            <select class="form-select form-select-sm" id="summaryYear" name="year">
                                <?php foreach ($availableYears as $year): ?>
                                    <option value="<?php echo htmlspecialchars($year); ?>"<?php echo $year === $selectedYear ? ' selected' : ''; ?>><?php echo htmlspecialchars($year); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-sm btn-outline-primary" type="submit">View</button>
                        </form>
                        <button class="btn btn-sm btn-primary" type="button" onclick="printReportSection('monthly-summary')"><i class="fa-solid fa-print me-1"></i>Print Summary</button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Total Records Submitted</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($monthlyTotalsForYear as $month => $total): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars(DateTime::createFromFormat('!Y-m', $month)->format('F Y')); ?></td>
                                    <td><?php echo number_format($total); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0 reports-ante-mortem-card reports-print-section" id="ante-mortem-report">
            <div class="card-body">
                <div class="reports-print-header">
                    <p class="mb-1">OFFICE OF THE CITY VETERINARIAN</p>
                    <p class="mb-1">Lipa City</p>
                    <p class="mb-3">MEAT INSPECTION DIVISION</p>
                    <h1 class="mb-1">DAILY ANTE-MORTEM REPORT</h1>
                    <p class="mb-0">Date: <?php echo htmlspecialchars($selectedDate->format('F d, Y')); ?></p>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3 reports-records-heading">
                    <div>
                        <h5 class="mb-1">Ante Mortem Records</h5>
                        <p class="text-secondary mb-0"><?php echo count($anteMortemRecords); ?> record(s) found for the selected date.</p>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-primary"><?php echo htmlspecialchars($selectedDate->format('F d, Y')); ?></span>
                        <button class="btn btn-sm btn-primary no-print" type="button" onclick="printReportSection('ante-mortem')"><i class="fa-solid fa-print me-1"></i>Print Records</button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle reports-ante-mortem-table mb-0">
                        <thead>
                            <tr>
                                <th class="reports-print-hide">Inspection ID</th>
                                <th>Owner / Code</th>
                                <th>No. of Heads</th>
                                <th>Name of Farm / Farmer</th>
                                <th>Origin / Place</th>
                                <th>Category</th>
                                <th>Document Presented</th>
                                <th class="reports-print-hide">Inspector</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($anteMortemRecords as $record): ?>
                                <tr>
                                    <td class="reports-print-hide"><?php echo htmlspecialchars($record['inspection_id']); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($record['customer_name']); ?></strong>
                                        <small class="d-block text-secondary"><?php echo htmlspecialchars($record['customer_code']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($record['heads']); ?></td>
                                    <td><?php echo htmlspecialchars($record['farm_owner']); ?></td>
                                    <td><?php echo htmlspecialchars($record['origin']); ?></td>
                                    <td><?php echo htmlspecialchars($record['category']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($record['document']); ?>
                                        <?php if ($record['document_number'] !== ''): ?>
                                            <small class="d-block text-secondary"><?php echo htmlspecialchars($record['document_number']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td class="reports-print-hide"><?php echo htmlspecialchars($record['inspector']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (!$anteMortemRecords): ?>
                        <p class="text-secondary text-center py-4 mb-0">No Ante Mortem records were found for this date.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .reports-print-header {
        display: none;
    }

    @media print {
        @page {
            size: A4 landscape;
            margin: 0;
        }

        body.reports-page .sidebar,
        body.reports-page .admin-navbar,
        body.reports-page #sidebarOverlay,
        body.reports-page .toast-container {
            display: none !important;
        }

        body.reports-page[data-report-print="monthly-summary"] #ante-mortem-report,
        body.reports-page:not([data-report-print="monthly-summary"]) #monthly-ante-mortem-summary,
        body.reports-page .reports-page-heading {
            display: none !important;
        }

        body.reports-page .reports-print-section {
            display: block !important;
            width: 100% !important;
            margin: 0 !important;
        }

        body.reports-page:not([data-report-print="monthly-summary"]) .reports-ante-mortem-card .badge,
        body.reports-page:not([data-report-print="monthly-summary"]) .reports-records-heading {
            display: none !important;
        }

        body.reports-page .main-content {
            margin: 0 !important;
            padding: 0 !important;
        }

        body.reports-page .container-fluid {
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            padding: 12mm !important;
        }

        body.reports-page .reports-print-header {
            display: block !important;
            margin-bottom: 1.25rem;
            color: #000 !important;
            text-align: center;
        }

        body.reports-page .reports-print-header p {
            margin: 0;
            color: #000 !important;
            font-size: 10pt;
        }

        body.reports-page .reports-print-header h1 {
            margin-top: 1rem !important;
            font-size: 15pt;
            font-weight: 700;
        }

        body.reports-page .reports-ante-mortem-card,
        body.reports-page .reports-ante-mortem-card .card-body,
        body.reports-page .reports-ante-mortem-card .table-responsive {
            overflow: visible !important;
        }

        body.reports-page .reports-ante-mortem-table {
            width: 100% !important;
            min-width: 0 !important;
            table-layout: fixed;
            border-collapse: collapse !important;
            font-size: 9pt;
        }

        body.reports-page .reports-ante-mortem-table th,
        body.reports-page .reports-ante-mortem-table td {
            padding: 6px !important;
            color: #000 !important;
            border: 1px solid #444 !important;
            white-space: normal !important;
            overflow-wrap: anywhere;
            vertical-align: top;
        }

        body.reports-page .reports-ante-mortem-table thead {
            display: table-header-group;
        }

        body.reports-page .reports-ante-mortem-table tr {
            break-inside: avoid;
        }

        body.reports-page .reports-ante-mortem-table .reports-print-hide {
            display: none !important;
        }

        body.reports-page .reports-ante-mortem-table thead th {
            background: #e9ecef !important;
            font-weight: 700;
        }

        body.reports-page .reports-ante-mortem-table th:nth-child(2),
        body.reports-page .reports-ante-mortem-table td:nth-child(2) {
            width: 15%;
        }

        body.reports-page .reports-ante-mortem-table th:nth-child(3),
        body.reports-page .reports-ante-mortem-table td:nth-child(3) {
            width: 8%;
        }

        body.reports-page .reports-ante-mortem-table th:nth-child(4),
        body.reports-page .reports-ante-mortem-table td:nth-child(4) {
            width: 19%;
        }

        body.reports-page .reports-ante-mortem-table th:nth-child(5),
        body.reports-page .reports-ante-mortem-table td:nth-child(5) {
            width: 13%;
        }

        body.reports-page .reports-ante-mortem-table th:nth-child(6),
        body.reports-page .reports-ante-mortem-table td:nth-child(6) {
            width: 10%;
        }

        body.reports-page .reports-ante-mortem-table th:nth-child(7),
        body.reports-page .reports-ante-mortem-table td:nth-child(7) {
            width: 35%;
        }

        body.reports-page .reports-ante-mortem-table tbody tr:nth-child(odd) td {
            background: #f5f5f5 !important;
        }
    }
</style>
<script>
    const originalPrintTitle = document.title;

    function printReportSection(section) {
        document.body.dataset.reportPrint = section;
        document.title = section === 'ante-mortem'
            ? 'Daily Ante-Mortem Report - <?php echo htmlspecialchars($selectedDate->format('F d, Y'), ENT_QUOTES); ?>'
            : 'Monthly Ante-Mortem Summary - <?php echo htmlspecialchars($selectedYear, ENT_QUOTES); ?>';
        window.print();
    }

    window.addEventListener('afterprint', function () {
        delete document.body.dataset.reportPrint;
        document.title = originalPrintTitle;
    });
</script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
