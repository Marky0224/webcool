<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$requests = get_array_values(firebase_get('inspection_requests'));
$registrations = get_array_values(firebase_get('client_registrations'));

$statusCounts = [
    'Waiting for Inspection' => count_status($requests, 'Waiting for Inspection'),
    'Approved' => count_status($requests, 'Approved'),
    'Partially Condemned' => count_status($requests, 'Partially Condemned'),
    'Condemned' => count_status($requests, 'Condemned'),
];

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Reports</h3>
                <p class="text-secondary mb-0">Use this panel to review inspection and registration trends.</p>
            </div>
            <button class="btn btn-success"><i class="fa-solid fa-file-export me-2"></i>Export Summary</button>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-6 col-xl-3">
                <div class="card shadow-sm border-0 p-3">
                    <h6 class="text-secondary mb-2">Total Inspection Requests</h6>
                    <h3 class="fw-bold"><?php echo count($requests); ?></h3>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="card shadow-sm border-0 p-3">
                    <h6 class="text-secondary mb-2">Total Client Registrations</h6>
                    <h3 class="fw-bold"><?php echo count($registrations); ?></h3>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="card shadow-sm border-0 p-3">
                    <h6 class="text-secondary mb-2">Open Inspections</h6>
                    <h3 class="fw-bold"><?php echo $statusCounts['Waiting for Inspection']; ?></h3>
                </div>
            </div>
            <div class="col-md-6 col-xl-3">
                <div class="card shadow-sm border-0 p-3">
                    <h6 class="text-secondary mb-2">Condemned Cases</h6>
                    <h3 class="fw-bold"><?php echo $statusCounts['Condemned']; ?></h3>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <h5 class="card-title mb-3">Inspection Status Breakdown</h5>
                <canvas id="statusChart" width="400" height="220"></canvas>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h5 class="mb-3">Download Reports</h5>
                <div class="d-flex flex-wrap gap-2">
                    <button class="btn btn-outline-primary">Daily PDF</button>
                    <button class="btn btn-outline-primary">Weekly Excel</button>
                    <button class="btn btn-outline-primary">Monthly PDF</button>
                    <button class="btn btn-outline-primary">Yearly Excel</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    const statusChartData = {
        labels: <?php echo json_encode(array_keys($statusCounts)); ?>,
        datasets: [{
            label: 'Inspection Status Counts',
            data: <?php echo json_encode(array_values($statusCounts)); ?>,
            backgroundColor: ['#C62828', '#2196F3', '#FFC107', '#9C27B0'],
        }]
    };
    window.addEventListener('DOMContentLoaded', () => {
        const statusCtx = document.getElementById('statusChart');
        if (statusCtx) {
            new Chart(statusCtx, {
                type: 'bar',
                data: statusChartData,
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: false },
                    }
                }
            });
        }
    });
</script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
