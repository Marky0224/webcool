<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$documentTitle = 'Reports';
$activityLogsResult = firebase_request('GET', 'activity_logs');
$activityLogsError = is_array($activityLogsResult) && isset($activityLogsResult['error']);
$activityLogs = !$activityLogsError && is_array($activityLogsResult)
    ? array_values(array_filter($activityLogsResult, 'is_array'))
    : [];
usort($activityLogs, static function (array $first, array $second): int {
    return strcmp((string) ($second['created_at'] ?? ''), (string) ($first['created_at'] ?? ''));
});
require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="card shadow-sm border-0 mt-4 reports-activity-logs">
            <div class="card-body">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
                    <div>
                        <h5 class="mb-1">Activity Logs</h5>
                        <p class="text-secondary small mb-0">Recent account and record changes, newest first.</p>
                    </div>
                </div>
                <?php if ($activityLogsError): ?>
                    <div class="alert alert-danger mb-0">Unable to load activity logs from Firebase. Please try again later.</div>
                <?php elseif (!$activityLogs): ?>
                    <div class="alert alert-light border mb-0">No activity has been recorded yet.</div>
                <?php else: ?>
                    <div class="reports-activity-controls">
                        <div class="reports-activity-print no-print">
                            <button class="btn btn-sm print-button" type="button" onclick="window.print()">
                                <i class="fa-solid fa-print me-1"></i>Print
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover align-middle datatable mb-0" data-page-length="25">
                            <thead>
                                <tr>
                                    <th scope="col">Date and Time</th>
                                    <th scope="col">User</th>
                                    <th scope="col">Action</th>
                                    <th scope="col">Record</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($activityLogs as $activityLog):
                                    $activityTimestamp = strtotime((string) ($activityLog['created_at'] ?? ''));
                                ?>
                                    <tr>
                                        <td><?php echo $activityTimestamp !== false ? htmlspecialchars(date('M d, Y h:i A', $activityTimestamp)) : 'N/A'; ?></td>
                                        <td>
                                            <?php echo htmlspecialchars((string) ($activityLog['actor_name'] ?? 'Unknown')); ?>
                                            <span class="text-secondary small">(<?php echo htmlspecialchars((string) ($activityLog['actor_role'] ?? '')); ?>)</span>
                                        </td>
                                        <td><?php echo htmlspecialchars((string) ($activityLog['action'] ?? 'Activity')); ?></td>
                                        <td><?php echo htmlspecialchars((string) ($activityLog['resource'] ?? '')); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
