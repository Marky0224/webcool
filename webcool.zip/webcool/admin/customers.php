<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

if (empty($_SESSION['customer_delete_csrf_token'])) {
    $_SESSION['customer_delete_csrf_token'] = bin2hex(random_bytes(32));
}
$customerDeleteCsrfToken = (string) $_SESSION['customer_delete_csrf_token'];
$deleteMessage = null;
$deleteError = null;

$customersRaw = firebase_get('customers');
$customers = is_array($customersRaw) ? array_filter($customersRaw, 'is_array') : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_customer') {
    $submittedToken = (string) ($_POST['csrf_token'] ?? '');
    $customerKey = trim((string) ($_POST['customer_key'] ?? ''));
    $deletionReason = trim((string) ($_POST['deletion_reason'] ?? ''));
    if ($submittedToken === '' || !hash_equals($customerDeleteCsrfToken, $submittedToken)) {
        $deleteError = 'Unable to delete the customer because the security token is invalid.';
    } elseif (!preg_match('/\A[A-Za-z0-9_-]+\z/', $customerKey)) {
        $deleteError = 'Unable to delete the customer because its record key is invalid.';
    } elseif (!array_key_exists($customerKey, $customers)) {
        $deleteError = 'This customer no longer exists. Refresh the page and try again.';
    } elseif ($deletionReason === '' || strlen($deletionReason) > 1000) {
        $deleteError = 'A deletion reason is required and must be 1,000 characters or fewer.';
    } else {
        $customer = $customers[$customerKey];
        $actorRole = !empty($_SESSION['admin_logged_in']) ? 'Admin' : 'System';
        $actorName = (string) ($_SESSION['admin_username'] ?? 'Admin');
        $auditEntry = [
            'action' => 'Deleted customer record',
            'resource' => 'customers/' . $customerKey,
            'actor_name' => $actorName,
            'actor_role' => $actorRole,
            'created_at' => date('c'),
            'deletion_reason' => $deletionReason,
            'deleted_record' => $customer,
        ];
        $auditRequest = firebase_request('POST', 'activity_logs', $auditEntry);
        if (is_array($auditRequest) && isset($auditRequest['error'])) {
            $deleteError = 'Unable to save the deletion record. The customer was not deleted.';
        } else {
            $deleteRequest = firebase_request_with_metadata('DELETE', 'customers/' . $customerKey);
            if ($deleteRequest['error'] !== null || $deleteRequest['status'] >= 400) {
                $deleteError = 'Unable to delete the customer. Please try again.';
            } else {
                $customerName = (string) ($customer['owner_name'] ?? $customer['customer_id'] ?? $customerKey);
                $deleteMessage = 'Customer ' . $customerName . ' was deleted successfully.';
            }
        }
    }

    $customersRaw = firebase_get('customers');
    $customers = is_array($customersRaw) ? array_filter($customersRaw, 'is_array') : [];
}

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Customers</h3>
                <p class="text-secondary mb-0">Showing all registered customer profiles.</p>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <?php if ($deleteMessage !== null): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($deleteMessage); ?></div>
                <?php elseif ($deleteError !== null): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($deleteError); ?></div>
                <?php endif; ?>
                <div class="admin-record-controls">
                    <div class="admin-record-print no-print">
                        <button class="btn btn-sm print-button" type="button" onclick="window.print()">
                            <i class="fa-solid fa-print me-1"></i>Print
                        </button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover datatable mb-0" data-default-order-column="0" data-default-order-dir="asc">
                        <thead>
                            <tr>
                                <th>Customer ID</th>
                                <th>Name</th>
                                <th>Code</th>
                                <th>Contact</th>
                                <th>Barangay of Animal Origin</th>
                                <th>Farm / Supplier</th>
                                <th>Category</th>
                                <th>Registered</th>
                                <th>QR</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($customers as $key => $customer): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($customer['customer_id'] ?? $key); ?></td>
                                    <td><?php echo htmlspecialchars(format_person_name((string) ($customer['owner_name'] ?? 'N/A'))); ?></td>
                                    <td><?php echo htmlspecialchars($customer['owner_code'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($customer['contact_number'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($customer['barangay_of_animal_origin'] ?? $customer['origin'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($customer['farm_supplier_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars(['B' => 'Backyard', 'C' => 'Commercial', 'S' => 'Stockyard'][get_ante_mortem_category_code((string) ($customer['category'] ?? ''))] ?? 'N/A'); ?></td>
                                    <td>
                                        <?php
                                        $registeredAt = (string) ($customer['created_at'] ?? '');
                                        echo htmlspecialchars($registeredAt !== '' ? date('M d, Y h:i A', strtotime($registeredAt)) : 'N/A');
                                        ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($customer['qr_image'])): ?>
                                            <span class="badge bg-success">Saved</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark">Missing</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="/admin/customer_profile.php?id=<?php echo urlencode($key); ?>" class="btn btn-sm btn-outline-primary">View</a>
                                        <form method="post" class="d-inline" onsubmit="return confirmCustomerDeletion(this, '<?php echo htmlspecialchars(format_person_name((string) ($customer['owner_name'] ?? $customer['customer_id'] ?? $key)), ENT_QUOTES, 'UTF-8'); ?>');">
                                            <input type="hidden" name="action" value="delete_customer">
                                            <input type="hidden" name="customer_key" value="<?php echo htmlspecialchars((string) $key, ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($customerDeleteCsrfToken, ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="deletion_reason" value="">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($customers)): ?>
                                <tr>
                                    <td class="text-center">No customers registered yet.</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function confirmCustomerDeletion(form, customerName) {
        if (!window.confirm('Delete ' + customerName + '? This action cannot be undone.')) {
            return false;
        }
        const reason = window.prompt('Enter the required reason for deleting this customer:');
        if (reason === null || reason.trim() === '') {
            window.alert('A deletion reason is required.');
            return false;
        }
        form.elements.deletion_reason.value = reason.trim();
        return true;
    }
</script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>