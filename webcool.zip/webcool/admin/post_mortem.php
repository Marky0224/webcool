<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$allInspections = array_values(array_filter(get_array_values(firebase_get('inspections')), 'is_array'));
$inspections = array_values(array_filter($allInspections, function ($item) {
	$inspectionData = is_array($item['inspection_data'] ?? null) ? $item['inspection_data'] : [];
	return isset($inspectionData['slaughter']) || !empty($inspectionData['decision']) || in_array($item['status'] ?? '', ['Slaughter', 'Passed', 'Partially Condemned', 'Condemned'], true);
}));
$summary = [
	'total' => count($inspections),
	'waiting' => count(array_filter($inspections, fn($item) => ($item['status'] ?? '') === 'Waiting for Client')),
	'slaughter' => count(array_filter($inspections, fn($item) => ($item['status'] ?? '') === 'Slaughter')),
];
$pageHeading = 'Post-Mortem Inspections';
$pageDescription = 'Review slaughter details and post-mortem inspection decisions.';

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
	<?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
	<div class="container-fluid px-4 py-4">
		<div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
			<div>
				<h3 class="mb-1"><?php echo htmlspecialchars($pageHeading); ?></h3>
				<p class="text-secondary mb-0"><?php echo htmlspecialchars($pageDescription); ?></p>
			</div>
			<a href="/inspector/inspection_create.php" class="btn btn-success"><i class="fa-solid fa-plus me-2"></i>Create New Inspection</a>
		</div>

		<div class="row g-3 mb-4">
			<?php foreach ([
				['label' => 'Total Active Inspections', 'value' => $summary['total'], 'icon' => 'fa-list', 'color' => 'success'],
				['label' => 'Waiting for Client', 'value' => $summary['waiting'], 'icon' => 'fa-hourglass-half', 'color' => 'warning'],
				['label' => 'Slaughter', 'value' => $summary['slaughter'], 'icon' => 'fa-skull-crossbones', 'color' => 'danger'],
			] as $card): ?>
				<div class="col-md-6 col-xl-3">
					<div class="card shadow-sm border-0 p-3">
						<div class="d-flex align-items-center justify-content-between mb-3">
							<div class="text-muted"><i class="fa-solid <?php echo $card['icon']; ?> fa-lg"></i></div>
							<span class="badge bg-<?php echo $card['color']; ?>-light text-<?php echo $card['color']; ?>"><?php echo $card['value']; ?></span>
						</div>
						<h6 class="text-secondary mb-1"><?php echo $card['label']; ?></h6>
						<h3 class="fw-bold"><?php echo $card['value']; ?></h3>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="card shadow-sm border-0">
			<div class="card-body">
				<h5 class="card-title mb-3"><?php echo htmlspecialchars($pageHeading); ?> Records</h5>
				<div class="table-responsive">
					<table class="table table-striped table-hover datatable mb-0">
						<thead>
							<tr>
								<th>Inspection ID</th>
								<th>Customer</th>
								<th>Inspector</th>
								<th>Status</th>
								<th>Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($inspections as $inspection): ?>
								<tr>
									<td><?php echo htmlspecialchars($inspection['inspection_id'] ?? 'N/A'); ?></td>
									<td><?php echo htmlspecialchars($inspection['customer_name'] ?? $inspection['customer_id'] ?? 'N/A'); ?></td>
									<td><?php echo htmlspecialchars($inspection['inspector_name'] ?? 'N/A'); ?></td>
									<td><?php echo htmlspecialchars($inspection['status'] ?? 'N/A'); ?></td>
									<td><?php echo htmlspecialchars($inspection['inspection_date'] ?? $inspection['created_at'] ?? 'N/A'); ?></td>
									<td><a href="/inspector/inspection_detail.php?inspection_id=<?php echo urlencode($inspection['inspection_id'] ?? ''); ?>" class="btn btn-sm btn-outline-primary">View</a></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>