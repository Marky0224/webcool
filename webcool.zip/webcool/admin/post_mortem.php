<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

$allInspections = array_values(array_filter(get_array_values(firebase_get('inspections')), 'is_array'));
$requestedDate = trim((string) ($_GET['date'] ?? ''));
$selectedDate = DateTime::createFromFormat('!Y-m-d', $requestedDate);
$selectedDateValue = $selectedDate && $selectedDate->format('Y-m-d') === $requestedDate
    ? $selectedDate->format('Y-m-d')
    : '';
$getRecordDate = static function (array $item): string {
    $inspectionData = is_array($item['inspection_data'] ?? null) ? $item['inspection_data'] : [];
    foreach ([
        $inspectionData['slaughter_date'] ?? '',
        $inspectionData['date_issued'] ?? '',
        $item['inspection_date'] ?? '',
        $item['created_at'] ?? '',
        $item['certificate_created_at'] ?? '',
    ] as $dateValue) {
        $candidateDate = substr(trim((string) $dateValue), 0, 10);
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $candidateDate)) {
            return $candidateDate;
        }
    }
    return '';
};
$inspections = array_values(array_filter($allInspections, static function (array $item) use ($selectedDateValue, $getRecordDate): bool {
    if ($selectedDateValue !== '' && $getRecordDate($item) !== $selectedDateValue) {
        return false;
    }

    $inspectionData = is_array($item['inspection_data'] ?? null) ? $item['inspection_data'] : [];

    $meatDetails = is_array($inspectionData['meat_details'] ?? null) ? $inspectionData['meat_details'] : [];
    $hasReleasedMeat = false;
    foreach (['pork', 'beef', 'carabeef', 'entrails'] as $meatType) {
        $detail = is_array($meatDetails[$meatType] ?? null) ? $meatDetails[$meatType] : [];
        if ((is_numeric($detail['qty'] ?? null) && (float) $detail['qty'] > 0)
            || (is_numeric($detail['weight'] ?? null) && (float) $detail['weight'] > 0)) {
            $hasReleasedMeat = true;
            break;
        }
    }
    $status = strtolower((string) ($item['status'] ?? ''));
    $hasPostMortemData = isset($inspectionData['slaughter'])
        || !empty($inspectionData['decision'])
        || in_array($status, ['mic', 'slaughter', 'passed', 'partially condemned', 'condemned'], true)
        || $hasReleasedMeat;

    return $hasPostMortemData;
}));

$records = [];
foreach ($inspections as $index => $inspection) {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    $customer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
    $meatDetails = is_array($inspectionData['meat_details'] ?? null) ? $inspectionData['meat_details'] : [];
    $releasedMeats = [];
    $meatBreakdown = [];
    $releasedQuantity = 0;
    $releasedWeight = 0.0;
    $hasReleasedWeight = false;
    foreach (['pork', 'beef', 'carabeef', 'entrails'] as $meatType) {
        $detail = is_array($meatDetails[$meatType] ?? null) ? $meatDetails[$meatType] : [];
        $quantity = is_numeric($detail['qty'] ?? null) ? (float) $detail['qty'] : 0.0;
        $weight = is_numeric($detail['weight'] ?? null) ? (float) $detail['weight'] : 0.0;
        if ($quantity > 0 || $weight > 0) {
            $releasedMeats[] = ucfirst($meatType);
            $releasedQuantity += (int) $quantity;
            $releasedWeight += $weight;
            $hasReleasedWeight = $hasReleasedWeight || is_numeric($detail['weight'] ?? null);
            $meatBreakdown[] = [
                'type' => ucfirst($meatType),
                'quantity' => $quantity,
                'weight' => $weight,
            ];
        }
    }

    $records[] = [
        'details_id' => 'post-mortem-details-' . $index,
        'record_number' => 'PM-' . date('Y') . '-' . str_pad((string) ($index + 1), 3, '0', STR_PAD_LEFT),
        'inspection_id' => (string) ($inspection['inspection_id'] ?? ''),
        'customer_code' => (string) ($customer['owner_code'] ?? $customer['customer_id'] ?? $inspection['customer_id'] ?? 'N/A'),
        'customer_name' => (string) ($customer['owner_name'] ?? $inspection['customer_name'] ?? 'N/A'),
        'meat_released' => $releasedMeats ? implode(', ', $releasedMeats) : 'N/A',
        'meat_breakdown' => $meatBreakdown,
        'slaughter_date' => $getRecordDate($inspection) !== '' ? $getRecordDate($inspection) : 'N/A',
        'released_quantity' => $releasedQuantity > 0 ? (string) $releasedQuantity : 'N/A',
        'released_weight' => $hasReleasedWeight ? number_format($releasedWeight, 2) : 'N/A',
        'inspection_date' => (string) ($inspection['inspection_date'] ?? $inspection['created_at'] ?? 'N/A'),
        'inspector' => (string) ($inspection['inspector_name'] ?? 'Linked inspector account'),
        'status' => (string) ($inspection['status'] ?? 'N/A'),
    ];
}

$summary = [
    'total' => count($records),
    'slaughter' => count(array_filter($inspections, static fn(array $item): bool => ($item['status'] ?? '') === 'Slaughter')),
];

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <main class="container-fluid px-4 py-4 post-mortem-page">
        <div class="post-mortem-heading">
            <span class="post-mortem-heading-icon"><i class="fa-solid fa-database"></i></span>
            <div>
                <h1>All Post-Mortem Records</h1>
                <p><?php echo $selectedDateValue === '' ? 'Showing records from all dates.' : 'Records from all meat inspectors for ' . htmlspecialchars($selectedDate->format('F d, Y')) . '.'; ?></p>
            </div>
            <form class="d-flex flex-wrap align-items-end gap-2" method="get" action="/admin/post_mortem.php">
                <div>
                    <label class="form-label small mb-1" for="postMortemDate">Filter by date</label>
                    <input class="form-control" type="date" id="postMortemDate" name="date" value="<?php echo htmlspecialchars($selectedDateValue); ?>">
                </div>
                <button class="btn btn-primary" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button>
                <?php if ($selectedDateValue !== ''): ?>
                    <a class="btn btn-outline-secondary" href="/admin/post_mortem.php">Show all</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="post-mortem-summary">
            <span>Total Records: <strong><?php echo $summary['total']; ?></strong></span>
            <span>Slaughter: <strong><?php echo $summary['slaughter']; ?></strong></span>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <div class="post-mortem-print-controls d-flex justify-content-end mb-3">
                    <button class="btn btn-sm btn-outline-secondary" type="button" onclick="window.print();">
                        <i class="fa-solid fa-print me-1"></i>Print
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle post-mortem-table datatable mb-0" data-page-length="25">
                        <thead>
                            <tr>
                                <th>Record Number</th>
                                <th>Customer / Code</th>
                                <th>Meat Released</th>
                                <th>Slaughter Date</th>
                                <th>Quantity Released</th>
                                <th>Released Weight (kg)</th>
                                <th>Inspection Date</th>
                                <th>Inspector</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr id="pm-<?php echo htmlspecialchars($record['inspection_id']); ?>">
                                    <td><?php echo htmlspecialchars($record['record_number']); ?></td>
                                    <td><?php echo htmlspecialchars($record['customer_code']); ?></td>
                                    <td><?php echo htmlspecialchars($record['meat_released']); ?></td>
                                    <td><?php echo htmlspecialchars($record['slaughter_date']); ?></td>
                                    <td><?php echo htmlspecialchars($record['released_quantity']); ?></td>
                                    <td><?php echo htmlspecialchars($record['released_weight']); ?></td>
                                    <td><?php echo htmlspecialchars($record['inspection_date']); ?></td>
                                    <td><?php echo htmlspecialchars($record['inspector']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="modal" data-bs-target="#<?php echo htmlspecialchars($record['details_id']); ?>">
                                            <i class="fa-regular fa-eye me-1"></i>View Details
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (!$records): ?>
                                <tr>
                                    <td colspan="9" class="text-center text-secondary py-4">No post-mortem records found<?php echo $selectedDateValue !== '' ? ' for this date' : ''; ?>.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php foreach ($records as $record): ?>
                    <div class="modal fade" id="<?php echo htmlspecialchars($record['details_id']); ?>" tabindex="-1" aria-labelledby="<?php echo htmlspecialchars($record['details_id']); ?>-label" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title fs-5" id="<?php echo htmlspecialchars($record['details_id']); ?>-label">Post-Mortem Details</h2>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <dl class="row mb-3">
                                        <dt class="col-sm-5">Record Number</dt>
                                        <dd class="col-sm-7"><?php echo htmlspecialchars($record['record_number']); ?></dd>
                                        <dt class="col-sm-5">Inspection ID</dt>
                                        <dd class="col-sm-7"><?php echo htmlspecialchars($record['inspection_id'] !== '' ? $record['inspection_id'] : 'N/A'); ?></dd>
                                        <dt class="col-sm-5">Customer</dt>
                                        <dd class="col-sm-7"><?php echo htmlspecialchars($record['customer_name'] . ' / ' . $record['customer_code']); ?></dd>
                                        <dt class="col-sm-5">Slaughter Date</dt>
                                        <dd class="col-sm-7"><?php echo htmlspecialchars($record['slaughter_date']); ?></dd>
                                        <dt class="col-sm-5">Inspector</dt>
                                        <dd class="col-sm-7"><?php echo htmlspecialchars($record['inspector']); ?></dd>
                                        <dt class="col-sm-5">Status</dt>
                                        <dd class="col-sm-7"><?php echo htmlspecialchars($record['status']); ?></dd>
                                    </dl>
                                    <h3 class="h6">Released Meat Breakdown</h3>
                                    <?php if ($record['meat_breakdown']): ?>
                                        <div class="table-responsive">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr><th>Meat Type</th><th>Quantity</th><th>Weight (kg)</th></tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($record['meat_breakdown'] as $meat): ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($meat['type']); ?></td>
                                                            <td><?php echo htmlspecialchars((string) $meat['quantity']); ?></td>
                                                            <td><?php echo htmlspecialchars(number_format($meat['weight'], 2)); ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-secondary mb-0">No released meat details were recorded.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
