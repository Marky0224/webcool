<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_admin_logged_in();

require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/admin_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Settings</h3>
                <p class="text-secondary mb-0">Manage administrator and system configuration.</p>
            </div>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h5 class="mb-4">Administrator Profile</h5>
                <form>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Administrator Username</label>
                            <input type="text" class="form-control" value="admin" disabled>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Notification Email</label>
                            <input type="email" class="form-control" value="admin@example.com" disabled>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" value="********" disabled>
                                <button type="button" class="btn btn-outline-primary">Reset Password</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
