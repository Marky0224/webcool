<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$errors = [];
$message = null;
$customer = null;
$form = [
    'first_name' => '',
    'last_name' => '',
    'middle_name' => '',
    'suffix' => '',
    'owner_code' => '',
    'contact_number' => '',
    'barangay_of_animal_origin' => '',
    'farm_supplier_name' => '',
    'category' => '',
];
$suffixOptions = ['', 'Jr.', 'Sr.', 'II', 'III', 'IV', 'V'];
$categoryOptions = ['B' => 'Backyard', 'C' => 'Commercial', 'S' => 'Stockyard'];
$barangayDatasetPath = __DIR__ . '/../assets/data/lipa-city-barangays.geojson';
$barangayDatasetContents = is_file($barangayDatasetPath) ? file_get_contents($barangayDatasetPath) : false;
$barangayDataset = is_string($barangayDatasetContents) ? json_decode($barangayDatasetContents, true) : null;
$barangays = [];
foreach (is_array($barangayDataset['features'] ?? null) ? $barangayDataset['features'] : [] as $feature) {
    $properties = is_array($feature['properties'] ?? null) ? $feature['properties'] : [];
    $name = trim((string) ($properties['name'] ?? ''));
    if ($name !== '') {
        $barangays[] = $name;
    }
}
$barangays = array_values(array_unique($barangays));
sort($barangays, SORT_NATURAL | SORT_FLAG_CASE);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $field => $default) {
        $value = $_POST[$field] ?? $default;
        $form[$field] = is_string($value) ? trim($value) : '';
    }

    $firstName = $form['first_name'];
    $lastName = $form['last_name'];
    $middleName = $form['middle_name'];
    $suffix = $form['suffix'];
    $ownerCode = $form['owner_code'];
    $contactNumber = $form['contact_number'];
    $barangayOrigin = $form['barangay_of_animal_origin'];
    $farmSupplierName = $form['farm_supplier_name'];
    $category = $form['category'];
    $firstName = format_person_name($firstName);
    $lastName = format_person_name($lastName);
    $form['first_name'] = $firstName;
    $form['last_name'] = $lastName;

    if ($firstName === '' || $lastName === '') {
        $errors[] = 'First name and last name are required.';
    }
    foreach (['First name' => $firstName, 'Last name' => $lastName, 'Middle name' => $middleName] as $label => $namePart) {
        if (strlen($namePart) > 100) {
            $errors[] = $label . ' must be 100 characters or fewer.';
        }
    }
    if (!in_array($suffix, $suffixOptions, true)) {
        $errors[] = 'Select a valid suffix.';
    }
    if ($ownerCode === '') {
        $errors[] = 'Code is required.';
    } elseif (strlen($ownerCode) > 50) {
        $errors[] = 'Code must be 50 characters or fewer.';
    }
    if ($contactNumber === '') {
        $errors[] = 'Contact number is required.';
    } elseif (!preg_match('/\A09[0-9]{9}\z/', $contactNumber)) {
        $errors[] = 'Contact number must be exactly 11 digits and start with 09.';
    }
    if (!in_array($barangayOrigin, $barangays, true)) {
        $errors[] = 'Select a barangay of animal origin.';
    }
    if ($farmSupplierName === '') {
        $errors[] = 'Farm / Supplier Name is required.';
    } elseif (strlen($farmSupplierName) > 150) {
        $errors[] = 'Farm / Supplier Name must be 150 characters or fewer.';
    }
    if (!array_key_exists($category, $categoryOptions)) {
        $errors[] = 'Select a valid category.';
    }

    if (!$errors) {
        $customersResult = firebase_request('get', 'customers');
        if (is_array($customersResult) && isset($customersResult['error'])) {
            $errors[] = 'Customer database is unavailable. Check the Firebase connection and try again.';
        } elseif ($customersResult !== null && !is_array($customersResult)) {
            $errors[] = 'Customer records could not be read. Please try again.';
        } else {
            $customers = array_values(array_filter(is_array($customersResult) ? $customersResult : [], 'is_array'));
            $normalizedOwnerCode = strtolower($ownerCode);

            foreach ($customers as $existingCustomer) {
                $existingOwnerCode = trim((string) ($existingCustomer['owner_code'] ?? ''));
                if ($existingOwnerCode === '') {
                    $existingOwnerCode = trim((string) ($existingCustomer['customer_id'] ?? ''));
                }
                if ($existingOwnerCode !== '' && strtolower($existingOwnerCode) === $normalizedOwnerCode) {
                    $errors[] = 'This code is already registered. Please enter another code.';
                    break;
                }
            }

            if (!$errors) {
                $customerId = generate_customer_id($customers);
                $ownerName = implode(' ', array_filter(
                    [$firstName, $middleName, $lastName, $suffix],
                    static fn(string $part): bool => $part !== ''
                ));
                $qrPath = save_customer_qr_image($customerId);
                $customer = [
                    'customer_id' => $customerId,
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'middle_name' => $middleName,
                    'suffix' => $suffix,
                    'owner_name' => $ownerName,
                    'owner_code' => $ownerCode,
                    'contact_number' => $contactNumber,
                    'barangay_of_animal_origin' => $barangayOrigin,
                    'farm_supplier_name' => $farmSupplierName,
                    'category' => $category,
                    'origin' => $barangayOrigin,
                    'created_at' => date('Y-m-d H:i:s'),
                    'qr_image' => $qrPath !== null ? customer_qr_image_web_path($customerId) : customer_qr_url($customerId),
                ];
                $result = firebase_post('customers', $customer);
                if (is_array($result) && !empty($result['name'])) {
                    $message = 'Customer registered successfully.';
                } else {
                    $errors[] = is_array($result) && !empty($result['error'])
                        ? 'Customer could not be saved: ' . $result['error']
                        : 'Customer could not be saved because the database did not return a record key.';
                    $customer = null;
                }
            }
        }
    }
}

$documentTitle = 'Customer Registration';
require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content inspector-registration-page">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <main class="container-fluid px-3 px-md-4 py-4">
        <div class="inspector-registration-heading mb-4">
            <div>
                <h1 class="mb-2">Customer Registration</h1>
                <p class="mb-0">Register an animal owner or supplier and generate their unique customer QR code.</p>
            </div>
            <a class="btn btn-outline-secondary" href="/inspector/dashboard.php"><i class="fa-solid fa-arrow-left me-2"></i>Dashboard</a>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($errors): ?>
            <div class="alert alert-danger" role="alert">
                <?php foreach ($errors as $error): ?>
                    <div><?php echo htmlspecialchars($error); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="row g-4 align-items-start">
            <div class="col-xl-8">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-3 p-md-4">
                        <form method="post">
                        <div class="border rounded-3 p-3 mb-4">
                            <fieldset class="mb-0">
                                <legend class="h5 mb-3">Category <span class="text-danger">*</span></legend>
                                <div class="row g-2">
                                    <?php foreach ($categoryOptions as $categoryCode => $categoryLabel): ?>
                                        <div class="col-12 col-md-4">
                                            <label class="form-check border rounded-2 p-3 h-100">
                                                <input class="form-check-input" type="radio" name="category" value="<?php echo htmlspecialchars($categoryCode); ?>"<?php echo $form['category'] === $categoryCode ? ' checked' : ''; ?> required>
                                                <span class="form-check-label"><?php echo htmlspecialchars($categoryLabel); ?></span>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </fieldset>
                        </div>
                        <h2 class="h4 mb-4">Customer Information</h2>
                            <div class="row g-3">
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="first_name">First Name <span class="text-danger">*</span></label>
                                    <input class="form-control form-control-lg" id="first_name" name="first_name" value="<?php echo htmlspecialchars($form['first_name']); ?>" maxlength="100" autocomplete="given-name" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="last_name">Last Name <span class="text-danger">*</span></label>
                                    <input class="form-control form-control-lg" id="last_name" name="last_name" value="<?php echo htmlspecialchars($form['last_name']); ?>" maxlength="100" autocomplete="family-name" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="middle_name">Middle Name</label>
                                    <input class="form-control form-control-lg" id="middle_name" name="middle_name" value="<?php echo htmlspecialchars($form['middle_name']); ?>" maxlength="100" autocomplete="additional-name">
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="suffix">Suffix</label>
                                    <select class="form-select form-select-lg" id="suffix" name="suffix">
                                        <?php foreach ($suffixOptions as $suffixOption): ?>
                                            <option value="<?php echo htmlspecialchars($suffixOption); ?>"<?php echo $form['suffix'] === $suffixOption ? ' selected' : ''; ?>><?php echo $suffixOption !== '' ? htmlspecialchars($suffixOption) : 'None'; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="owner_code">Code <span class="text-danger">*</span></label>
                                    <input class="form-control form-control-lg" id="owner_code" name="owner_code" value="<?php echo htmlspecialchars($form['owner_code']); ?>" maxlength="50" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="contact_number">Contact Number <span class="text-danger">*</span></label>
                                    <input class="form-control form-control-lg" type="tel" id="contact_number" name="contact_number" value="<?php echo htmlspecialchars($form['contact_number']); ?>" placeholder="09XXXXXXXXX" inputmode="numeric" pattern="09[0-9]{9}" minlength="11" maxlength="11" title="Enter exactly 11 digits starting with 09." autocomplete="tel" required>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="barangay_of_animal_origin">Barangay of Animal Origin <span class="text-danger">*</span></label>
                                    <select class="form-select form-select-lg" id="barangay_of_animal_origin" name="barangay_of_animal_origin" required>
                                        <option value="">Select barangay</option>
                                        <?php foreach ($barangays as $barangay): ?>
                                            <option value="<?php echo htmlspecialchars($barangay); ?>"<?php echo $form['barangay_of_animal_origin'] === $barangay ? ' selected' : ''; ?>><?php echo htmlspecialchars($barangay); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label class="form-label" for="farm_supplier_name">Farm / Supplier Name <span class="text-danger">*</span></label>
                                    <input class="form-control form-control-lg" id="farm_supplier_name" name="farm_supplier_name" value="<?php echo htmlspecialchars($form['farm_supplier_name']); ?>" maxlength="150" required>
                                </div>
                            </div>
                            <p class="text-secondary small mt-4 mb-3">* Required fields. Middle name and suffix are optional.</p>
                            <button class="btn btn-success btn-lg w-100" type="submit"><i class="fa-solid fa-user-plus me-2"></i>Register Customer &amp; Generate QR Code</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="inspector-qr-panel">
                    <h2 class="h4"><i class="fa-solid fa-qrcode me-2"></i>QR Code Generation</h2>
                    <?php if ($customer): ?>
                        <p>A unique QR code was generated for this customer.</p>
                        <img class="img-fluid mx-auto d-block my-3" src="<?php echo htmlspecialchars($customer['qr_image']); ?>" alt="Customer QR Code">
                        <strong class="d-block text-center mb-3"><?php echo htmlspecialchars($customer['customer_id']); ?></strong>
                        <a class="btn btn-outline-success w-100" href="<?php echo htmlspecialchars($customer['qr_image']); ?>" download="<?php echo htmlspecialchars($customer['customer_id']); ?>-qr.png"><i class="fa-solid fa-download me-2"></i>Download QR Code</a>
                    <?php else: ?>
                        <p>A unique QR code will be generated after the customer information is saved successfully.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
