<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();
require_once __DIR__ . '/../includes/firestore.php';

$registrations = firebase_get('client_registrations');
$registrations = is_array($registrations) ? $registrations : [];
$inspections = get_array_values(firebase_get('inspections'));

$selectedKey = $_GET['registration_key'] ?? '';
$selectedRegistration = $selectedKey && isset($registrations[$selectedKey]) ? $registrations[$selectedKey] : null;
$message = null;
$error = null;
$newInspection = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_inspection') {
    $selectedKey = $_POST['registration_key'] ?? '';
    if (!$selectedKey || !isset($registrations[$selectedKey])) {
        $error = 'Please select a valid registration before creating an inspection.';
    } else {
        $selectedRegistration = $registrations[$selectedKey];
        $inspectionId = generate_inspection_id($inspections);
        $inspection = [
            'inspection_id' => $inspectionId,
            'registration_key' => $selectedKey,
            'registration_id' => $selectedRegistration['inspection_id'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
            'status' => 'Waiting for Client',
            'decision' => null,
            'qr_code_value' => $inspectionId,
            'inspection_data' => [],
            'certificate_id' => null,
        ];

        $pushResult = firebase_post('inspections', $inspection);
        if (!empty($pushResult['name'])) {
            $message = 'Inspection created successfully.';
            $inspection['firebase_key'] = $pushResult['name'];
            $newInspection = $inspection;
            // Also write to Firestore if configured (optional)
            if (function_exists('firestore_add_document')) {
                // try to add using inspection id as document id
                $fsResult = firestore_write_document('inspections', $inspection['inspection_id'], $inspection);
                // ignore errors here; failure won't block RTDB flow
            }
            firebase_patch('client_registrations/' . $selectedKey, ['status' => 'Assigned to Inspection']);
        } else {
            $error = 'Unable to save inspection. Please try again.';
        }
    }
}

require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Create New Inspection</h3>
                <p class="text-secondary mb-0">Start a new meat inspection and generate an inspection QR code.</p>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-xl-7">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Select Registration</h5>
                        <form method="get" class="row gy-3 gx-3 align-items-end">
                            <div class="col-12 col-md-8">
                                <label class="form-label">Registration</label>
                                <select id="registration_key" class="form-select" name="registration_key" onchange="this.form.submit()">
                                    <option value="">Choose registration...</option>
                                    <?php foreach ($registrations as $key => $registration): ?>
                                        <option value="<?php echo htmlspecialchars($key); ?>" <?php echo $selectedKey === $key ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($registration['inspection_id'] ?? $key); ?> - <?php echo htmlspecialchars($registration['owner_name'] ?? 'Unknown'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-4">
                                <button type="submit" class="btn btn-primary w-100">Load Registration</button>
                            </div>
                        </form>

                        <div class="border rounded-3 p-3 mt-4">
                            <h5 class="mb-3">Scan Customer QR</h5>
                            <p class="text-secondary small mb-3">Use your device camera to scan the customer's registration QR code and auto-load their details.</p>
                            <button type="button" id="startScanBtn" class="btn btn-outline-success w-100 mb-3">Start Camera Scan</button>
                            <div id="scannerPreview" class="d-none">
                                <video id="qrVideo" class="w-100 rounded-3 border" playsinline muted></video>
                                <canvas id="qrCanvas" class="d-none"></canvas>
                                <p class="text-secondary small mt-2">Point the camera at the QR code until the registration loads automatically.</p>
                            </div>
                            <div class="mt-3">
                                <label class="form-label">Scanned Result</label>
                                <input type="text" id="scannedQrResult" class="form-control" readonly>
                            </div>
                        </div>
                    </div>

                <?php if ($selectedRegistration): ?>
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Registration Details</h5>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <p class="mb-1 text-secondary">Inspection ID</p>
                                    <p class="fw-semibold"><?php echo htmlspecialchars($selectedRegistration['inspection_id'] ?? 'N/A'); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-1 text-secondary">Owner</p>
                                    <p class="fw-semibold"><?php echo htmlspecialchars($selectedRegistration['owner_name'] ?? 'N/A'); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-1 text-secondary">Animal</p>
                                    <p class="fw-semibold"><?php echo htmlspecialchars($selectedRegistration['animal_type'] ?? 'N/A'); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-1 text-secondary">Submitted At</p>
                                    <p class="fw-semibold"><?php echo htmlspecialchars($selectedRegistration['submitted_at'] ?? 'N/A'); ?></p>
                                </div>
                            </div>
                            <div class="mt-4">
                                <form method="post">
                                    <input type="hidden" name="action" value="create_inspection">
                                    <input type="hidden" name="registration_key" value="<?php echo htmlspecialchars($selectedKey); ?>">
                                    <button type="submit" class="btn btn-success">Create Inspection</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-xl-5">
                <?php if ($newInspection): ?>
                    <div class="card shadow-sm border-0">
                        <div class="card-body text-center">
                            <h5 class="card-title mb-3">Inspection Created</h5>
                            <p class="text-secondary mb-4">Inspection ID and QR code generated automatically.</p>
                            <p class="h5 fw-bold mb-3"><?php echo htmlspecialchars($newInspection['inspection_id']); ?></p>
                            <img id="inspectionQr" src="<?php echo inspection_qr_url($newInspection['inspection_id']); ?>" alt="Inspection QR Code" class="img-fluid mb-3" style="max-width:260px;">
                            <p class="mb-3"><span class="badge bg-warning text-dark"><?php echo htmlspecialchars($newInspection['status']); ?></span></p>
                            <div class="d-flex flex-wrap gap-2 justify-content-center">
                                <button class="btn btn-outline-secondary" onclick="window.print();"><i class="fa-solid fa-print me-2"></i>Print QR</button>
                                <button class="btn btn-outline-primary" onclick="downloadQr()"><i class="fa-solid fa-download me-2"></i>Download QR</button>
                                <button class="btn btn-outline-success" onclick="shareQr()"><i class="fa-solid fa-share-nodes me-2"></i>Share QR</button>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Inspection Preview</h5>
                            <p class="text-secondary">Create a new inspection record from an existing client registration. The system generates a unique inspection number and QR code automatically.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<script>
    async function downloadQr() {
        const img = document.getElementById('inspectionQr');
        if (!img) return;
        const response = await fetch(img.src);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'inspection-qr.png';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    async function shareQr() {
        const img = document.getElementById('inspectionQr');
        if (!img) return;
        if (navigator.share) {
            try {
                await navigator.share({
                    title: 'Inspection QR Code',
                    text: 'Scan this QR code to view inspection details.',
                    url: img.src,
                });
            } catch (err) {
                console.warn('Share canceled', err);
            }
        } else {
            await navigator.clipboard.writeText(img.src);
            alert('QR image URL copied to clipboard.');
        }
    }

    function isSecureCameraContext() {
        const host = window.location.hostname;
        const isLocalHost = host === 'localhost' || host === '127.0.0.1' || host === '[::1]';
        const isPrivateNetwork = /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[0-1])\.)/.test(host);
        return window.isSecureContext || isLocalHost || isPrivateNetwork;
    }

    async function scanQrCode() {
        const startScanBtn = document.getElementById('startScanBtn');
        const scannerPreview = document.getElementById('scannerPreview');
        const video = document.getElementById('qrVideo');
        const canvas = document.getElementById('qrCanvas');
        const scannedQrResult = document.getElementById('scannedQrResult');

        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            alert('Camera access is not supported in this browser. Try Chrome or Safari on a phone.');
            return;
        }

        if (!isSecureCameraContext()) {
            alert('Phone camera requires a secure connection. Open this page with HTTPS or use localhost on the same device, then try again.');
            return;
        }

        startScanBtn.disabled = true;
        scannerPreview.classList.remove('d-none');

        try {
            video.setAttribute('playsinline', 'true');
            video.setAttribute('autoplay', 'true');
            video.setAttribute('muted', 'true');
            video.muted = true;

            const stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: { ideal: 'environment' },
                    width: { ideal: 1280 },
                    height: { ideal: 720 }
                }
            });
            video.srcObject = stream;
            await video.play();

            const context = canvas.getContext('2d');
            const scanInterval = setInterval(async () => {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                const code = jsQR(imageData.data, imageData.width, imageData.height);
                if (code) {
                    scannedQrResult.value = code.data;
                    clearInterval(scanInterval);
                    stream.getTracks().forEach(track => track.stop());
                    await loadRegistrationFromQr(code.data);
                }
            }, 300);
        } catch (err) {
            console.error(err);
            alert('Unable to access camera. Please allow camera permission and try again. If this is a phone, open it over HTTPS or localhost.');
        }
    }

    async function loadRegistrationFromQr(qrText) {
        const searchParams = new URLSearchParams(window.location.search);
        const url = new URL(window.location.href);
        const registrationKey = qrText.trim();

        if (!registrationKey) {
            return;
        }

        const query = searchParams;
        query.set('registration_key', registrationKey);
        url.search = query.toString();
        window.location.href = url.toString();
    }

    document.addEventListener('DOMContentLoaded', function () {
        const startScanBtn = document.getElementById('startScanBtn');
        if (startScanBtn) {
            startScanBtn.addEventListener('click', scanQrCode);
        }
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js"></script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>