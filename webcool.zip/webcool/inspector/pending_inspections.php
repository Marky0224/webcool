<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$inspections = array_values(array_filter(get_array_values(firebase_get('inspections')), 'is_array'));
$savedCertificates = array_values(array_filter(get_array_values(firebase_get('certificates')), 'is_array'));
$requestedDate = trim((string) ($_GET['date'] ?? ''));
$showAllDates = $requestedDate === '' || $requestedDate === 'all';
$parsedSelectedDate = DateTime::createFromFormat('!Y-m-d', $requestedDate);
$selectedDate = !$showAllDates && $parsedSelectedDate && $parsedSelectedDate->format('Y-m-d') === $requestedDate
    ? $requestedDate
    : '';

$releasedCertificateIds = [];
$releasedInspectionIds = [];
foreach ($inspections as $inspection) {
    $certificateId = trim((string) ($inspection['certificate_id'] ?? ''));
    if ($certificateId !== '') {
        $releasedCertificateIds[$certificateId] = true;
    }

    $inspectionId = trim((string) ($inspection['inspection_id'] ?? ''));
    if ($inspectionId !== '' && $certificateId !== '') {
        $releasedInspectionIds[$inspectionId] = true;
    }
}
foreach ($savedCertificates as $certificate) {
    $certificateId = trim((string) ($certificate['certificate_id'] ?? ''));
    if ($certificateId !== '') {
        $releasedCertificateIds[$certificateId] = true;
    }

    $inspectionId = trim((string) ($certificate['inspection_id'] ?? ''));
    if ($inspectionId !== '' && $certificateId !== '') {
        $releasedInspectionIds[$inspectionId] = true;
    }
}

$pendingAnteMortems = [];
foreach ($inspections as $inspection) {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    $anteMortem = $inspectionData['ante_mortem'] ?? null;
    if (!is_array($anteMortem)) {
        continue;
    }

    $inspectionDate = (string) ($inspection['inspection_date'] ?? $inspection['created_at'] ?? '');
    if ($selectedDate !== '' && substr($inspectionDate, 0, 10) !== $selectedDate) {
        continue;
    }

    $inspectionId = trim((string) ($inspection['inspection_id'] ?? ''));
    $certificateId = trim((string) ($inspection['certificate_id'] ?? ''));
    if (($inspectionId !== '' && isset($releasedInspectionIds[$inspectionId]))
        || ($certificateId !== '' && isset($releasedCertificateIds[$certificateId]))) {
        continue;
    }

    $customer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
    $pendingAnteMortems[] = [
        'inspection_id' => $inspectionId,
        'date' => substr($inspectionDate, 0, 10),
        'time' => !empty($inspection['created_at']) ? date('h:i A', strtotime((string) $inspection['created_at'])) : 'N/A',
        'owner_code' => (string) ($customer['owner_code'] ?? $inspection['customer_id'] ?? 'N/A'),
        'owner_name' => (string) ($inspection['customer_name'] ?? $customer['owner_name'] ?? 'N/A'),
        'heads' => $anteMortem['no_of_heads'] ?? 'N/A',
        'farm_owner' => (string) ($anteMortem['farm_owner'] ?? $customer['farm_supplier_name'] ?? 'N/A'),
        'origin' => (string) ($anteMortem['origin'] ?? $customer['barangay_of_animal_origin'] ?? $customer['origin'] ?? 'N/A'),
        'category' => get_ante_mortem_category_code((string) ($anteMortem['category'] ?? 'N/A')),
        'document' => is_array($anteMortem['document_presented'] ?? null)
            ? implode(', ', array_map(static fn($document): string => get_ante_mortem_document_label((string) $document), $anteMortem['document_presented']))
            : get_ante_mortem_document_label((string) ($anteMortem['document_presented'] ?? 'N/A')),
        'document_number' => (string) ($anteMortem['document_number'] ?? ''),
    ];
}
usort($pendingAnteMortems, static function (array $first, array $second): int {
    return strcmp($second['date'], $first['date']);
});
$pendingRecordCount = count($pendingAnteMortems);
$pendingRecordsPerPage = 20;
$pendingPageCount = max(1, (int) ceil($pendingRecordCount / $pendingRecordsPerPage));
$pendingCurrentPage = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 1],
]);
$pendingCurrentPage = $pendingCurrentPage === false ? 1 : min((int) $pendingCurrentPage, $pendingPageCount);
$pendingCurrentPage = (int) $pendingCurrentPage;
$pendingAnteMortems = array_slice($pendingAnteMortems, ($pendingCurrentPage - 1) * $pendingRecordsPerPage, $pendingRecordsPerPage);
$paginationUrl = static function (int $page) use ($selectedDate): string {
    $query = ['page' => $page];
    if ($selectedDate !== '') {
        $query['date'] = $selectedDate;
    }
    return '/inspector/pending_inspections.php?' . http_build_query($query);
};

require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content inspector-ante-list-page">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <main class="container-fluid px-3 px-md-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h1 class="mb-2"><i class="fa-solid fa-clipboard-check me-2 text-primary"></i>Pending Inspections</h1>
                <p class="text-secondary mb-0">Ante-Mortem records without a released Meat Inspection Certificate.</p>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <a href="/inspector/dashboard.php<?php echo $selectedDate !== '' ? '?date=' . urlencode($selectedDate) : ''; ?>" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-2"></i>Back to Dashboard</a>
                <button type="button" class="btn print-button" onclick="window.print()"><i class="fa-solid fa-print me-2"></i>Print Records</button>
            </div>
        </div>

        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body">
                <form method="get" class="date-filter-panel pending-inspection-date-filter">
                    <label for="pendingInspectionDate">Select date</label>
                    <input class="form-control" type="date" id="pendingInspectionDate" name="date" value="<?php echo htmlspecialchars($selectedDate); ?>">
                    <div class="date-filter-panel-actions">
                        <a class="btn btn-outline-secondary" href="/inspector/pending_inspections.php?date=<?php echo urlencode(date('Y-m-d')); ?>">Today</a>
                        <button class="btn filter-button" type="submit">Apply</button>
                        <a class="btn btn-outline-secondary" href="/inspector/pending_inspections.php?date=all">All dates</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow-sm border-0 inspector-ante-record-card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <h2 class="h5 mb-0"><i class="fa-solid fa-clipboard-list me-2 text-success"></i>Ante-Mortem Records Without MIC</h2>
                <span class="badge bg-primary"><?php echo $pendingRecordCount; ?> record<?php echo $pendingRecordCount === 1 ? '' : 's'; ?></span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 inspector-ante-list-table">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Owner / Code</th>
                                <th>No. of Heads</th>
                                <th>Farm / Supplier Name</th>
                                <th>Barangay of Animal Origin</th>
                                <th>Category</th>
                                <th>Document Presented</th>
                                <th>Date &amp; Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pendingAnteMortems as $index => $report): ?>
                                <tr>
                                    <td><?php echo (($pendingCurrentPage - 1) * $pendingRecordsPerPage) + (int) $index + 1; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars(format_person_name((string) $report['owner_name'])); ?></strong>
                                        <small class="d-block text-secondary"><?php echo htmlspecialchars($report['owner_code']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars((string) $report['heads']); ?></td>
                                    <td><?php echo htmlspecialchars($report['farm_owner']); ?></td>
                                    <td><?php echo htmlspecialchars($report['origin']); ?></td>
                                    <td><?php echo htmlspecialchars($report['category']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($report['document']); ?>
                                        <?php if ($report['document_number'] !== ''): ?>
                                            <small class="d-block text-secondary"><?php echo htmlspecialchars($report['document_number']); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($report['date'] !== '' ? date('M d, Y', strtotime($report['date'])) : 'N/A'); ?><small class="d-block text-secondary"><?php echo htmlspecialchars($report['time']); ?></small></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($pendingAnteMortems)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-secondary py-4"><?php echo $selectedDate === '' ? 'No pending Ante-Mortem records found.' : 'No pending Ante-Mortem records found for this date.'; ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($pendingRecordCount > 0): ?>
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 p-3">
                        <?php if ($pendingPageCount > 1): ?>
                            <nav aria-label="Pending inspection pages">
                                <ul class="pagination pagination-sm mb-0">
                                    <li class="page-item<?php echo $pendingCurrentPage === 1 ? ' disabled' : ''; ?>">
                                        <a class="page-link" href="<?php echo htmlspecialchars($paginationUrl(max(1, $pendingCurrentPage - 1))); ?>" aria-label="Previous page">Previous</a>
                                    </li>
                                    <?php for ($page = 1; $page <= $pendingPageCount; $page++): ?>
                                        <li class="page-item<?php echo $page === $pendingCurrentPage ? ' active' : ''; ?>">
                                            <a class="page-link" href="<?php echo htmlspecialchars($paginationUrl($page)); ?>"<?php echo $page === $pendingCurrentPage ? ' aria-current="page"' : ''; ?>><?php echo $page; ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    <li class="page-item<?php echo $pendingCurrentPage === $pendingPageCount ? ' disabled' : ''; ?>">
                                        <a class="page-link" href="<?php echo htmlspecialchars($paginationUrl(min($pendingPageCount, $pendingCurrentPage + 1))); ?>" aria-label="Next page">Next</a>
                                    </li>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
