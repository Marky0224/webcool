<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$barangayDatasetPath = __DIR__ . '/../assets/data/lipa-city-barangays.geojson';
$barangayDatasetContents = is_file($barangayDatasetPath) ? file_get_contents($barangayDatasetPath) : false;
$barangayDataset = is_string($barangayDatasetContents) ? json_decode($barangayDatasetContents, true) : null;
$barangaysByCode = [];
if (is_array($barangayDataset['features'] ?? null)) {
    foreach ($barangayDataset['features'] as $feature) {
        $properties = is_array($feature['properties'] ?? null) ? $feature['properties'] : [];
        $code = (string) ($properties['psgc_code'] ?? '');
        if (preg_match('/^0401014\d{3}$/', $code) && !empty($properties['name'])) {
            $barangaysByCode[$code] = (string) $properties['name'];
        }
    }
}

$reportsResult = firebase_request('GET', 'disease_monitoring_reports');
$reportsLoadError = is_array($reportsResult) && isset($reportsResult['error']);
$diseaseReports = [];
if (!$reportsLoadError && is_array($reportsResult)) {
    foreach ($reportsResult as $barangayCode => $reports) {
        $barangayCode = (string) $barangayCode;
        if (!isset($barangaysByCode[$barangayCode]) || !is_array($reports)) {
            continue;
        }
        foreach ($reports as $reportKey => $report) {
            if (!is_array($report)) {
                continue;
            }
            $status = (string) ($report['status'] ?? 'active');
            $statusInspectorField = $status === 'resolved'
                ? 'resolved_by'
                : ($status === 'cancelled' ? 'cancelled_by' : 'recorded_by');
            $diseaseReports[] = [
                'barangay' => $barangaysByCode[$barangayCode],
                'disease' => (string) ($report['disease'] ?? 'Disease report'),
                'certainty' => in_array($report['certainty'] ?? '', ['suspected', 'confirmed'], true)
                    ? (string) $report['certainty']
                    : 'suspected',
                'reported_on' => (string) ($report['reported_on'] ?? ''),
                'status' => in_array($status, ['active', 'resolved', 'cancelled'], true) ? $status : 'active',
                'status_inspector' => trim((string) ($report[$statusInspectorField] ?? '')),
            ];
        }
    }
}
usort($diseaseReports, static function (array $first, array $second): int {
    return strcmp($second['reported_on'], $first['reported_on'])
        ?: strnatcasecmp($first['barangay'], $second['barangay']);
});

$documentTitle = 'Disease Report History';
require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="card shadow-sm border-0 mt-4">
            <div class="card-body">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-4">
                    <div>
                        <h1 class="h5 mb-1">Disease Report History</h1>
                        <p class="text-secondary small mb-0">All recorded barangay disease reports, including inactive reports.</p>
                    </div>
                    <a href="/inspector/barangay_disease_monitoring.php" class="btn btn-outline-secondary flex-shrink-0 no-print">
                        <i class="fa-solid fa-arrow-left me-2" aria-hidden="true"></i>Back to Monitoring
                    </a>
                </div>

                <?php if ($reportsLoadError): ?>
                    <div class="alert alert-danger" role="alert">Unable to load disease report history from Firebase.</div>
                <?php elseif (!$diseaseReports): ?>
                    <div class="alert alert-secondary" role="status">No disease reports have been recorded.</div>
                <?php else: ?>
                    <div class="card border-0 bg-light mb-3 no-print">
                        <div class="card-body">
                            <div class="row g-2 align-items-end">
                                <div class="col-md-4">
                                    <label class="form-label" for="diseaseReportSearch">Search reports</label>
                                    <input type="search" class="form-control" id="diseaseReportSearch" placeholder="Search barangay or disease">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label" for="diseaseReportDate">Filter by date</label>
                                    <input type="date" class="form-control" id="diseaseReportDate">
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-outline-secondary w-100" id="clearDiseaseReportFilters">Clear filters</button>
                                </div>
                                <div class="col-md-3">
                                    <button type="button" class="btn print-button w-100" onclick="window.print()">
                                        <i class="fa-solid fa-print me-2" aria-hidden="true"></i>Print Records
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle" id="diseaseReportHistoryTable">
                            <thead>
                                <tr>
                                    <th>Barangay</th>
                                    <th>Disease</th>
                                    <th>Certainty</th>
                                    <th>Reported on</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($diseaseReports as $report): ?>
                                    <tr data-reported-on="<?php echo htmlspecialchars($report['reported_on'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <td><?php echo htmlspecialchars($report['barangay']); ?></td>
                                        <td><?php echo htmlspecialchars($report['disease']); ?></td>
                                        <td><?php echo htmlspecialchars(ucfirst($report['certainty'])); ?></td>
                                        <td><?php echo htmlspecialchars($report['reported_on'] ?: 'Not set'); ?></td>
                                        <td>
                                            <span class="badge <?php echo $report['status'] === 'active' ? 'bg-danger' : 'bg-secondary'; ?>"><?php echo htmlspecialchars(ucfirst($report['status'])); ?></span>
                                            <div class="small text-secondary mt-1">
                                                <?php
                                                $statusAction = $report['status'] === 'active'
                                                    ? 'Reported by'
                                                    : (ucfirst($report['status']) . ' by');
                                                echo htmlspecialchars($statusAction . ': ' . ($report['status_inspector'] ?: 'Inspector not recorded'));
                                                ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <p class="text-secondary small mb-0 no-print" id="noFilteredDiseaseReports" hidden>No reports match the selected filters.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php if ($diseaseReports): ?>
<script>
    (function () {
        const searchInput = document.getElementById('diseaseReportSearch');
        const dateInput = document.getElementById('diseaseReportDate');
        const clearButton = document.getElementById('clearDiseaseReportFilters');
        const rows = Array.from(document.querySelectorAll('#diseaseReportHistoryTable tbody tr'));
        const emptyMessage = document.getElementById('noFilteredDiseaseReports');

        const applyFilters = function () {
            const search = searchInput.value.trim().toLowerCase();
            const date = dateInput.value;
            let visibleRows = 0;
            rows.forEach(function (row) {
                const matchesSearch = search === '' || row.textContent.toLowerCase().includes(search);
                const matchesDate = date === '' || row.dataset.reportedOn === date;
                row.hidden = !matchesSearch || !matchesDate;
                if (!row.hidden) {
                    visibleRows += 1;
                }
            });
            emptyMessage.hidden = visibleRows !== 0;
        };

        searchInput.addEventListener('input', applyFilters);
        dateInput.addEventListener('change', applyFilters);
        clearButton.addEventListener('click', function () {
            searchInput.value = '';
            dateInput.value = '';
            applyFilters();
        });
    })();
</script>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
