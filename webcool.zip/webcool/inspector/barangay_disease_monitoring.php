<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$barangayDatasetPath = __DIR__ . '/../assets/data/lipa-city-barangays.geojson';
$barangayDatasetContents = is_file($barangayDatasetPath) ? file_get_contents($barangayDatasetPath) : false;
$barangayDataset = is_string($barangayDatasetContents) ? json_decode($barangayDatasetContents, true) : null;
$barangaysByCode = [];
if (is_array($barangayDataset['features'] ?? null)) {
    foreach ($barangayDataset['features'] as $feature) {
        $properties = is_array($feature['properties'] ?? null) ? $feature['properties'] : [];
        $code = (string) ($properties['psgc_code'] ?? '');
        if (preg_match('/^0401014\d{3}$/', $code) && !empty($properties['name'])) {
            $barangaysByCode[$code] = (string) $properties['name'];
        }
    }
}

$csrfSessionKey = 'barangay_disease_monitoring_csrf_token';
if (empty($_SESSION[$csrfSessionKey])) {
    $_SESSION[$csrfSessionKey] = bin2hex(random_bytes(32));
}
$csrfToken = (string) $_SESSION[$csrfSessionKey];
$flashSessionKey = 'barangay_disease_monitoring_flash';
$flash = is_array($_SESSION[$flashSessionKey] ?? null) ? $_SESSION[$flashSessionKey] : [];
unset($_SESSION[$flashSessionKey]);
$errors = is_array($flash['errors'] ?? null) ? $flash['errors'] : [];
$successMessage = is_string($flash['success_message'] ?? null) ? $flash['success_message'] : '';
$reopenReportForm = !empty($flash['reopen_report_form']);
$formValues = [
    'barangay_code' => '',
    'disease' => '',
    'certainty' => 'suspected',
    'reported_on' => date('Y-m-d'),
];
foreach ($formValues as $field => $default) {
    if (isset($flash['form_values'][$field]) && is_string($flash['form_values'][$field])) {
        $formValues[$field] = $flash['form_values'][$field];
    }
}
$getPostString = static function (string $field, string $default = ''): string {
    $value = $_POST[$field] ?? $default;
    return is_string($value) || is_numeric($value) ? trim((string) $value) : '';
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($formValues as $field => $default) {
        $formValues[$field] = $getPostString($field, $default);
    }

    $submittedToken = $getPostString('csrf_token');
    $action = $getPostString('action');
    $barangayCode = $formValues['barangay_code'];
    if ($submittedToken === '' || !hash_equals($csrfToken, $submittedToken)) {
        $errors[] = 'Your session token is invalid or expired. Refresh the page and try again.';
    } elseif (!isset($barangaysByCode[$barangayCode])) {
        $errors[] = 'Select a valid barangay.';
    } elseif ($action === 'add_report') {
        $disease = trim($formValues['disease']);
        $certainty = $formValues['certainty'];
        $reportedOn = DateTime::createFromFormat('!Y-m-d', $formValues['reported_on']);
        if ($disease === '' || strlen($disease) > 100) {
            $errors[] = 'Enter a disease name with no more than 100 characters.';
        }
        if (!in_array($certainty, ['suspected', 'confirmed'], true)) {
            $errors[] = 'Select whether the disease is suspected or confirmed.';
        }
        if (!$reportedOn || $reportedOn->format('Y-m-d') !== $formValues['reported_on'] || $formValues['reported_on'] > date('Y-m-d')) {
            $errors[] = 'Enter a valid report date that is not in the future.';
        }

        if (!$errors) {
            $result = firebase_post('disease_monitoring_reports/' . $barangayCode, [
                'disease' => $disease,
                'certainty' => $certainty,
                'reported_on' => $formValues['reported_on'],
                'status' => 'active',
                'recorded_by' => get_current_inspector_name(),
                'recorded_at' => date('c'),
            ]);
            if (is_array($result) && isset($result['error'])) {
                error_log('Unable to save barangay disease report: ' . $result['error']);
                $errors[] = 'Unable to save the report. Check the Firebase connection and try again.';
            } else {
                $successMessage = 'Disease report saved for ' . $barangaysByCode[$barangayCode] . '.';
                $formValues = [
                    'barangay_code' => '',
                    'disease' => '',
                    'certainty' => 'suspected',
                    'reported_on' => date('Y-m-d'),
                ];
            }
        }
    } elseif ($action === 'edit_report') {
        $reportKey = $getPostString('report_key');
        $disease = $formValues['disease'];
        $certainty = $formValues['certainty'];
        $reportedOn = DateTime::createFromFormat('!Y-m-d', $formValues['reported_on']);
        if (!preg_match('/^-[A-Za-z0-9_-]{10,}$/', $reportKey)) {
            $errors[] = 'Select a valid disease report to edit.';
        }
        if ($disease === '' || strlen($disease) > 100) {
            $errors[] = 'Enter a disease name with no more than 100 characters.';
        }
        if (!in_array($certainty, ['suspected', 'confirmed'], true)) {
            $errors[] = 'Select whether the disease is suspected or confirmed.';
        }
        if (!$reportedOn || $reportedOn->format('Y-m-d') !== $formValues['reported_on'] || $formValues['reported_on'] > date('Y-m-d')) {
            $errors[] = 'Enter a valid report date that is not in the future.';
        }

        if (!$errors) {
            $reportPath = 'disease_monitoring_reports/' . $barangayCode . '/' . $reportKey;
            $existingReport = firebase_request('GET', $reportPath);
            if (is_array($existingReport) && isset($existingReport['error'])) {
                error_log('Unable to load barangay disease report before editing: ' . $existingReport['error']);
                $errors[] = 'Unable to load the report. Check the Firebase connection and try again.';
            } elseif (!is_array($existingReport) || empty($existingReport['disease']) || ($existingReport['status'] ?? 'active') !== 'active') {
                $errors[] = 'This report does not exist or is no longer active. Refresh the page and try again.';
            } else {
                $result = firebase_patch($reportPath, [
                    'disease' => $disease,
                    'certainty' => $certainty,
                    'reported_on' => $formValues['reported_on'],
                    'edited_by' => get_current_inspector_name(),
                    'edited_at' => date('c'),
                ]);
                if (is_array($result) && isset($result['error'])) {
                    error_log('Unable to edit barangay disease report: ' . $result['error']);
                    $errors[] = 'Unable to edit the report. Check the Firebase connection and try again.';
                } else {
                    $successMessage = 'Disease report updated for ' . $barangaysByCode[$barangayCode] . '.';
                    $formValues = [
                        'barangay_code' => '',
                        'disease' => '',
                        'certainty' => 'suspected',
                        'reported_on' => date('Y-m-d'),
                    ];
                }
            }
        }
    } elseif ($action === 'cancel_report') {
        $reportKey = $getPostString('report_key');
        if (!preg_match('/^-[A-Za-z0-9_-]{10,}$/', $reportKey)) {
            $errors[] = 'Select a valid disease report to cancel.';
        } else {
            $reportPath = 'disease_monitoring_reports/' . $barangayCode . '/' . $reportKey;
            $existingReport = firebase_request('GET', $reportPath);
            if (is_array($existingReport) && isset($existingReport['error'])) {
                error_log('Unable to load barangay disease report before cancellation: ' . $existingReport['error']);
                $errors[] = 'Unable to load the report. Check the Firebase connection and try again.';
            } elseif (!is_array($existingReport) || empty($existingReport['disease']) || ($existingReport['status'] ?? 'active') !== 'active') {
                $errors[] = 'This report does not exist or is no longer active. Refresh the page and try again.';
            } else {
                $result = firebase_patch($reportPath, [
                    'status' => 'cancelled',
                    'cancelled_by' => get_current_inspector_name(),
                    'cancelled_at' => date('c'),
                ]);
                if (is_array($result) && isset($result['error'])) {
                    error_log('Unable to cancel barangay disease report: ' . $result['error']);
                    $errors[] = 'Unable to cancel the report. Check the Firebase connection and try again.';
                } else {
                    $successMessage = 'Disease report cancelled for ' . $barangaysByCode[$barangayCode] . '.';
                }
            }
        }
    } elseif ($action === 'resolve_report') {
        $reportKey = $getPostString('report_key');
        if (!preg_match('/^-[A-Za-z0-9_-]{10,}$/', $reportKey)) {
            $errors[] = 'Select a valid disease report to resolve.';
        } else {
            $reportPath = 'disease_monitoring_reports/' . $barangayCode . '/' . $reportKey;
            $existingReport = firebase_request('GET', $reportPath);
            if (is_array($existingReport) && isset($existingReport['error'])) {
                error_log('Unable to load barangay disease report before resolution: ' . $existingReport['error']);
                $errors[] = 'Unable to load the report. Check the Firebase connection and try again.';
            } elseif (!is_array($existingReport) || empty($existingReport['disease']) || ($existingReport['status'] ?? 'active') !== 'active') {
                $errors[] = 'This report does not exist or is no longer active. Refresh the page and try again.';
            } else {
                $result = firebase_patch($reportPath, [
                    'status' => 'resolved',
                    'resolved_by' => get_current_inspector_name(),
                    'resolved_at' => date('c'),
                ]);
                if (is_array($result) && isset($result['error'])) {
                    error_log('Unable to resolve barangay disease report: ' . $result['error']);
                    $errors[] = 'Unable to resolve the report. Check the Firebase connection and try again.';
                } else {
                    $successMessage = 'Disease report resolved for ' . $barangaysByCode[$barangayCode] . '.';
                }
            }
        }
    } else {
        $errors[] = 'Select a valid report action.';
    }

    $_SESSION[$flashSessionKey] = [
        'errors' => $errors,
        'success_message' => $successMessage,
        'form_values' => $formValues,
        'form_action' => in_array($action, ['add_report', 'edit_report'], true) ? $action : 'add_report',
        'report_key' => $action === 'edit_report' ? $getPostString('report_key') : '',
        'reopen_report_form' => (bool) $errors && in_array($action, ['add_report', 'edit_report'], true),
    ];
    header('Location: /inspector/barangay_disease_monitoring.php');
    exit;
}
$formAction = in_array($flash['form_action'] ?? '', ['add_report', 'edit_report'], true)
    ? $flash['form_action']
    : 'add_report';
$formReportKey = $formAction === 'edit_report' && is_string($flash['report_key'] ?? null)
    ? $flash['report_key']
    : '';

$reportsResult = firebase_request('GET', 'disease_monitoring_reports');
$reportsLoadError = is_array($reportsResult) && isset($reportsResult['error']);
$diseaseReports = [];
if (!$reportsLoadError && is_array($reportsResult)) {
    foreach ($reportsResult as $barangayCode => $reports) {
        if (!isset($barangaysByCode[(string) $barangayCode]) || !is_array($reports)) {
            continue;
        }
        foreach ($reports as $reportKey => $report) {
            if (!is_array($report)) {
                continue;
            }
            $reportStatus = (string) ($report['status'] ?? 'active');
            $statusInspectorField = $reportStatus === 'resolved'
                ? 'resolved_by'
                : ($reportStatus === 'cancelled' ? 'cancelled_by' : 'recorded_by');
            $diseaseReports[(string) $barangayCode][] = [
                'key' => (string) $reportKey,
                'disease' => (string) ($report['disease'] ?? 'Disease report'),
                'certainty' => in_array($report['certainty'] ?? '', ['suspected', 'confirmed'], true)
                    ? (string) $report['certainty']
                    : 'suspected',
                'reported_on' => (string) ($report['reported_on'] ?? ''),
                'status' => in_array($reportStatus, ['active', 'resolved', 'cancelled'], true) ? $reportStatus : 'active',
                'status_inspector' => trim((string) ($report[$statusInspectorField] ?? '')),
            ];
        }
    }
}
$activeDiseaseReports = [];
foreach ($diseaseReports as $barangayCode => $reports) {
    foreach ($reports as $report) {
        if ($report['status'] !== 'active') {
            continue;
        }
        $activeDiseaseReports[] = [
            'barangay_code' => $barangayCode,
            'barangay_name' => $barangaysByCode[$barangayCode],
            'key' => $report['key'],
            'disease' => $report['disease'],
            'certainty' => $report['certainty'],
            'reported_on' => $report['reported_on'],
        ];
    }
}
usort($activeDiseaseReports, static function (array $first, array $second): int {
    return strnatcasecmp($first['barangay_name'], $second['barangay_name'])
        ?: strcmp($second['reported_on'], $first['reported_on']);
});
$diseaseReportsJson = json_encode(
    $diseaseReports,
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES
);
if ($diseaseReportsJson === false) {
    error_log('Unable to encode barangay disease reports for the monitoring map.');
    $reportsLoadError = true;
    $diseaseReportsJson = '{}';
}

$documentTitle = 'Barangay Disease Monitoring';
require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="card shadow-sm border-0 mt-4">
            <div class="card-body">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
                    <div>
                        <h5 class="mb-1">Barangay Disease Monitoring</h5>
                        <p class="text-secondary small mb-0">Select a barangay marker to review reports or record a suspected or confirmed contagious disease.</p>
                    </div>
                    <div class="d-flex flex-wrap gap-2 flex-shrink-0">
                    <a href="/inspector/disease_report_history.php" class="btn btn-primary">
                        <i class="fa-solid fa-clock-rotate-left me-2" aria-hidden="true"></i>History
                    </a>
                    <a href="/inspector/dashboard.php" class="btn btn-outline-secondary">
                        <i class="fa-solid fa-arrow-left me-2" aria-hidden="true"></i>Back to Dashboard
                    </a>
                    </div>
                </div>

                <?php if ($errors): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php foreach ($errors as $error): ?>
                            <div><?php echo htmlspecialchars($error); ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php if ($reportsLoadError): ?>
                    <div class="alert alert-danger" role="alert">Unable to load disease reports from Firebase. The map will not show current report markers.</div>
                <?php endif; ?>
                <?php if (count($barangaysByCode) !== 72): ?>
                    <div class="alert alert-danger" role="alert">The Lipa barangay boundary data is incomplete or unavailable. Report markers are disabled until it can be loaded.</div>
                <?php endif; ?>

                <div class="d-flex flex-wrap gap-3 small mb-2" aria-label="Report marker legend">
                    <span><i class="fa-solid fa-location-dot text-danger me-1"></i>Active disease report</span>
                    <span><i class="fa-solid fa-location-dot text-secondary me-1"></i>No active reports</span>
                </div>
                <div class="row g-3">
                    <div class="col-lg-8">
                        <div
                            id="barangayDiseaseMap"
                            class="barangay-disease-map"
                            role="region"
                            aria-label="OpenStreetMap showing the boundaries of Lipa City's 72 barangays"
                        ></div>
                    </div>
                    <div class="col-lg-4">
                        <section class="active-disease-reports" aria-labelledby="activeDiseaseReportsTitle">
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
                                <h2 class="h6 mb-0" id="activeDiseaseReportsTitle">Active reports</h2>
                                <span class="badge rounded-pill bg-danger"><?php echo count($activeDiseaseReports); ?></span>
                            </div>
                            <?php if ($reportsLoadError): ?>
                                <p class="small text-danger mb-0">Active reports could not be loaded.</p>
                            <?php elseif (!$activeDiseaseReports): ?>
                                <p class="small text-secondary mb-0">No active disease reports.</p>
                            <?php else: ?>
                                <div class="active-disease-report-list">
                                    <?php foreach ($activeDiseaseReports as $report): ?>
                                        <article class="active-disease-report">
                                            <div class="d-flex align-items-start gap-2">
                                                <i class="fa-solid fa-location-dot text-danger mt-1" aria-hidden="true"></i>
                                                <div class="flex-grow-1">
                                                    <strong><?php echo htmlspecialchars($report['barangay_name']); ?></strong>
                                                    <div class="small"><?php echo htmlspecialchars($report['disease']); ?></div>
                                                    <div class="small text-secondary">
                                                        <?php echo htmlspecialchars(ucfirst($report['certainty']) . ' · ' . $report['reported_on']); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if (!$reportsLoadError && count($barangaysByCode) === 72): ?>
                                                <div class="d-flex gap-2 mt-2">
                                                    <button
                                                        type="button"
                                                        class="btn btn-sm btn-outline-primary edit-disease-report"
                                                        data-barangay-code="<?php echo htmlspecialchars($report['barangay_code'], ENT_QUOTES, 'UTF-8'); ?>"
                                                        data-barangay-name="<?php echo htmlspecialchars($report['barangay_name'], ENT_QUOTES, 'UTF-8'); ?>"
                                                        data-report-key="<?php echo htmlspecialchars($report['key'], ENT_QUOTES, 'UTF-8'); ?>"
                                                        data-disease="<?php echo htmlspecialchars($report['disease'], ENT_QUOTES, 'UTF-8'); ?>"
                                                        data-certainty="<?php echo htmlspecialchars($report['certainty'], ENT_QUOTES, 'UTF-8'); ?>"
                                                        data-reported-on="<?php echo htmlspecialchars($report['reported_on'], ENT_QUOTES, 'UTF-8'); ?>"
                                                    >Edit</button>
                                                    <button
                                                        type="button"
                                                        class="btn btn-sm btn-outline-success resolve-disease-report"
                                                        data-barangay-code="<?php echo htmlspecialchars($report['barangay_code'], ENT_QUOTES, 'UTF-8'); ?>"
                                                        data-report-key="<?php echo htmlspecialchars($report['key'], ENT_QUOTES, 'UTF-8'); ?>"
                                                    >Resolve</button>
                                                    <button
                                                        type="button"
                                                        class="btn btn-sm btn-outline-danger cancel-disease-report"
                                                        data-barangay-code="<?php echo htmlspecialchars($report['barangay_code'], ENT_QUOTES, 'UTF-8'); ?>"
                                                        data-report-key="<?php echo htmlspecialchars($report['key'], ENT_QUOTES, 'UTF-8'); ?>"
                                                    >Cancel</button>
                                                </div>
                                            <?php endif; ?>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </section>
                    </div>
                </div>
                <div id="barangayDiseaseMapStatus" class="small text-secondary mb-2" role="status" aria-live="polite">
                    Loading Lipa City map…
                </div>
                <div class="alert alert-info mb-0" role="note">
                    Reports are barangay-level and should not include patient names or other identifying details. Mark a report as confirmed only when confirmed by an authorized health professional. Boundary data is for monitoring reference, not legal or cadastral use.
                    <a href="https://github.com/bendlikeabamboo/barangay-boundaries-repository" target="_blank" rel="noopener noreferrer">Boundary data source and license</a>.
                </div>
            </div>
        </div>
    </div>
</div>
<dialog id="diseaseReportDialog" class="disease-report-dialog">
    <form method="post" id="diseaseReportForm">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="action" id="diseaseReportAction" value="<?php echo htmlspecialchars($formAction, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="barangay_code" id="diseaseReportBarangayCode" value="<?php echo htmlspecialchars($formValues['barangay_code'], ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="report_key" id="diseaseReportKey" value="<?php echo htmlspecialchars($formReportKey, ENT_QUOTES, 'UTF-8'); ?>">
        <div class="d-flex align-items-start justify-content-between gap-3 mb-3">
            <div>
                <h2 class="h5 mb-1" id="diseaseReportDialogTitle"><?php echo $formAction === 'edit_report' ? 'Edit disease report' : 'Record disease report'; ?></h2>
                <p class="text-secondary mb-0" id="diseaseReportBarangayName"><?php echo htmlspecialchars($barangaysByCode[$formValues['barangay_code']] ?? ''); ?></p>
            </div>
            <button type="button" class="btn-close" id="closeDiseaseReportDialog" aria-label="Close"></button>
        </div>
        <label class="form-label" for="diseaseReportName">Disease</label>
        <input class="form-control mb-3" type="text" name="disease" id="diseaseReportName" maxlength="100" required value="<?php echo htmlspecialchars($formValues['disease'], ENT_QUOTES, 'UTF-8'); ?>">
        <label class="form-label" for="diseaseReportCertainty">Report status</label>
        <select class="form-select mb-1" name="certainty" id="diseaseReportCertainty" required>
            <option value="suspected"<?php echo $formValues['certainty'] === 'suspected' ? ' selected' : ''; ?>>Suspected</option>
            <option value="confirmed"<?php echo $formValues['certainty'] === 'confirmed' ? ' selected' : ''; ?>>Confirmed by an authorized health professional</option>
        </select>
        <div class="form-text mb-3">Do not mark a report confirmed without authorized confirmation.</div>
        <label class="form-label" for="diseaseReportDate">Report date</label>
        <input class="form-control mb-4" type="date" name="reported_on" id="diseaseReportDate" max="<?php echo htmlspecialchars(date('Y-m-d'), ENT_QUOTES, 'UTF-8'); ?>" required value="<?php echo htmlspecialchars($formValues['reported_on'], ENT_QUOTES, 'UTF-8'); ?>">
        <div class="d-flex justify-content-end gap-2">
            <button type="button" class="btn btn-outline-secondary" id="cancelDiseaseReport">Cancel</button>
            <button type="submit" class="btn btn-primary" id="saveDiseaseReportButton"><?php echo $formAction === 'edit_report' ? 'Save changes' : 'Save report'; ?></button>
        </div>
    </form>
</dialog>
<form method="post" id="resolveDiseaseReportForm" class="d-none">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="action" value="resolve_report">
    <input type="hidden" name="barangay_code" id="resolveDiseaseReportBarangayCode">
    <input type="hidden" name="report_key" id="resolveDiseaseReportKey">
</form>
<form method="post" id="cancelDiseaseReportForm" class="d-none">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="action" value="cancel_report">
    <input type="hidden" name="barangay_code" id="cancelDiseaseReportBarangayCode">
    <input type="hidden" name="report_key" id="cancelDiseaseReportKey">
</form>
<script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    (function () {
        const status = document.getElementById('barangayDiseaseMapStatus');
        const reports = <?php echo $diseaseReportsJson; ?>;
        const canUseMarkers = <?php echo !$reportsLoadError && count($barangaysByCode) === 72 ? 'true' : 'false'; ?>;
        const reportDialog = document.getElementById('diseaseReportDialog');
        const reportForm = document.getElementById('diseaseReportForm');
        const reportBarangayCode = document.getElementById('diseaseReportBarangayCode');
        const reportBarangayName = document.getElementById('diseaseReportBarangayName');
        const reportAction = document.getElementById('diseaseReportAction');
        const reportKey = document.getElementById('diseaseReportKey');
        const reportDialogTitle = document.getElementById('diseaseReportDialogTitle');
        const saveReportButton = document.getElementById('saveDiseaseReportButton');
        let boundaryLoaded = false;
        let barangaysLoaded = false;
        let tilesLoaded = false;
        let tileError = false;

        function updateStatus() {
            if (tileError) {
                status.textContent = 'Some map tiles could not be loaded. Check your internet connection and try again.';
                status.classList.add('text-danger');
            } else if (boundaryLoaded && barangaysLoaded && tilesLoaded) {
                if (!canUseMarkers) {
                    status.textContent = 'Map loaded, but current report data is unavailable.';
                    status.classList.add('text-danger');
                    return;
                }
                const activeReports = Object.values(reports).flat().filter(function (report) {
                    return report.status === 'active';
                }).length;
                status.textContent = 'Lipa City boundary and all 72 barangays loaded. ' + activeReports + ' active disease report' + (activeReports === 1 ? '' : 's') + '.';
                status.classList.remove('text-danger');
            }
        }

        if (!window.L) {
            status.textContent = 'The map library could not be loaded. Check your internet connection and try again.';
            status.classList.add('text-danger');
            return;
        }

        const map = L.map('barangayDiseaseMap', { maxBoundsViscosity: 1 }).setView([13.941, 121.162], 12);
        const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors | City boundary: <a href="https://www.openstreetmap.org/relation/6209763" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>'
        }).addTo(map);

        tiles.on('load', function () {
            tilesLoaded = true;
            updateStatus();
        });
        tiles.on('tileerror', function () {
            tileError = true;
            updateStatus();
        });

        const colors = ['#7aa6d8', '#e08b82', '#84b96b', '#d2b95f', '#ae8ac4', '#61aeb0'];
        const barangayStyle = function (feature) {
            const code = String(feature.properties.psgc_code || '');
            const colorIndex = Array.from(code).reduce(function (total, character) {
                return total + character.charCodeAt(0);
            }, 0) % colors.length;
            return {
                color: '#334155',
                weight: 1.2,
                opacity: 0.9,
                fillColor: colors[colorIndex],
                fillOpacity: 0.32
            };
        };
        const updateBarangayLabels = function () {
            const showLabels = map.getZoom() >= 13;
            document.querySelectorAll('.barangay-map-label').forEach(function (label) {
                label.style.display = showLabels ? '' : 'none';
            });
        };
        const setCurrentReportDate = function () {
            const today = new Date();
            reportForm.elements.reported_on.value = [
                today.getFullYear(),
                String(today.getMonth() + 1).padStart(2, '0'),
                String(today.getDate()).padStart(2, '0')
            ].join('-');
        };
        const openReportDialog = function (mode, barangayCode, barangayName, report) {
            reportBarangayCode.value = barangayCode;
            reportBarangayName.textContent = barangayName;
            reportAction.value = mode === 'edit' ? 'edit_report' : 'add_report';
            reportKey.value = mode === 'edit' ? report.key : '';
            reportDialogTitle.textContent = mode === 'edit' ? 'Edit disease report' : 'Record disease report';
            saveReportButton.textContent = mode === 'edit' ? 'Save changes' : 'Save report';
            reportForm.elements.disease.value = mode === 'edit' ? report.disease : '';
            reportForm.elements.certainty.value = mode === 'edit' ? report.certainty : 'suspected';
            if (mode === 'edit') {
                reportForm.elements.reported_on.value = report.reported_on;
            } else {
                setCurrentReportDate();
            }
            reportDialog.showModal();
        };
        const submitResolveReport = function (barangayCode, key) {
            if (!window.confirm('Resolve this report? Its history will remain, but the barangay marker will no longer be red unless another active report exists.')) {
                return;
            }
            document.getElementById('resolveDiseaseReportBarangayCode').value = barangayCode;
            document.getElementById('resolveDiseaseReportKey').value = key;
            document.getElementById('resolveDiseaseReportForm').submit();
        };
        const submitCancelReport = function (barangayCode, key) {
            if (!window.confirm('Cancel this report? Its history will remain, but the barangay marker will no longer be red unless another active report exists.')) {
                return;
            }
            document.getElementById('cancelDiseaseReportBarangayCode').value = barangayCode;
            document.getElementById('cancelDiseaseReportKey').value = key;
            document.getElementById('cancelDiseaseReportForm').submit();
        };
        const createPopupContent = function (barangayCode, barangayName, barangayReports) {
            const container = document.createElement('div');
            const title = document.createElement('strong');
            title.textContent = barangayName;
            container.appendChild(title);

            const heading = document.createElement('div');
            heading.className = 'small fw-semibold mt-2';
            heading.textContent = 'Disease report history';
            container.appendChild(heading);

            const list = document.createElement('ul');
            list.className = 'small ps-3 mb-2';
            const sortedReports = barangayReports.slice().sort(function (first, second) {
                return second.reported_on.localeCompare(first.reported_on);
            });
            if (sortedReports.length === 0) {
                const empty = document.createElement('li');
                empty.textContent = canUseMarkers ? 'No reports recorded.' : 'Report data is unavailable.';
                list.appendChild(empty);
            }
            sortedReports.forEach(function (report) {
                const item = document.createElement('li');
                const details = document.createElement('span');
                const statusAction = report.status === 'active' ? 'Reported by' : (report.status.charAt(0).toUpperCase() + report.status.slice(1) + ' by');
                const inspector = report.status_inspector || 'Inspector not recorded';
                details.textContent = report.disease + ' — ' + report.certainty + ', ' + (report.reported_on || 'date not set') + ' (' + report.status + '; ' + statusAction + ': ' + inspector + ')';
                item.appendChild(details);
                if (report.status === 'active' && canUseMarkers) {
                    const editButton = document.createElement('button');
                    editButton.type = 'button';
                    editButton.className = 'btn btn-sm btn-outline-primary d-block mt-1';
                    editButton.textContent = 'Edit report';
                    editButton.addEventListener('click', function () {
                        openReportDialog('edit', barangayCode, barangayName, report);
                    });
                    item.appendChild(editButton);

                    const resolveButton = document.createElement('button');
                    resolveButton.type = 'button';
                    resolveButton.className = 'btn btn-sm btn-outline-success d-block mt-1';
                    resolveButton.textContent = 'Resolve report';
                    resolveButton.addEventListener('click', function () {
                        submitResolveReport(barangayCode, report.key);
                    });
                    item.appendChild(resolveButton);
                    const cancelButton = document.createElement('button');
                    cancelButton.type = 'button';
                    cancelButton.className = 'btn btn-sm btn-outline-danger d-block mt-1';
                    cancelButton.textContent = 'Cancel report';
                    cancelButton.addEventListener('click', function () {
                        submitCancelReport(barangayCode, report.key);
                    });
                    item.appendChild(cancelButton);
                }
                list.appendChild(item);
            });
            container.appendChild(list);

            if (canUseMarkers) {
                const addButton = document.createElement('button');
                addButton.type = 'button';
                addButton.className = 'btn btn-sm btn-primary';
                addButton.textContent = 'Record disease report';
                addButton.addEventListener('click', function () {
                    openReportDialog('add', barangayCode, barangayName, null);
                });
                container.appendChild(addButton);
            }
            return container;
        };
        map.on('zoomend', updateBarangayLabels);

        document.querySelectorAll('.edit-disease-report').forEach(function (button) {
            button.addEventListener('click', function () {
                openReportDialog('edit', button.dataset.barangayCode, button.dataset.barangayName, {
                    key: button.dataset.reportKey,
                    disease: button.dataset.disease,
                    certainty: button.dataset.certainty,
                    reported_on: button.dataset.reportedOn
                });
            });
        });
        document.querySelectorAll('.resolve-disease-report').forEach(function (button) {
            button.addEventListener('click', function () {
                submitResolveReport(button.dataset.barangayCode, button.dataset.reportKey);
            });
            document.querySelectorAll('.cancel-disease-report').forEach(function (button) {
                button.addEventListener('click', function () {
                    submitCancelReport(button.dataset.barangayCode, button.dataset.reportKey);
                });
            });
        });

        Promise.all([
            fetch('/assets/data/lipa-city-boundary.geojson'),
            fetch('/assets/data/lipa-city-barangays.geojson')
        ])
            .then(function (responses) {
                if (!responses[0].ok || !responses[1].ok) {
                    throw new Error('Unable to load the Lipa City boundary data.');
                }
                return Promise.all(responses.map(function (response) {
                    return response.json();
                }));
            })
            .then(function (data) {
                const boundary = data[0];
                const barangays = data[1];
                if (!Array.isArray(barangays.features) || barangays.features.length !== 72) {
                    throw new Error('Expected all 72 Lipa City barangay boundaries.');
                }

                const barangayLayer = L.geoJSON(barangays, {
                    style: barangayStyle,
                    onEachFeature: function (feature, layer) {
                        const properties = feature.properties || {};
                        const barangayCode = String(properties.psgc_code || '');
                        const barangayName = String(properties.name || 'Barangay');
                        const barangayReports = reports[barangayCode] || [];
                        const activeReports = barangayReports.filter(function (report) {
                            return report.status === 'active';
                        });
                        const marker = L.circleMarker(layer.getBounds().getCenter(), {
                            radius: 8,
                            color: '#ffffff',
                            weight: 2,
                            fillColor: activeReports.length ? '#dc3545' : '#6c757d',
                            fillOpacity: 0.95
                        }).addTo(map);
                        marker.bindPopup(createPopupContent(barangayCode, barangayName, barangayReports));
                        layer.on('click', function () {
                            marker.openPopup();
                        });
                        layer.bindTooltip(String(feature.properties.name || 'Barangay'), {
                            permanent: true,
                            direction: 'center',
                            className: 'barangay-map-label'
                        });
                    }
                }).addTo(map);
                barangaysLoaded = true;

                const boundaryLayer = L.geoJSON(boundary, {
                    style: {
                        color: '#1f2937',
                        weight: 2.5,
                        opacity: 0.9,
                        fill: false
                    }
                }).addTo(map);
                const cityBounds = boundaryLayer.getBounds();
                map.fitBounds(cityBounds.pad(0.04));
                map.setMaxBounds(cityBounds.pad(0.08));
                map.setMinZoom(map.getZoom());
                updateBarangayLabels();
                boundaryLoaded = true;
                updateStatus();
            })
            .catch(function () {
                status.textContent = 'The Lipa City or barangay boundary data could not be loaded. Refresh the page and try again.';
                status.classList.add('text-danger');
            });
    })();
</script>
<script>
    (function () {
        const dialog = document.getElementById('diseaseReportDialog');
        document.getElementById('closeDiseaseReportDialog').addEventListener('click', function () {
            dialog.close();
        });
        document.getElementById('cancelDiseaseReport').addEventListener('click', function () {
            dialog.close();
        });
        <?php if ($reopenReportForm): ?>
            dialog.showModal();
        <?php endif; ?>
    })();
</script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
