<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$inspectionId = $_GET['inspection_id'] ?? '';
$inspection = null;
$registrations = get_array_values(firebase_get('client_registrations'));
$inspectionsRaw = firebase_get('inspections');
$inspections = is_array($inspectionsRaw) ? $inspectionsRaw : [];
$inspectionKey = null;
$message = null;
$error = null;

foreach ($inspections as $key => $item) {
    if (!empty($item['inspection_id']) && $item['inspection_id'] === $inspectionId) {
        $inspection = $item;
        $inspectionKey = $key;
        break;
    }
}

if (!$inspection) {
    header('Location: /inspector/dashboard.php');
    exit;
}

$registration = null;
foreach ($registrations as $regKey => $regItem) {
    if (!empty($inspection['registration_key']) && $regKey === $inspection['registration_key']) {
        $registration = $regItem;
        break;
    }
    if (!empty($inspection['registration_id']) && !empty($regItem['inspection_id']) && $regItem['inspection_id'] === $inspection['registration_id']) {
        $registration = $regItem;
        break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $postData = $_POST;
    $update = [];
    if ($postData['action'] === 'save_inspection') {
        $update['inspection_data'] = [
            'slaughter' => [
                'date' => $postData['slaughter_date'] ?? '',
                'time' => $postData['slaughter_time'] ?? '',
                'method' => $postData['slaughter_method'] ?? '',
                'remarks' => $postData['slaughter_remarks'] ?? '',
            ],
            'decision' => $postData['decision'] ?? '',
            'final_remarks' => $postData['final_remarks'] ?? '',
        ];
        if (!empty($postData['decision'])) {
            $update['decision'] = $postData['decision'];
            if ($postData['decision'] === 'Passed') {
                $update['status'] = 'Passed';
                $update['certificate_id'] = generate_certificate_id(get_array_values(firebase_get('certificates')));
            } elseif ($postData['decision'] === 'Partially Condemned') {
                $update['status'] = 'Partially Condemned';
            } elseif ($postData['decision'] === 'Condemned') {
                $update['status'] = 'Condemned';
            }
        }
        $result = firebase_patch('inspections/' . $inspectionKey, $update);
        if ($result !== null) {
            $message = 'Inspection saved successfully.';
            $inspection = array_merge($inspection, $update);
        } else {
            $error = 'Failed to update inspection.';
        }
    }
}

require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h3 class="mb-1">Inspection Detail</h3>
                <p class="text-secondary mb-0">Complete the inspection workflow and finalize the certification decision.</p>
            </div>
            <a href="/inspector/dashboard.php" class="btn btn-outline-secondary">Back to Dashboard</a>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-xl-6">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Inspection Summary</h5>
                        <p class="mb-1 text-secondary">Inspection ID</p>
                        <p class="fw-semibold"><?php echo htmlspecialchars($inspection['inspection_id']); ?></p>
                        <p class="mb-1 text-secondary">Batch ID</p>
                        <p class="fw-semibold"><?php echo htmlspecialchars($inspection['batch_id'] ?? 'N/A'); ?></p>
                        <p class="mb-1 text-secondary">Inspection Date</p>
                        <p class="fw-semibold"><?php echo htmlspecialchars($inspection['inspection_date'] ?? substr($inspection['created_at'] ?? '', 0, 10)); ?></p>
                        <p class="mb-1 text-secondary">Inspector</p>
                        <p class="fw-semibold"><?php echo htmlspecialchars($inspection['inspector_name'] ?? ($_SESSION['inspector_username'] ?? 'Inspector')); ?></p>
                        <p class="mb-1 text-secondary">Status</p>
                        <p><span class="badge <?php echo inspection_status_badge_class($inspection['status'] ?? 'Waiting for Client'); ?>"><?php echo htmlspecialchars($inspection['status'] ?? 'Waiting for Client'); ?></span></p>
                        <p class="mb-1 text-secondary">Owner</p>
                        <p class="fw-semibold"><?php echo htmlspecialchars($registration['owner_name'] ?? 'N/A'); ?></p>
                    </div>
                </div>

                <form method="post">
                    <input type="hidden" name="action" value="save_inspection">
                    <div class="card shadow-sm border-0 mb-4">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Slaughter Information</h5>
                            <?php $slaughter = $inspection['inspection_data']['slaughter'] ?? []; ?>
                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Date</label>
                                    <input type="date" class="form-control" name="slaughter_date" value="<?php echo htmlspecialchars($slaughter['date'] ?? ''); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Time</label>
                                    <input type="time" class="form-control" name="slaughter_time" value="<?php echo htmlspecialchars($slaughter['time'] ?? ''); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Method</label>
                                    <input type="text" class="form-control" name="slaughter_method" value="<?php echo htmlspecialchars($slaughter['method'] ?? ''); ?>">
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Remarks</label>
                                    <textarea class="form-control" name="slaughter_remarks" rows="3"><?php echo htmlspecialchars($slaughter['remarks'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-xl-6">
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Inspection Decision</h5>
                        <div class="mb-3">
                            <label class="form-label">Final Decision</label>
                            <select class="form-select" name="decision">
                                <option value=""<?php echo empty($inspection['decision']) ? ' selected' : ''; ?>>Select decision...</option>
                                <option value="Passed"<?php echo ($inspection['decision'] ?? '') === 'Passed' ? ' selected' : ''; ?>>Passed</option>
                                <option value="Partially Condemned"<?php echo ($inspection['decision'] ?? '') === 'Partially Condemned' ? ' selected' : ''; ?>>Partially Condemned</option>
                                <option value="Condemned"<?php echo ($inspection['decision'] ?? '') === 'Condemned' ? ' selected' : ''; ?>>Condemned</option>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Remarks</label>
                            <textarea class="form-control" name="final_remarks" rows="3"><?php echo htmlspecialchars($inspection['final_remarks'] ?? ''); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-success">Save Inspection</button>
                        <?php if (!empty($inspection['decision']) && $inspection['decision'] === 'Passed' && !empty($inspection['certificate_id'])): ?>
                            <a class="btn btn-outline-primary ms-2" href="/inspector/inspection_certificate.php?inspection_id=<?php echo urlencode($inspection['inspection_id']); ?>">Print Certificate</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>