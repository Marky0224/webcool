<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$inspections = array_values(array_filter(get_array_values(firebase_get('inspections')), 'is_array'));
$customers = array_values(array_filter(get_array_values(firebase_get('customers')), 'is_array'));
$savedCertificates = array_values(array_filter(get_array_values(firebase_get('certificates')), 'is_array'));
$diseaseReportsResult = firebase_get('disease_monitoring_reports');
$barangayDatasetPath = __DIR__ . '/../assets/data/lipa-city-barangays.geojson';
$barangayDatasetContents = is_file($barangayDatasetPath) ? file_get_contents($barangayDatasetPath) : false;
$barangayDataset = is_string($barangayDatasetContents) ? json_decode($barangayDatasetContents, true) : null;
$barangaysByCode = [];
if (is_array($barangayDataset['features'] ?? null)) {
    foreach ($barangayDataset['features'] as $feature) {
        $properties = is_array($feature['properties'] ?? null) ? $feature['properties'] : [];
        $code = trim((string) ($properties['psgc_code'] ?? ''));
        $name = trim((string) ($properties['name'] ?? ''));
        if ($code !== '' && $name !== '') {
            $barangaysByCode[$code] = $name;
        }
    }
}
$activeDiseaseReports = [];
if (is_array($diseaseReportsResult)) {
    foreach ($diseaseReportsResult as $barangayCode => $barangayReports) {
        if (!is_array($barangayReports)) {
            continue;
        }
        foreach ($barangayReports as $report) {
            if (!is_array($report) || (string) ($report['status'] ?? 'active') !== 'active') {
                continue;
            }
            $activeDiseaseReports[] = [
                'barangay_code' => (string) $barangayCode,
                'barangay_name' => $barangaysByCode[(string) $barangayCode] ?? 'Unknown barangay',
                'disease' => trim((string) ($report['disease'] ?? 'Unknown disease')),
                'certainty' => trim((string) ($report['certainty'] ?? 'suspected')),
            ];
        }
    }
}
$requestedDate = trim((string) ($_GET['date'] ?? date('Y-m-d')));
$parsedSelectedDate = DateTime::createFromFormat('!Y-m-d', $requestedDate);
$selectedDate = $parsedSelectedDate && $parsedSelectedDate->format('Y-m-d') === $requestedDate
    ? $requestedDate
    : date('Y-m-d');
$customersRegisteredOnDate = array_filter($customers, static function (array $customer) use ($selectedDate): bool {
    return substr((string) ($customer['created_at'] ?? ''), 0, 10) === $selectedDate;
});
$releasedMicIds = [];
$releasedCertificateIds = [];
$releasedInspectionIds = [];
foreach ($inspections as $inspection) {
    $certificateId = trim((string) ($inspection['certificate_id'] ?? ''));
    $inspectionId = trim((string) ($inspection['inspection_id'] ?? ''));
    if ($certificateId !== '') {
        $releasedCertificateIds[$certificateId] = true;
    }
    if ($inspectionId !== '' && $certificateId !== '') {
        $releasedInspectionIds[$inspectionId] = true;
    }
    if ($certificateId !== '' && strtolower((string) ($inspection['status'] ?? '')) === 'passed') {
        $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
        $releaseDate = '';
        foreach ([
            $inspection['certificate_created_at'] ?? '',
            $inspectionData['date_issued'] ?? '',
            $inspection['inspection_date'] ?? '',
            $inspection['created_at'] ?? '',
        ] as $dateValue) {
            if (trim((string) $dateValue) !== '') {
                $releaseDate = substr((string) $dateValue, 0, 10);
                break;
            }
        }
        if ($releaseDate === $selectedDate) {
            $releasedMicIds[$certificateId] = true;
        }
    }
}
foreach ($savedCertificates as $certificate) {
    $certificateId = trim((string) ($certificate['certificate_id'] ?? ''));
    $inspectionId = trim((string) ($certificate['inspection_id'] ?? ''));
    if ($certificateId !== '') {
        $releasedCertificateIds[$certificateId] = true;
    }
    if ($inspectionId !== '' && $certificateId !== '') {
        $releasedInspectionIds[$inspectionId] = true;
    }
    if ($certificateId !== '' && strtolower((string) ($certificate['status'] ?? '')) === 'passed') {
        $certificateData = is_array($certificate['inspection_data'] ?? null) ? $certificate['inspection_data'] : [];
        $releaseDate = '';
        foreach ([$certificate['issued_at'] ?? '', $certificateData['date_issued'] ?? ''] as $dateValue) {
            if (trim((string) $dateValue) !== '') {
                $releaseDate = substr((string) $dateValue, 0, 10);
                break;
            }
        }
        if ($releaseDate === $selectedDate) {
            $releasedMicIds[$certificateId] = true;
        }
    }
}
$selectedDateInspections = array_values(array_filter($inspections, static function (array $inspection) use ($selectedDate): bool {
    $inspectionDate = $inspection['inspection_date'] ?? $inspection['created_at'] ?? '';
    return substr((string) $inspectionDate, 0, 10) === $selectedDate;
}));
$pendingInspections = array_values(array_filter($selectedDateInspections, static function (array $inspection) use ($releasedCertificateIds, $releasedInspectionIds): bool {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    if (!is_array($inspectionData['ante_mortem'] ?? null)) {
        return false;
    }

    $certificateId = trim((string) ($inspection['certificate_id'] ?? ''));
    $inspectionId = trim((string) ($inspection['inspection_id'] ?? ''));
    return ($certificateId === '' || !isset($releasedCertificateIds[$certificateId]))
        && ($inspectionId === '' || !isset($releasedInspectionIds[$inspectionId]));
}));
$hasPendingInspectionsAcrossDates = false;
foreach ($inspections as $inspection) {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    if (!is_array($inspectionData['ante_mortem'] ?? null)) {
        continue;
    }

    $certificateId = trim((string) ($inspection['certificate_id'] ?? ''));
    $inspectionId = trim((string) ($inspection['inspection_id'] ?? ''));
    if (($certificateId === '' || !isset($releasedCertificateIds[$certificateId]))
        && ($inspectionId === '' || !isset($releasedInspectionIds[$inspectionId]))) {
        $hasPendingInspectionsAcrossDates = true;
        break;
    }
}
$selectedDateAnteMortems = array_values(array_filter($selectedDateInspections, static function (array $inspection): bool {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    return is_array($inspectionData['ante_mortem'] ?? null);
}));
$dashboardStats = [
    ['label' => 'Registered Customers', 'value' => count($customersRegisteredOnDate), 'icon' => 'fa-users', 'tone' => 'green'],
    ['label' => 'MICs Released', 'value' => count($releasedMicIds), 'icon' => 'fa-file-circle-check', 'tone' => 'teal'],
    ['label' => 'Pending Inspections', 'value' => count($pendingInspections), 'icon' => 'fa-clipboard-check', 'tone' => 'blue', 'href' => '/inspector/pending_inspections.php'],
    ['label' => 'Ante Mortem', 'value' => count($selectedDateAnteMortems), 'icon' => 'fa-file-circle-check', 'tone' => 'orange'],
];
$dashboardFunctions = [
    ['title' => 'Customer Registration', 'description' => 'Enter customer information and generate a QR code.', 'icon' => 'fa-user-plus', 'href' => '/inspector/customer_registration.php'],
    ['title' => 'Scan Customer QR Code', 'description' => 'Identify the customer using their unique code.', 'icon' => 'fa-qrcode', 'href' => '/inspector/customer_scanner.php'],
    ['title' => 'Ante Mortem List', 'description' => 'View saved animal details and documents before inspection.', 'icon' => 'fa-clipboard-list', 'href' => '/inspector/ante_mortems.php'],
    ['title' => 'Condemnation', 'description' => 'Record condemned animals or affected carcass parts and the authorized disposition.', 'icon' => 'fa-file-circle-exclamation', 'href' => '/inspector/condemnation.php'],
    ['title' => 'Meat Inspection Certificates', 'description' => 'View and manage issued meat inspection certificates.', 'icon' => 'fa-file-circle-check', 'href' => '/inspector/certificates.php'],
    ['title' => 'Barangay Disease Monitoring', 'description' => 'View disease monitoring activity across Lipa City.', 'icon' => 'fa-house-medical', 'href' => '/inspector/barangay_disease_monitoring.php'],
];

require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content inspector-dashboard">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <div class="container-fluid px-4 py-4">
        <div class="inspector-dashboard-hero mb-4">
            <div>
                <span class="inspector-dashboard-kicker">Meat Inspection System</span>
                <h1 class="mb-2">Meat Inspector Dashboard</h1>
                <p class="mb-0">Manage customer registration, animal inspections, and certificates.</p>
            </div>
        </div>
        <?php if ($activeDiseaseReports): ?>
            <div class="alert alert-danger d-flex align-items-start gap-3 mb-4" role="alert">
                <i class="fa-solid fa-triangle-exclamation fs-4 mt-1" aria-hidden="true"></i>
                <div>
                    <h2 class="h6 mb-1">Active disease report notification</h2>
                    <p class="mb-2">
                        <?php echo count($activeDiseaseReports) === 1 ? 'There is 1 active disease report.' : 'There are ' . count($activeDiseaseReports) . ' active disease reports.'; ?>
                    </p>
                    <ul class="mb-0 ps-3">
                        <?php foreach ($activeDiseaseReports as $report): ?>
                            <li>
                                <?php echo htmlspecialchars($report['disease']); ?>
                                (<?php echo htmlspecialchars(ucfirst($report['certainty'])); ?>)
                                — <?php echo htmlspecialchars($report['barangay_name']); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <a class="alert-link d-inline-block mt-2" href="/inspector/barangay_disease_monitoring.php">View disease monitoring</a>
                </div>
            </div>
        <?php endif; ?>

        <div class="inspector-dashboard-stats mb-4">
            <?php foreach ($dashboardStats as $stat): ?>
                <?php if (!empty($stat['href'])): ?>
                    <a class="inspector-stat-card inspector-stat-card-link" href="<?php echo htmlspecialchars($stat['href']); ?>" aria-label="View Ante Mortem records without an MIC">
                <?php else: ?>
                    <div class="inspector-stat-card">
                <?php endif; ?>
                    <div class="inspector-stat-icon <?php echo $stat['tone']; ?>"><i class="fa-solid <?php echo $stat['icon']; ?>"></i></div>
                    <div>
                        <p class="inspector-stat-label mb-2<?php echo $stat['label'] === 'Pending Inspections' && $hasPendingInspectionsAcrossDates ? ' text-danger' : ''; ?>"><?php echo htmlspecialchars($stat['label']); ?></p>
                        <strong class="inspector-stat-value"><?php echo htmlspecialchars((string) $stat['value']); ?></strong>
                    </div>
                <?php if (!empty($stat['href'])): ?>
                    </a>
                <?php else: ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>

        <section class="inspector-functions mb-4" aria-labelledby="mainFunctionsTitle">
            <h2 id="mainFunctionsTitle">Main Functions</h2>
            <div class="inspector-function-list">
                <?php foreach ($dashboardFunctions as $function): ?>
                    <a class="inspector-function-link" href="<?php echo htmlspecialchars($function['href']); ?>">
                        <span class="inspector-function-icon"><i class="fa-solid <?php echo $function['icon']; ?>"></i></span>
                        <span class="inspector-function-copy">
                            <strong><?php echo htmlspecialchars($function['title']); ?></strong>
                            <small><?php echo htmlspecialchars($function['description']); ?></small>
                        </span>
                        <i class="fa-solid fa-chevron-right inspector-function-arrow" aria-hidden="true"></i>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>

    </div>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
