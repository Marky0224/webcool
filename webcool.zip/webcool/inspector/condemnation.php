<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$inspectionsRaw = firebase_get('inspections');
$inspections = is_array($inspectionsRaw) ? $inspectionsRaw : [];
$customersRaw = firebase_get('customers');
$customers = is_array($customersRaw) ? $customersRaw : [];
$customersById = [];
foreach ($customers as $customerKey => $customerRecord) {
    if (!is_array($customerRecord)) {
        continue;
    }

    $customerId = trim((string) ($customerRecord['customer_id'] ?? $customerKey));
    if ($customerId !== '') {
        $customersById[$customerId] = $customerRecord;
    }
}
$errors = [];
$message = null;
$inspectionOptions = [];
foreach ($inspections as $key => $inspection) {
    if (!is_array($inspection)) {
        continue;
    }

    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    $embeddedCustomer = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
    $customerId = trim((string) ($inspection['customer_id'] ?? $embeddedCustomer['customer_id'] ?? ''));
    $customer = $customersById[$customerId] ?? $embeddedCustomer;
    $ownerCode = '';
    foreach ([$customer['owner_code'] ?? '', $customer['customer_code'] ?? ''] as $codeCandidate) {
        $codeCandidate = trim((string) $codeCandidate);
        if ($codeCandidate !== '') {
            $ownerCode = $codeCandidate;
            break;
        }
    }
    if ($customerId === '' && $ownerCode === '') {
        continue;
    }

    $customerName = trim((string) ($customer['owner_name'] ?? $inspection['customer_name'] ?? ''));
    $optionLabel = ($customerId !== '' ? $customerId : 'N/A')
        . ' — ' . ($customerName !== '' ? $customerName : 'N/A');
    if ($ownerCode !== '' && strcasecmp($ownerCode, $customerId) !== 0) {
        $optionLabel .= ' (' . $ownerCode . ')';
    }
    $inspectionOptions[] = [
        'key' => (string) $key,
        'label' => $optionLabel,
    ];
}
usort($inspectionOptions, static function (array $first, array $second): int {
    return strnatcasecmp($first['label'], $second['label']);
});
$form = [
    'customer_code' => trim((string) ($_POST['customer_code'] ?? '')),
    'animal_type' => (string) ($_POST['animal_type'] ?? 'pork'),
    'part_affected' => (string) ($_POST['part_affected'] ?? 'part'),
    'quantity' => trim((string) ($_POST['quantity'] ?? '1')),
    'weight' => trim((string) ($_POST['weight'] ?? '')),
    'reason' => (string) ($_POST['reason'] ?? 'Abnormal findings'),
    'remarks' => trim((string) ($_POST['remarks'] ?? '')),
];

$matchingInspection = null;
$matchingKey = null;
if ($form['customer_code'] !== '' && array_key_exists($form['customer_code'], $inspections) && is_array($inspections[$form['customer_code']])) {
    $matchingInspection = $inspections[$form['customer_code']];
    $matchingKey = $form['customer_code'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $allowedAnimalTypes = ['pork', 'beef', 'carabeef'];
    $allowedParts = ['whole', 'part', 'organ'];
    $allowedReasons = ['Abnormal findings', 'Disease suspected', 'Contamination', 'Injury', 'Other'];

    if ($matchingInspection === null) {
        $errors[] = 'Select a customer code and inspection record from the list.';
    }
    if (!in_array($form['animal_type'], $allowedAnimalTypes, true)) {
        $errors[] = 'Select a valid animal or meat type.';
    }
    if (!in_array($form['part_affected'], $allowedParts, true)) {
        $errors[] = 'Select the affected part.';
    }
    if (!in_array($form['reason'], $allowedReasons, true)) {
        $errors[] = 'Select a valid reason for condemnation.';
    }
    if (!ctype_digit($form['quantity']) || (int) $form['quantity'] < 1) {
        $errors[] = 'Quantity must be a whole number greater than zero.';
    }
    if ($form['part_affected'] !== 'whole'
        && ($form['weight'] === '' || !is_numeric($form['weight']) || (float) $form['weight'] < 0)) {
        $errors[] = 'Enter a valid non-negative weight.';
    }
    if ($form['remarks'] === '') {
        $errors[] = 'Enter the inspection findings or remarks.';
    }

    if (!$errors && $matchingInspection !== null && $matchingKey !== null) {
        $inspectionData = is_array($matchingInspection['inspection_data'] ?? null) ? $matchingInspection['inspection_data'] : [];
        $condemnation = [
            'animal_type' => $form['animal_type'],
            'part_affected' => $form['part_affected'],
            'quantity' => (int) $form['quantity'],
            'weight' => $form['part_affected'] === 'whole' ? null : (float) $form['weight'],
            'reason' => $form['reason'],
            'remarks' => $form['remarks'],
            'inspector' => get_current_inspector_name(),
            'recorded_at' => date('Y-m-d H:i:s'),
        ];
        $result = firebase_patch('inspections/' . $matchingKey, [
            'inspection_data' => array_merge($inspectionData, ['condemnation' => $condemnation]),
        ]);
        if ($result !== null && (!is_array($result) || !isset($result['error']))) {
            $message = 'Condemnation record saved for inspection ' . ($matchingInspection['inspection_id'] ?? $form['customer_code']) . '.';
            $form = array_fill_keys(array_keys($form), '');
            $form['animal_type'] = 'pork';
            $form['part_affected'] = 'part';
            $form['quantity'] = '1';
            $form['reason'] = 'Abnormal findings';
        } else {
            $errors[] = 'Unable to save the condemnation record. Please check the Firebase connection and try again.';
        }
    }
}

require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content inspector-condemnation-page">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <main class="container-fluid px-3 px-md-4 py-4">
        <div class="condemnation-card">
            <div class="condemnation-heading">
                <span class="condemnation-heading-icon"><i class="fa-regular fa-file-lines"></i></span>
                <div>
                    <h1>A New Condemnation Record</h1>
                    <p>Form fields the inspector fills out.</p>
                </div>
            </div>

            <?php if ($errors): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?><div><?php echo htmlspecialchars($error); ?></div><?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

            <form method="post" class="condemnation-form">
                <div class="condemnation-field">
                    <label for="customer_code">Customer</label>
                    <select id="customer_code" name="customer_code" required>
                        <option value="">Select customer</option>
                        <?php foreach ($inspectionOptions as $option): ?>
                            <option value="<?php echo htmlspecialchars($option['key']); ?>" <?php echo $form['customer_code'] === $option['key'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($option['label']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <fieldset class="condemnation-field">
                    <legend>Animal / Meat Type</legend>
                    <div class="condemnation-options">
                        <?php foreach (['pork' => 'Pork', 'beef' => 'Beef', 'carabeef' => 'Carabeef'] as $value => $label): ?>
                            <label><input type="radio" name="animal_type" value="<?php echo $value; ?>" <?php echo $form['animal_type'] === $value ? 'checked' : ''; ?>> <span><?php echo $label; ?></span></label>
                        <?php endforeach; ?>
                    </div>
                </fieldset>

                <fieldset class="condemnation-field">
                    <legend>Part Affected</legend>
                    <div class="condemnation-options condemnation-options-vertical">
                        <?php foreach (['whole' => 'Whole animal / carcass', 'part' => 'Part of carcass', 'organ' => 'Organ / entrails'] as $value => $label): ?>
                            <label><input type="radio" name="part_affected" value="<?php echo $value; ?>" <?php echo $form['part_affected'] === $value ? 'checked' : ''; ?>> <span><?php echo $label; ?></span></label>
                        <?php endforeach; ?>
                    </div>
                </fieldset>

                <div class="condemnation-two-columns">
                    <div class="condemnation-field">
                        <label for="quantity">Quantity</label>
                        <input id="quantity" name="quantity" type="number" min="1" step="1" value="<?php echo htmlspecialchars($form['quantity']); ?>" required>
                    </div>
                    <div class="condemnation-field">
                        <label for="weight">Weight (kg)</label>
                        <input id="weight" name="weight" type="number" min="0" step="0.01" value="<?php echo htmlspecialchars($form['weight']); ?>" placeholder="Weight in kg" <?php echo $form['part_affected'] === 'whole' ? 'disabled' : 'required'; ?>>
                    </div>
                </div>

                <div class="condemnation-field">
                    <label for="reason">Reason for Condemnation <span class="text-danger" aria-hidden="true">*</span><span class="visually-hidden"> required</span></label>
                    <select id="reason" name="reason" required>
                        <?php foreach (['Abnormal findings', 'Disease suspected', 'Contamination', 'Injury', 'Other'] as $reason): ?>
                            <option value="<?php echo htmlspecialchars($reason); ?>" <?php echo $form['reason'] === $reason ? 'selected' : ''; ?>><?php echo htmlspecialchars($reason); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="condemnation-field">
                    <label for="remarks">Inspection Findings / Remarks <span class="text-danger" aria-hidden="true">*</span><span class="visually-hidden"> required</span></label>
                    <textarea id="remarks" name="remarks" rows="4" placeholder="Describe the observed findings and basis for the decision." required aria-required="true"><?php echo htmlspecialchars($form['remarks']); ?></textarea>
                </div>

                <div class="d-flex justify-content-between gap-2 mt-4">
                    <a href="/inspector/dashboard.php" class="btn btn-outline-secondary">Cancel</a>
                    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk me-2"></i>Save Condemnation Record</button>
                </div>
            </form>
        </div>
    </main>
</div>
<script>
    const weightInput = document.getElementById('weight');
    document.querySelectorAll('input[name="part_affected"]').forEach(function (input) {
        input.addEventListener('change', function () {
            weightInput.disabled = this.value === 'whole';
            weightInput.required = this.value !== 'whole';
            if (weightInput.disabled) {
                weightInput.value = '';
            }
        });
    });

    const selectedPart = document.querySelector('input[name="part_affected"]:checked');
    if (selectedPart) {
        weightInput.disabled = selectedPart.value === 'whole';
        weightInput.required = selectedPart.value !== 'whole';
        if (weightInput.disabled) {
            weightInput.value = '';
        }
    }
</script>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
