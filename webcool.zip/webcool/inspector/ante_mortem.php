<?php
require_once __DIR__ . '/../includes/admin_functions.php';
ensure_inspector_logged_in();

$customerId = trim($_GET['customer_id'] ?? $_POST['customer_id'] ?? '');
$inspectionId = trim($_GET['inspection_id'] ?? $_POST['inspection_id'] ?? '');
$customer = null;
$inspection = null;
$inspectionKey = null;
$errors = [];
$message = null;
$documentSelectionMissing = false;
$reportDate = date('Y-m-d');
$categoryOptions = ['B' => 'Backyard', 'C' => 'Commercial', 'S' => 'Stockyard'];
$changeReason = trim((string) ($_POST['change_reason'] ?? ''));
$documentOptions = [
    'Animal Identification Certificate (AIC)',
    'Veterinary Health Certificate (VHC)',
    'Certificate of Status for African Swine Fever (ASF)',
    'Shipping Permit',
    'Para Vet Issue',
];

$inspectionsRaw = firebase_get('inspections');
$inspections = get_array_values($inspectionsRaw);
if ($inspectionId !== '') {
    foreach (is_array($inspectionsRaw) ? $inspectionsRaw : [] as $key => $item) {
        if (is_array($item) && ($item['inspection_id'] ?? '') === $inspectionId) {
            $inspection = $item;
            $inspectionKey = $key;
            $customer = is_array($item['inspection_data']['customer'] ?? null) ? $item['inspection_data']['customer'] : null;
            $customerId = $item['customer_id'] ?? $customer['customer_id'] ?? '';
            break;
        }
    }
    if ($inspection === null) {
        $errors[] = 'The requested Ante Mortem report could not be found.';
    }
} else {
    $customersResult = firebase_request('get', 'customers');
    if (is_array($customersResult) && !isset($customersResult['error'])) {
        foreach ($customersResult as $item) {
            if (is_array($item) && ($item['customer_id'] ?? '') === $customerId) {
                $customer = $item;
                break;
            }
        }
    } elseif ($customerId !== '') {
        $errors[] = 'Customer database is unavailable. Check the Firebase connection and try again.';
    }
}

if ($customerId !== '') {
    $registeredCustomers = firebase_request('get', 'customers');
    if (is_array($registeredCustomers) && !isset($registeredCustomers['error'])) {
        foreach ($registeredCustomers as $item) {
            if (is_array($item) && ($item['customer_id'] ?? '') === $customerId) {
                $customer = $item;
                break;
            }
        }
    }
}

$anteMortem = is_array($inspection['inspection_data']['ante_mortem'] ?? null) ? $inspection['inspection_data']['ante_mortem'] : [];
$farmOwnerDefault = trim((string) ($customer['farm_supplier_name'] ?? ''));
if ($farmOwnerDefault === '') {
    $farmOwnerDefault = trim((string) ($anteMortem['farm_owner'] ?? $customer['owner_name'] ?? ''));
}
$originDefault = trim((string) ($customer['barangay_of_animal_origin'] ?? $customer['origin'] ?? ''));
if ($originDefault === '') {
    $originDefault = trim((string) ($anteMortem['origin'] ?? ''));
}
$categoryDefault = get_ante_mortem_category_code((string) ($anteMortem['category'] ?? $customer['category'] ?? ''));

$blockedByConfirmedDiseaseReport = false;
if ($customer !== null) {
    $customerBarangay = trim((string) ($customer['barangay_of_animal_origin'] ?? $customer['origin'] ?? ''));
    $barangayDatasetPath = __DIR__ . '/../assets/data/lipa-city-barangays.geojson';
    $barangayDatasetContents = is_file($barangayDatasetPath) ? file_get_contents($barangayDatasetPath) : false;
    $barangayDataset = is_string($barangayDatasetContents) ? json_decode($barangayDatasetContents, true) : null;
    $barangayCode = null;
    foreach (is_array($barangayDataset['features'] ?? null) ? $barangayDataset['features'] : [] as $feature) {
        $properties = is_array($feature['properties'] ?? null) ? $feature['properties'] : [];
        if (strcasecmp(trim((string) ($properties['name'] ?? '')), $customerBarangay) === 0) {
            $barangayCode = (string) ($properties['psgc_code'] ?? '');
            break;
        }
    }
    if ($barangayCode !== null && preg_match('/^0401014\d{3}$/', $barangayCode)) {
        $barangayReports = firebase_request('GET', 'disease_monitoring_reports/' . $barangayCode);
        if (is_array($barangayReports)) {
            foreach ($barangayReports as $report) {
                if (is_array($report)
                    && ($report['status'] ?? 'active') === 'active'
                    && ($report['certainty'] ?? '') === 'confirmed'
                ) {
                    $blockedByConfirmedDiseaseReport = true;
                    break;
                }
            }
        }
    }
}

if ($blockedByConfirmedDiseaseReport) {
    $errors[] = 'Ante Mortem inspection is not available because a confirmed disease has been reported in this customer’s barangay.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $customer !== null && !$blockedByConfirmedDiseaseReport) {
    $heads = trim($_POST['no_of_heads'] ?? '');
    $farmOwner = $farmOwnerDefault;
    $origin = $originDefault;
    $category = trim($_POST['category'] ?? '');
    $documentPresented = array_values(array_unique(array_filter(
        array_map('trim', is_array($_POST['document_presented'] ?? null) ? $_POST['document_presented'] : []),
        static fn(string $document): bool => in_array($document, $documentOptions, true)
    )));
    $documentNumber = trim($_POST['document_number'] ?? '');

    if ($heads === '' || $farmOwner === '' || $origin === '' || $category === '') {
        $errors[] = 'Complete all required Ante Mortem report fields.';
    }
    if (!$documentPresented) {
        $documentSelectionMissing = true;
    }
    if ($category !== '' && !array_key_exists($category, $categoryOptions)) {
        $errors[] = 'Select a valid category.';
    }
    if ($inspection !== null && $changeReason === '') {
        $errors[] = 'Enter a reason for changing this Ante Mortem report.';
    }

    if (empty($errors)) {
        $anteMortem = [
            'no_of_heads' => $heads,
            'farm_owner' => $farmOwner,
            'origin' => $origin,
            'category' => $category,
            'document_presented' => $documentPresented,
            'document_number' => $documentNumber,
        ];
        if ($inspection !== null && $inspectionKey !== null) {
            $anteMortem['change_reason'] = $changeReason;
            $anteMortem['changed_at'] = date('Y-m-d H:i:s');
            $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
            $result = firebase_patch('inspections/' . $inspectionKey, [
                'inspection_data' => array_merge($inspectionData, [
                    'customer' => $customer,
                    'ante_mortem' => $anteMortem,
                ]),
            ]);
            if ($result !== null) {
                $_SESSION['ante_mortem_notice'] = 'Ante Mortem report updated successfully.';
                header('Location: /inspector/customer_scanner.php');
                exit;
            } else {
                $errors[] = 'Failed to update the Ante Mortem report.';
            }
        } else {
            $newInspectionId = generate_inspection_id($inspections);
            $newInspection = [
                'inspection_id' => $newInspectionId,
                'batch_id' => generate_batch_id($inspections),
                'inspection_date' => $reportDate,
                'inspector_name' => get_current_inspector_name(),
                'customer_id' => $customer['customer_id'] ?? $customerId,
                'customer_name' => $customer['owner_name'] ?? '',
                'customer_contact' => $customer['contact_number'] ?? '',
                'created_at' => date('Y-m-d H:i:s'),
                'status' => 'Ante-Mortem',
                'decision' => null,
                'qr_code_value' => $newInspectionId,
                'inspection_data' => [
                    'customer' => $customer,
                    'ante_mortem' => $anteMortem,
                ],
                'certificate_id' => null,
            ];
            $result = firebase_post('inspections', $newInspection);
            if (!empty($result['name'])) {
                $_SESSION['ante_mortem_notice'] = 'Ante Mortem report saved successfully. Inspection ID: ' . $newInspectionId . '.';
                header('Location: /inspector/customer_scanner.php');
                exit;
            } else {
                $errors[] = 'Failed to save the Ante Mortem report.';
            }
        }
    }
}

$isEdit = $inspection !== null;
require_once __DIR__ . '/../includes/admin_header.php';
?>
<div class="main-content inspector-ante-page">
    <?php require_once __DIR__ . '/../includes/inspector_navbar.php'; ?>
    <main class="container-fluid px-3 px-md-4 py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-4">
            <div>
                <h1 class="mb-2"><?php echo $isEdit ? 'Edit Ante Mortem Report' : 'Ante Mortem Report'; ?></h1>
                <p class="text-secondary mb-0">Record the animal details and documents before inspection.</p>
            </div>
            <a href="/inspector/customer_scanner.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-2"></i>Back to Scanner</a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?><div><?php echo htmlspecialchars($error); ?></div><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>

        <?php if ($customer && !$blockedByConfirmedDiseaseReport): ?>
            <form method="post">
                <input type="hidden" name="customer_id" value="<?php echo htmlspecialchars($customerId); ?>">
                <?php if ($isEdit): ?>
                    <input type="hidden" name="inspection_id" value="<?php echo htmlspecialchars($inspectionId); ?>">
                <?php endif; ?>
                <div class="card shadow-sm border-0">
                    <div class="card-body p-3 p-md-4">
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle mb-0 inspector-ante-report">
                                <thead>
                                    <tr>
                                        <th>Date / Ante Mortem Report</th>
                                        <th>Owner / Code</th>
                                        <th>No. of Heads</th>
                                        <th>Farm / Supplier Name</th>
                                        <th>Origin / Place</th>
                                        <th>Category</th>
                                        <th>Document Presented</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo htmlspecialchars(date('F d, Y', strtotime($reportDate))); ?></td>
                                        <td><?php echo htmlspecialchars((string) ($customer['owner_name'] ?? 'N/A') . ' / ' . ($customer['owner_code'] ?? $customer['customer_id'] ?? 'N/A')); ?></td>
                                        <td><input class="form-control" type="number" min="1" name="no_of_heads" required value="<?php echo htmlspecialchars($_POST['no_of_heads'] ?? $anteMortem['no_of_heads'] ?? ''); ?>"></td>
                                        <td><?php echo htmlspecialchars($farmOwnerDefault !== '' ? $farmOwnerDefault : 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($originDefault !== '' ? $originDefault : 'N/A'); ?></td>
                                        <td>
                                            <?php $selectedCategory = get_ante_mortem_category_code((string) ($_POST['category'] ?? $categoryDefault)); ?>
                                            <select class="form-select w-100" name="category" required>
                                                <option value="" disabled<?php echo array_key_exists($selectedCategory, $categoryOptions) ? '' : ' selected'; ?>>Select category</option>
                                                <?php foreach ($categoryOptions as $categoryCode => $categoryLabel): ?>
                                                    <option value="<?php echo htmlspecialchars($categoryCode); ?>"<?php echo $selectedCategory === $categoryCode ? ' selected' : ''; ?>><?php echo htmlspecialchars($categoryLabel); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <?php
                                            $savedDocuments = is_array($_POST['document_presented'] ?? null)
                                            ? $_POST['document_presented']
                                            : (is_array($anteMortem['document_presented'] ?? null) ? $anteMortem['document_presented'] : (($anteMortem['document_presented'] ?? '') !== '' ? [$anteMortem['document_presented']] : []));
                                            $savedDocuments = array_map(
                                                static fn($document): string => get_ante_mortem_document_label((string) $document),
                                                $savedDocuments
                                            );
                                            ?>
                                            <div class="document-presented-options d-flex flex-column gap-2">
                                            <?php foreach ($documentOptions as $document): ?>
                                                <label class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="document_presented[]" value="<?php echo htmlspecialchars($document); ?>"<?php echo in_array($document, $savedDocuments, true) ? ' checked' : ''; ?>>
                                                    <span class="form-check-label"><?php echo htmlspecialchars($document); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                            </div>
                                            <small class="form-text text-muted">Select at least one document.</small>
                                            <?php if ($documentSelectionMissing): ?>
                                                <div class="text-danger small mt-1">Select at least one document presented.</div>
                                            <?php endif; ?>
                                            <input class="form-control mt-2" type="text" name="document_number" placeholder="Document number" value="<?php echo htmlspecialchars($_POST['document_number'] ?? $anteMortem['document_number'] ?? ''); ?>">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <?php if ($isEdit): ?>
                            <div class="mt-3">
                                <label class="form-label" for="change_reason">Reason for Change <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="change_reason" name="change_reason" rows="3" maxlength="1000" required><?php echo htmlspecialchars($changeReason); ?></textarea>
                            </div>
                        <?php endif; ?>
                        <div class="d-flex flex-column flex-sm-row justify-content-end gap-2 mt-4">
                            <a href="/inspector/ante_mortems.php" class="btn btn-outline-secondary">Cancel</a>
                            <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk me-2"></i><?php echo $isEdit ? 'Update' : 'Save'; ?> Ante Mortem Report</button>
                        </div>
                    </div>
                </div>
            </form>
        <?php elseif ($customerId === ''): ?>
            <div class="alert alert-warning">Scan a customer first before opening the Ante Mortem report.</div>
        <?php endif; ?>
    </main>
</div>
<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
