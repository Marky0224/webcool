#!/usr/bin/env python3
"""Python HTTP service and launcher for monthly inspection forecasts."""

import csv
import json
import math
import os
import secrets
import subprocess
import sys
import time
from datetime import date
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.error import URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen


HOST = os.environ.get("PYTHON_FORECAST_HOST", "127.0.0.1")
PORT = int(os.environ.get("PYTHON_FORECAST_PORT", "8001"))
TOKEN = os.environ.get("PYTHON_FORECAST_TOKEN", "")
MAX_REQUEST_BYTES = 65536
TRAINING_DATA_PATH = Path(__file__).resolve().parent / "data" / "monthly_data.csv"


def solve_linear_system(matrix, values):
    """Solve a small square system using Gaussian elimination with pivoting."""
    size = len(values)
    augmented = [list(row) + [values[index]] for index, row in enumerate(matrix)]

    for column in range(size):
        pivot = max(range(column, size), key=lambda row: abs(augmented[row][column]))
        if abs(augmented[pivot][column]) < 1e-10:
            raise ValueError("The training data does not contain enough variation.")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]

        divisor = augmented[column][column]
        augmented[column] = [value / divisor for value in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            augmented[row] = [
                current - factor * pivot_value
                for current, pivot_value in zip(augmented[row], augmented[column])
            ]

    return [augmented[index][-1] for index in range(size)]


def model_features(month_offset, month):
    # Linear trend plus month-of-year effects; January is the reference month.
    return [1.0, float(month_offset)] + [
        1.0 if month == indicator else 0.0
        for indicator in range(2, 13)
    ]


def load_monthly_history():
    """Load consecutive monthly totals from the project training CSV."""
    observations = []
    try:
        training_file = TRAINING_DATA_PATH.open("r", encoding="utf-8-sig", newline="")
    except OSError as error:
        raise ValueError("Training data could not be opened: %s" % error)

    with training_file:
        reader = csv.DictReader(training_file)
        if reader.fieldnames is None or not {"month", "volume"}.issubset(reader.fieldnames):
            raise ValueError("Training CSV must contain month and volume columns.")

        for item in reader:
            if not isinstance(item, dict):
                raise ValueError("Each CSV row must contain a month and volume.")
            month_value = item.get("month", "")
            volume_value = item.get("volume", "")
            try:
                observation_date = date.fromisoformat(month_value)
            except (TypeError, ValueError):
                raise ValueError("CSV month values must use YYYY-MM-DD format.")
            if observation_date.day != 1:
                raise ValueError("CSV dates must be the first day of each month.")
            try:
                count = float(volume_value)
            except (TypeError, ValueError, OverflowError):
                raise ValueError("CSV volume values must be numeric.")
            if not math.isfinite(count) or count < 0:
                raise ValueError("CSV volume values must be finite and non-negative.")
            observations.append((observation_date, count))

    if len(observations) < 12:
        raise ValueError("At least 12 months of training data are required.")
    observations.sort(key=lambda observation: observation[0])
    for previous, current in zip(observations, observations[1:]):
        previous_month = previous[0].year * 12 + previous[0].month
        current_month = current[0].year * 12 + current[0].month
        if current_month != previous_month + 1:
            raise ValueError("Training data must contain one observation per consecutive month.")
    return observations


def train_and_predict(horizon, as_of_date=None):
    """Fit a trend through the selected month and predict the following months."""
    if not isinstance(horizon, int) or isinstance(horizon, bool) or horizon < 1 or horizon > 7:
        raise ValueError("The forecast horizon must be from 1 to 7 months.")

    observations = load_monthly_history()
    if as_of_date is None:
        forecast_origin = observations[-1][0]
    else:
        if not isinstance(as_of_date, str):
            raise ValueError("The forecast date must use YYYY-MM-DD format.")
        try:
            selected_date = date.fromisoformat(as_of_date)
        except ValueError:
            raise ValueError("The forecast date must use YYYY-MM-DD format.")
        if selected_date.isoformat() != as_of_date:
            raise ValueError("The forecast date must use YYYY-MM-DD format.")
        forecast_origin = date(selected_date.year, selected_date.month, 1)

    observations = [
        observation for observation in observations
        if observation[0] <= forecast_origin
    ]
    if len(observations) < 12:
        raise ValueError("At least 12 months of training data must be available through the selected date.")

    start_date = observations[0][0]
    rows = []
    targets = []
    for observation_date, count in observations:
        month_offset = (
            (observation_date.year - start_date.year) * 12
            + observation_date.month - start_date.month
        )
        rows.append(model_features(month_offset, observation_date.month))
        targets.append(count)

    feature_count = len(rows[0])
    gram = [[0.0] * feature_count for _ in range(feature_count)]
    target_products = [0.0] * feature_count
    for row, target in zip(rows, targets):
        for left in range(feature_count):
            target_products[left] += row[left] * target
            for right in range(feature_count):
                gram[left][right] += row[left] * row[right]

    # Regularization stabilizes seasonal effects with a modest training set.
    for index in range(2, feature_count):
        gram[index][index] += 10.0

    coefficients = solve_linear_system(gram, target_products)
    observed_counts = {
        observation_date: count
        for observation_date, count in observations
    }
    history = []
    for months_ago in range(6, -1, -1):
        month_index = forecast_origin.year * 12 + forecast_origin.month - 1 - months_ago
        history_date = date(month_index // 12, month_index % 12 + 1, 1)
        history.append({
            "date": history_date.isoformat(),
            "count": observed_counts.get(history_date),
        })

    predictions = []
    for offset in range(1, horizon + 1):
        month_index = forecast_origin.year * 12 + forecast_origin.month - 1 + offset
        forecast_date = date(month_index // 12, month_index % 12 + 1, 1)
        month_offset = (
            (forecast_date.year - start_date.year) * 12
            + forecast_date.month - start_date.month
        )
        features = model_features(month_offset, forecast_date.month)
        predicted_volume = sum(
            coefficient * feature
            for coefficient, feature in zip(coefficients, features)
        )
        predictions.append({
            "date": forecast_date.isoformat(),
            "count": max(0.0, predicted_volume),
        })

    return {"history": history, "predictions": predictions}


def forecast_service_is_ready():
    request = Request(
        "http://127.0.0.1:%s/forecast" % PORT,
        data=b'{"horizon":7}',
        headers={
            "Authorization": "Bearer " + TOKEN,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=2) as response:
            result = json.loads(response.read().decode("utf-8"))
    except (OSError, URLError, TimeoutError, ValueError):
        return False

    if not isinstance(result, dict):
        return False
    history = result.get("history")
    predictions = result.get("predictions")
    return (
        isinstance(history, list)
        and len(history) == 7
        and isinstance(predictions, list)
        and len(predictions) == 7
    )


def start_forecast_service():
    """Start the HTTP service in the background and wait until it responds."""
    if forecast_service_is_ready():
        return

    project_directory = Path(__file__).resolve().parent
    data_directory = Path(
        os.environ.get("LOCALAPPDATA") or Path.home() / ".local" / "share"
    )
    logs_directory = data_directory / "Webcool" / "logs"
    logs_directory.mkdir(parents=True, exist_ok=True)
    stdout_path = logs_directory / "forecast-service.log"
    stderr_path = logs_directory / "forecast-service-error.log"

    process_options = {}
    if os.name == "nt":
        process_options["creationflags"] = (
            subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        )
    else:
        process_options["start_new_session"] = True

    with stdout_path.open("a", encoding="utf-8") as stdout_log:
        with stderr_path.open("a", encoding="utf-8") as stderr_log:
            process = subprocess.Popen(
                [sys.executable, "-u", str(Path(__file__).resolve())],
                cwd=str(project_directory),
                stdin=subprocess.DEVNULL,
                stdout=stdout_log,
                stderr=stderr_log,
                **process_options
            )

    for _ in range(15):
        if forecast_service_is_ready():
            return
        if process.poll() is not None:
            break
        time.sleep(1)

    try:
        details = stderr_path.read_text(encoding="utf-8").splitlines()[-20:]
    except OSError:
        details = []
    message = "Forecast service did not start at http://127.0.0.1:%s/forecast." % PORT
    if details:
        message += "\n" + "\n".join(details)
    raise RuntimeError(message)


class ForecastHandler(BaseHTTPRequestHandler):
    def send_json(self, status, payload):
        response = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(response)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(response)

    def do_POST(self):
        if urlparse(self.path).path != "/forecast":
            self.send_json(404, {"error": "Not found."})
            return

        if TOKEN and not secrets.compare_digest(
            self.headers.get("Authorization", ""),
            "Bearer " + TOKEN,
        ):
            self.send_json(401, {"error": "Unauthorized."})
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_json(400, {"error": "Invalid Content-Length."})
            return
        if content_length <= 0 or content_length > MAX_REQUEST_BYTES:
            self.send_json(413, {"error": "Request body size is invalid."})
            return

        try:
            payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("Request body must be a JSON object.")
            forecast = train_and_predict(payload.get("horizon"), payload.get("as_of_date"))
        except (UnicodeDecodeError, json.JSONDecodeError, AttributeError, OSError, ValueError) as error:
            self.send_json(400, {"error": str(error)})
            return

        self.send_json(200, forecast)

    def log_message(self, format_string, *args):
        print("%s - %s" % (self.address_string(), format_string % args))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1:] == ["--start"]:
        try:
            start_forecast_service()
        except (OSError, RuntimeError, subprocess.SubprocessError) as error:
            raise SystemExit(str(error))
        print("Forecast service is ready at http://127.0.0.1:%s/forecast" % PORT)
    else:
        if HOST not in ("127.0.0.1", "localhost", "::1") and not TOKEN:
            raise SystemExit("Set PYTHON_FORECAST_TOKEN before binding outside localhost.")
        server = HTTPServer((HOST, PORT), ForecastHandler)
        print("Forecast service listening on http://%s:%s/forecast" % (HOST, PORT))
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
