<?php
require_once __DIR__ . '/includes/admin_functions.php';

$lookupId = trim((string) ($_GET['inspection_id'] ?? $_GET['id'] ?? ''));
$inspectionId = $lookupId;
$inspections = get_array_values(firebase_get('inspections'));
$inspection = null;
foreach ($inspections as $item) {
    if (
        is_array($item)
        && (
            (string) ($item['inspection_id'] ?? '') === $lookupId
            || (string) ($item['certificate_id'] ?? '') === $lookupId
        )
    ) {
        $inspection = $item;
        $inspectionId = (string) ($item['inspection_id'] ?? $lookupId);
        break;
    }
}

$certificates = get_array_values(firebase_get('certificates'));
$certificate = null;
$dateIssued = '';
$controlNumber = '';
$micQrPayload = '';
foreach ($certificates as $item) {
    if (
        is_array($item)
        && (
            (string) ($item['inspection_id'] ?? '') === $inspectionId
            || (string) ($item['certificate_id'] ?? '') === $lookupId
        )
    ) {
        $certificate = $item;
        $inspectionId = (string) ($item['inspection_id'] ?? $inspectionId);
        break;
    }
}

$certificateId = trim((string) ($certificate['certificate_id'] ?? $inspection['certificate_id'] ?? ''));
if (!$inspection || $certificateId === '') {
    http_response_code(404);
    $inspection = null;
} else {
    $inspectionData = is_array($inspection['inspection_data'] ?? null) ? $inspection['inspection_data'] : [];
    $certificateData = is_array($certificate['inspection_data'] ?? null) ? $certificate['inspection_data'] : [];
    $inspectionData = array_merge($inspectionData, $certificateData);

    $registration = is_array($inspectionData['customer'] ?? null) ? $inspectionData['customer'] : [];
    $registrations = firebase_get('client_registrations');
    if (
        is_array($registrations)
        && !empty($inspection['registration_key'])
        && is_array($registrations[$inspection['registration_key']] ?? null)
    ) {
        $registration = $registrations[$inspection['registration_key']];
    } elseif (is_array($registrations)) {
        foreach ($registrations as $registrationItem) {
            if (
                is_array($registrationItem)
                && !empty($inspection['registration_id'])
                && ($registrationItem['inspection_id'] ?? '') === $inspection['registration_id']
            ) {
                $registration = $registrationItem;
                break;
            }
        }
    }

    $meatDetails = is_array($inspectionData['meat_details'] ?? null) ? $inspectionData['meat_details'] : [];
    $ownerDealer = (string) ($inspectionData['owner_dealer'] ?? $registration['owner_name'] ?? $inspection['customer_name'] ?? $certificate['customer_name'] ?? 'N/A');
    $inspectorName = (string) ($certificate['inspector_name'] ?? $inspection['inspector_name'] ?? 'N/A');
    $controlNumber = (string) ($certificate['control_number'] ?? $inspection['control_number'] ?? $inspectionData['control_number'] ?? '');
    $dateIssued = (string) ($inspectionData['date_issued'] ?? $inspection['inspection_date'] ?? $certificate['issued_at'] ?? substr((string) ($inspection['created_at'] ?? ''), 0, 10));
    $timeIssued = (string) ($inspectionData['time_issued'] ?? '');
    $micQrPayload = mic_qr_payload($inspection, $inspectionData, $registration, $certificate);
}

$documentTitle = 'Meat Inspection Certificate';
require_once __DIR__ . '/includes/admin_header.php';
require_once __DIR__ . '/includes/navbar.php';
?>
<main class="container py-4 public-certificate-page">
    <?php if (!$inspection): ?>
        <div class="alert alert-warning">This issued Meat Inspection Certificate could not be found.</div>
    <?php else: ?>
        <div class="d-flex justify-content-end mb-3 no-print">
            <button class="btn print-button" type="button" onclick="window.print()">
                <i class="fa-solid fa-print me-2"></i>Print Certificate
            </button>
        </div>
        <div class="certificate-preview-card certificate-view-only">
            <article class="certificate-preview-paper">
                <header class="certificate-letterhead">
                    <div class="certificate-letterhead-top">
                        <img src="/assets/images/lipa-city-seal.png" alt="City of Lipa official seal">
                        <p>Republic of the Philippines<br>City of Lipa</p>
                        <img src="/assets/images/lipa-veterinary-office-seal.png" alt="Lipa City Veterinary Office seal">
                    </div>
                    <h1>OFFICE OF THE CITY VETERINARIAN</h1>
                    <p class="certificate-control-number"><strong>CN:</strong> <?php echo htmlspecialchars($controlNumber !== '' ? $controlNumber : '________'); ?></p>
                    <p class="certificate-letterhead-office">LIPA CITY SLAUGHTERHOUSE</p>
                    <p class="certificate-letterhead-accreditation">NMIS ACCREDITATION NO. SH-989-AAA</p>
                </header>
                <h2>MEAT INSPECTION CERTIFICATE</h2>
                <p>This certifies that meat/meat by products described below are slaughtered in accordance with the Meat Inspection Code of the Philippines and at the time and date of inspection are found fit for human consumption.</p>
                <table class="certificate-table w-100 text-uppercase">
                    <thead>
                        <tr><th style="width: 50%;">Type of Meat/Entrails</th><th style="width: 25%;">Quantity</th><th style="width: 25%;">Weight</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach (['PORK' => 'pork', 'BEEF' => 'beef', 'CARABEEF' => 'carabeef', 'ENTRAILS' => 'entrails'] as $label => $key):
                            $detail = is_array($meatDetails[$key] ?? null) ? $meatDetails[$key] : [];
                            $quantity = $detail['qty'] ?? $inspection['qty_' . $key] ?? '';
                            $weight = $detail['weight'] ?? $inspection['weight_' . $key] ?? '';
                        ?>
                            <tr>
                                <td class="fw-semibold"><?php echo $label; ?></td>
                                <td><?php echo htmlspecialchars((string) ($quantity !== '' ? $quantity : ($key === 'entrails' ? 'set/s' : 'hd/s'))); ?></td>
                                <td><?php echo htmlspecialchars((string) ($weight !== '' ? $weight : 'kls.')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <dl>
                    <dt>Name of Owner (Dealer)</dt><dd><?php echo htmlspecialchars($ownerDealer); ?></dd>
                    <dt>Point of Origin</dt><dd><?php echo htmlspecialchars((string) ($inspectionData['origin'] ?? 'FMIMC')); ?></dd>
                    <dt>Destination</dt><dd><?php echo htmlspecialchars((string) ($inspectionData['destination'] ?? 'Lipa')); ?></dd>
                    <dt>Time Issued</dt><dd><?php echo htmlspecialchars($timeIssued); ?></dd>
                    <dt>Date Issued</dt><dd><?php echo htmlspecialchars($dateIssued); ?></dd>
                </dl>
                <div class="certificate-preview-signatures">
                    <span><strong><?php echo htmlspecialchars($ownerDealer); ?></strong><small>Owner/Dealer</small></span>
                    <span><strong><?php echo htmlspecialchars($inspectorName); ?></strong><small>Meat Inspector</small></span>
                </div>
                <div class="certificate-preview-qr">
                    <div class="mic-qr-code" data-qr-payload="<?php echo htmlspecialchars($micQrPayload, ENT_QUOTES, 'UTF-8'); ?>"></div>
                    <span>Scan to view MIC details as text</span>
                </div>
            </article>
        </div>
    <?php endif; ?>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="/assets/js/mic-qr.js?v=<?php echo (int) filemtime(__DIR__ . '/assets/js/mic-qr.js'); ?>"></script>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
