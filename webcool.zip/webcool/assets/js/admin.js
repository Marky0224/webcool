document.addEventListener('DOMContentLoaded', function () {
    const toastContainer = document.querySelector('.toast-container');

    function showToast(message, type = 'success') {
        const toastEl = document.createElement('div');
        toastEl.className = `toast align-items-center text-bg-${type} border-0`;
        toastEl.setAttribute('role', 'alert');
        toastEl.setAttribute('aria-live', 'assertive');
        toastEl.setAttribute('aria-atomic', 'true');
        toastEl.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        toastContainer.appendChild(toastEl);
        const toast = new bootstrap.Toast(toastEl, { delay: 5000 });
        toast.show();
        toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
    }

    window.adminShowToast = showToast;

    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function () {
            sidebar.classList.toggle('open');
            document.body.classList.toggle('sidebar-open');
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', function () {
            sidebar.classList.remove('open');
            document.body.classList.remove('sidebar-open');
        });
    }

    const currentDateTime = document.getElementById('currentDateTime');
    if (currentDateTime) {
        function updateDateTime() {
            const now = new Date();
            const options = { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' };
            currentDateTime.textContent = now.toLocaleDateString('en-US', options);
        }
        updateDateTime();
        setInterval(updateDateTime, 60000);
    }

    if (window.jQuery && $.fn.dataTable) {
        $.fn.dataTable.ext.type.order['admin-date-pre'] = function (value) {
            const dateText = String(value)
                .replace(/<[^>]*>/g, ' ')
                .replace(/&nbsp;/gi, ' ')
                .trim();
            const timestamp = Date.parse(dateText);
            return Number.isNaN(timestamp) ? Number.NEGATIVE_INFINITY : timestamp;
        };

        $.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
            const table = settings.nTable;
            const selectedDate = table.adminSelectedDate || '';
            if (!selectedDate) {
                return true;
            }

            const row = settings.aoData[dataIndex];
            const dateColumns = table.adminDateColumns || [];
            return dateColumns.some(function (columnIndex) {
                const cell = row.anCells && row.anCells[columnIndex];
                const cellText = cell ? cell.textContent.trim() : String(data[columnIndex] || '').trim();
                const isoDate = cellText.match(/\b\d{4}-\d{2}-\d{2}\b/);
                if (isoDate) {
                    return isoDate[0] === selectedDate;
                }

                const timestamp = Date.parse(cellText);
                if (Number.isNaN(timestamp)) {
                    return false;
                }
                const parsedDate = new Date(timestamp);
                const parsedIsoDate = [
                    parsedDate.getFullYear(),
                    String(parsedDate.getMonth() + 1).padStart(2, '0'),
                    String(parsedDate.getDate()).padStart(2, '0')
                ].join('-');
                return parsedIsoDate === selectedDate;
            });
        });

        $('.datatable').each(function () {
            const $table = $(this);
            const thCount = $table.find('thead th').length || $table.find('tbody tr:first td').length || 0;
            const columns = Array.from({ length: thCount }, () => null);
            const hasCertificateNumber = $table.data('certificate-number') === true || $table.data('certificate-number') === 'true';
            const dateColumns = $table.find('thead th').toArray().reduce(function (indices, header, index) {
                if (/\b(date|submitted|created|recorded|issued|registered)\b/i.test(header.textContent || '')) {
                    indices.push(index);
                }
                return indices;
            }, []);
            const hasCustomFilters = $table.data('filter-toolbar') === false || $table.data('filter-toolbar') === 'false';
            const toolbar = hasCustomFilters ? null : document.createElement('div');
            const pageDate = new URLSearchParams(window.location.search).get('date') || '';
            const validPageDate = /^\d{4}-\d{2}-\d{2}$/.test(pageDate) ? pageDate : '';
            const tableId = $table.attr('id') || `adminTable${$('.datatable').index(this) + 1}`;
            let searchInput = null;
            let dateInput = null;
            let dateBadge = null;

            if (toolbar) {
                toolbar.className = 'admin-table-filter-toolbar mb-3';
                if (dateColumns.length > 0) {
                    const dateFilter = document.createElement('form');
                    dateFilter.className = 'admin-table-date-filter';
                    dateFilter.addEventListener('submit', function (event) {
                        event.preventDefault();
                        $table[0].adminSelectedDate = dateInput.value;
                        dateBadge.textContent = dateInput.value
                            ? new Date(`${dateInput.value}T00:00:00`).toLocaleDateString('en-US', {
                                month: 'long',
                                day: '2-digit',
                                year: 'numeric'
                            })
                            : 'All dates';
                        dataTable.draw();
                    });

                    const dateLabel = document.createElement('label');
                    dateLabel.className = 'form-label mb-0';
                    dateLabel.htmlFor = `${tableId}DateFilter`;
                    dateLabel.textContent = 'Date';
                    dateInput = document.createElement('input');
                    dateInput.className = 'form-control form-control-sm';
                    dateInput.type = 'date';
                    dateInput.id = `${tableId}DateFilter`;
                    dateInput.value = validPageDate;
                    const filterButton = document.createElement('button');
                    filterButton.className = 'btn btn-sm filter-button';
                    filterButton.type = 'submit';
                    filterButton.innerHTML = '<i class="fa-solid fa-filter me-1"></i>Filter';
                    dateBadge = document.createElement('span');
                    dateBadge.className = 'badge bg-primary';
                    dateBadge.textContent = validPageDate
                        ? new Date(`${validPageDate}T00:00:00`).toLocaleDateString('en-US', {
                            month: 'long',
                            day: '2-digit',
                            year: 'numeric'
                        })
                        : 'All dates';
                    dateFilter.append(dateLabel, dateInput, filterButton, dateBadge);
                    toolbar.appendChild(dateFilter);
                }

                searchInput = document.createElement('input');
                searchInput.className = 'form-control form-control-sm admin-table-search';
                searchInput.type = 'search';
                searchInput.placeholder = 'Search records...';
                searchInput.setAttribute('aria-label', 'Search table records');
                toolbar.appendChild(searchInput);

                const tableResponsive = $table.closest('.table-responsive')[0];
                if (tableResponsive) {
                    tableResponsive.parentNode.insertBefore(toolbar, tableResponsive);
                }
            }

            $table[0].adminDateColumns = dateColumns;
            $table[0].adminSelectedDate = validPageDate;
            const defaultOrderColumn = Number($table.attr('data-default-order-column'));
            const defaultOrderDirection = $table.attr('data-default-order-dir');
            const options = {
                responsive: true,
                pageLength: $table.data('page-length') || 10,
                lengthChange: false,
                searching: true,
                ordering: true,
                info: false,
                dom: 'rtp',
                language: { emptyTable: 'No records available in the table.' },
                columns: columns
            };
            const searchInputId = $table.data('search-input');
            if (typeof searchInputId === 'string' && searchInputId !== '') {
                options.dom = 'rtp';
            }

            if (dateColumns.length > 0) {
                options.columnDefs = dateColumns.map(function (columnIndex) {
                    return { targets: columnIndex, type: 'admin-date' };
                });
                options.order = [[dateColumns[0], 'desc']];
            }

            if (Number.isInteger(defaultOrderColumn) && defaultOrderColumn >= 0 && defaultOrderColumn < thCount
                && ['asc', 'desc'].includes(defaultOrderDirection)) {
                options.order = [[defaultOrderColumn, defaultOrderDirection]];
            }

            if (hasCertificateNumber) {
                options.columnDefs = (options.columnDefs || []).concat([
                    { targets: 1, orderable: false, searchable: true }
                ]);
                options.drawCallback = function (settings) {
                    const api = this.api();
                    const info = api.page.info();
                    api.rows({ page: 'current' }).every(function (rowIndex, tableLoop, rowLoop) {
                        const node = $(this.node()).find('.certificate-number');
                        node.text(info.start + rowLoop + 1);
                    });
                };
            }

            const dataTable = $table.DataTable(options);
            if (toolbar && searchInput) {
                searchInput.addEventListener('input', function () {
                    dataTable.search(searchInput.value).draw();
                });
            }
            if (typeof searchInputId === 'string' && searchInputId !== '') {
                const searchInput = document.getElementById(searchInputId);
                if (searchInput) {
                    searchInput.addEventListener('input', function () {
                        dataTable.search(searchInput.value).draw();
                    });
                }
            }
            const countTargetId = $table.data('count-target');
            if (typeof countTargetId === 'string' && countTargetId !== '') {
                const countTarget = document.getElementById(countTargetId);
                if (countTarget) {
                    const updateCount = function () {
                        countTarget.textContent = String(dataTable.rows({ search: 'applied' }).count());
                    };
                    $table.on('draw.dt', updateCount);
                    updateCount();
                }
            }
        });
    }

    document.querySelectorAll('.document-presented-options').forEach(function (group) {
        const checkboxes = Array.from(group.querySelectorAll('input[type="checkbox"][name="document_presented[]"]'));
        const firstCheckbox = checkboxes[0];
        if (!firstCheckbox) {
            return;
        }

        function validateDocumentSelection() {
            const hasSelection = checkboxes.some(function (checkbox) {
                return checkbox.checked;
            });
            firstCheckbox.required = !hasSelection;
            firstCheckbox.setCustomValidity(hasSelection ? '' : 'Select at least one document presented.');
        }

        checkboxes.forEach(function (checkbox) {
            checkbox.addEventListener('change', validateDocumentSelection);
        });
        validateDocumentSelection();
    });
});
