(function () {
    const table = document.getElementById('inspectorsTable');
    const inspectorForm = document.getElementById('inspectorForm');
    const resetPasswordForm = document.getElementById('resetPasswordForm');
    const inspectorModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('inspectorModal'));
    const resetPasswordModal = bootstrap.Modal.getOrCreateInstance(document.getElementById('resetPasswordModal'));
    const passwordUpdatedModalElement = document.getElementById('passwordUpdatedModal');
    const passwordUpdatedModal = bootstrap.Modal.getOrCreateInstance(passwordUpdatedModalElement);

    function notify(message, type) {
        if (typeof window.adminShowToast === 'function') {
            window.adminShowToast(message, type);
        } else {
            window.alert(message);
        }
    }

    async function sendInspectorAction(formData) {
        const response = await fetch('/admin/api_inspector.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || 'The inspector action could not be completed.');
        }
        return result;
    }

    function reloadAfterAction(message) {
        notify(message, 'success');
        window.setTimeout(function () {
            window.location.reload();
        }, 700);
    }

    function setFormSubmitting(form, isSubmitting, button, defaultText, pendingText) {
        form.querySelectorAll('button[type="submit"]').forEach(function (submitButton) {
            submitButton.disabled = isSubmitting;
        });
        button.textContent = isSubmitting ? pendingText : defaultText;
    }

    table.addEventListener('click', async function (event) {
        const button = event.target.closest('button[data-inspector-id]');
        if (!button) {
            return;
        }

        const inspectorId = button.dataset.inspectorId;
        const inspector = inspectorsData[inspectorId];
        if (!inspector) {
            notify('Inspector details could not be loaded. Refresh the page and try again.', 'danger');
            return;
        }

        if (button.classList.contains('inspector-edit')) {
            document.getElementById('inspectorModalLabel').textContent = 'Edit Meat Inspector';
            document.getElementById('inspector_id').value = inspectorId;
            document.getElementById('form_action').value = 'edit';
            document.getElementById('inspector_name').value = inspector.name;
            document.getElementById('inspector_email').value = inspector.email;
            document.getElementById('inspector_phone').value = inspector.phone;
            document.getElementById('inspector_status').value = inspector.status;
            document.getElementById('inspector_password').value = '';
            document.getElementById('inspectorSubmitButton').textContent = 'Save Changes';
            inspectorModal.show();
            return;
        }

        if (button.classList.contains('inspector-toggle-status')) {
            const nextStatus = button.dataset.status;
            if (nextStatus === 'Inactive' && !window.confirm('Deactivate ' + inspector.name + '?')) {
                return;
            }

            const formData = new FormData();
            formData.set('action', 'toggle_status');
            formData.set('inspector_id', inspectorId);
            formData.set('status', nextStatus);
            button.disabled = true;
            try {
                const result = await sendInspectorAction(formData);
                reloadAfterAction(result.message);
            } catch (error) {
                notify(error.message, 'danger');
                button.disabled = false;
            }
            return;
        }

        if (button.classList.contains('inspector-delete')) {
            if (!window.confirm('Delete ' + inspector.name + '? This action cannot be undone.')) {
                return;
            }

            const formData = new FormData();
            formData.set('action', 'delete');
            formData.set('inspector_id', inspectorId);
            button.disabled = true;
            try {
                const result = await sendInspectorAction(formData);
                reloadAfterAction(result.message);
            } catch (error) {
                notify(error.message, 'danger');
                button.disabled = false;
            }
            return;
        }

        if (button.classList.contains('inspector-reset-password')) {
            resetPasswordForm.reset();
            document.getElementById('reset_inspector_id').value = inspectorId;
            document.getElementById('resetInspectorName').textContent = inspector.name;
            document.getElementById('reset_password_confirm').setCustomValidity('');
            resetPasswordModal.show();
        }
    });

    inspectorForm.addEventListener('submit', async function (event) {
        event.preventDefault();
        const submitButton = document.getElementById('inspectorSubmitButton');
        const defaultText = document.getElementById('form_action').value === 'add' ? 'Save Inspector' : 'Save Changes';
        const formData = new FormData(inspectorForm);
        setFormSubmitting(inspectorForm, true, submitButton, defaultText, 'Saving...');

        try {
            const result = await sendInspectorAction(formData);
            inspectorModal.hide();
            reloadAfterAction(result.message);
        } catch (error) {
            notify(error.message, 'danger');
            setFormSubmitting(inspectorForm, false, submitButton, defaultText, 'Saving...');
        }
    });

    document.getElementById('openAddInspector').addEventListener('click', function () {
        inspectorForm.reset();
        document.getElementById('inspectorModalLabel').textContent = 'Add Meat Inspector';
        document.getElementById('inspector_id').value = '';
        document.getElementById('form_action').value = 'add';
        document.getElementById('inspectorSubmitButton').textContent = 'Save Inspector';
    });

    resetPasswordForm.addEventListener('submit', async function (event) {
        event.preventDefault();
        const passwordInput = document.getElementById('reset_password');
        const confirmInput = document.getElementById('reset_password_confirm');
        confirmInput.setCustomValidity(passwordInput.value === confirmInput.value ? '' : 'The passwords must match.');
        if (!resetPasswordForm.reportValidity()) {
            return;
        }

        const submitButton = document.getElementById('resetPasswordSubmit');
        const formData = new FormData(resetPasswordForm);
        setFormSubmitting(resetPasswordForm, true, submitButton, 'Set New Password', 'Updating...');
        try {
            await sendInspectorAction(formData);
            document.getElementById('updatedPasswordInspectorName').textContent =
                document.getElementById('resetInspectorName').textContent;
            resetPasswordModalElement.addEventListener('hidden.bs.modal', function showSuccessPopup() {
                passwordUpdatedModal.show();
            }, { once: true });
            resetPasswordModal.hide();
        } catch (error) {
            notify(error.message, 'danger');
            setFormSubmitting(resetPasswordForm, false, submitButton, 'Set New Password', 'Updating...');
        }
    });

    document.getElementById('passwordUpdatedDone').addEventListener('click', function () {
        window.location.reload();
    });

    passwordUpdatedModalElement.addEventListener('hidden.bs.modal', function () {
        window.location.reload();
    });
})();
