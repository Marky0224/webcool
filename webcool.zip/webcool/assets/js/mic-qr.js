document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.mic-qr-code').forEach(function (container) {
        const payload = container.dataset.qrPayload || '';
        if (!payload || typeof window.QRCode !== 'function') {
            console.error('Unable to generate MIC QR code: QR generator or payload is missing.');
            container.textContent = 'QR code unavailable';
            return;
        }

        container.replaceChildren();
        new window.QRCode(container, {
            text: payload,
            width: 220,
            height: 220,
            correctLevel: window.QRCode.CorrectLevel.L
        });

        const image = container.querySelector('img');
        if (image) {
            image.alt = 'QR code containing MIC details as text';
        }
    });
});
