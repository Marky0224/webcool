<?php
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$inspectorDisplayName = get_current_inspector_name();
$inspectorAvatarInitial = strtoupper(substr($inspectorDisplayName, 0, 1));
?>
<nav class="admin-navbar navbar navbar-expand-lg navbar-dark bg-surface shadow-sm sticky-top no-print">
    <div class="container-fluid py-3">
        <?php if ($currentPage !== 'dashboard.php'): ?>
            <button class="btn btn-sm btn-outline-light d-md-none me-2" id="sidebarToggle" aria-label="Toggle sidebar">
                <i class="fa-solid fa-bars"></i>
            </button>
        <?php endif; ?>
        <div class="d-flex align-items-center ms-auto gap-2">
            <?php
            $inspectorDate = $selectedDate ?? ($_GET['date'] ?? date('Y-m-d'));
            $inspectorCurrentPath = parse_url($_SERVER['REQUEST_URI'] ?? $_SERVER['PHP_SELF'] ?? '/inspector/dashboard.php', PHP_URL_PATH);
            ?>
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-light date-filter dropdown-toggle" type="button" id="inspectorDashboardDate" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa-regular fa-calendar-days me-2"></i>
                    <?php echo htmlspecialchars(date('F d, Y', strtotime($inspectorDate ?: date('Y-m-d')))); ?>
                </button>
                <div class="dropdown-menu dropdown-menu-end p-3 shadow-sm" aria-labelledby="inspectorDashboardDate" style="min-width: 250px;">
                    <form action="<?php echo htmlspecialchars($currentPage === 'dashboard.php' ? '/inspector/dashboard.php' : $inspectorCurrentPath); ?>" method="get">
                        <label class="form-label small fw-semibold" for="inspectorDashboardDateInput">Select date</label>
                        <input class="form-control mb-3" type="date" id="inspectorDashboardDateInput" name="date" value="<?php echo htmlspecialchars($inspectorDate); ?>" required>
                        <div class="date-filter-menu-actions">
                            <a class="btn btn-outline-secondary" href="<?php echo htmlspecialchars($inspectorCurrentPath . '?date=' . urlencode(date('Y-m-d'))); ?>">Today</a>
                            <button class="btn filter-button" type="submit">Apply</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle d-flex align-items-center" type="button" id="inspectorProfileMenu" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="avatar bg-success text-white rounded-circle me-2"><?php echo htmlspecialchars($inspectorAvatarInitial); ?></div>
                    <span><?php echo htmlspecialchars($inspectorDisplayName); ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-sm" aria-labelledby="inspectorProfileMenu">
                    <li><a class="dropdown-item" href="/inspector/profile.php"><i class="fa-solid fa-user me-2"></i>See Profile</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="/inspector/logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
